#pragma once
#include "afxwin.h"
#include "afxcmn.h"


enum ArtistType
{
	artistIdent, // artistId
	artistName	 // name
};

enum TrackType
{
	trackId,
	trackName, // name
	genreId,
	composer,
	unitPrice
};

// CAlbumDlg dialog

class CAlbumDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CAlbumDlg)

public:
	CAlbumDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CAlbumDlg();

// Dialog Data
	enum { IDD = IDD_ALBUM };
	
	enum AlbumType
	{
		albumId,
		title,
		artistId
	};	

	void LoadAlbumByID(int id);
private:
	void FillArtistsCombo();
	void FillTracksList();
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	CComboBox mArtistsCombo;
	CListCtrl mTracksList;
	int mArtistValue;
	CString mTitleValue;
};
