// AlbumDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "AlbumDlg.h"
#include "afxdialogex.h"
#include <memory>


// CAlbumDlg dialog


const LPCTSTR gAlbumQuery = 
	_T("SELECT albumId, title, artistId FROM albums ")
	_T(" WHERE albumId = %d");

const LPCTSTR gArtistsQuery =
	_T("SELECT artistId, name FROM artists");

const LPCTSTR gTrackQuery = 
	_T("SELECT trackId,	name, genreId,	composer, unitPrice ")
	_T(" FROM tracks WHERE albumId = %d");

IMPLEMENT_DYNAMIC(CAlbumDlg, CDialogEx)

CAlbumDlg::CAlbumDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CAlbumDlg::IDD, pParent)	
	, mArtistValue(0)
	, mTitleValue(_T(""))
{

}

CAlbumDlg::~CAlbumDlg()
{
}

void CAlbumDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ALBUM_ARTISTS_COMBO, mArtistsCombo);
	DDX_Control(pDX, IDC_ALBUM_TRACKS_LIST, mTracksList);	
	DDX_CBIndex(pDX, IDC_ALBUM_ARTISTS_COMBO, mArtistValue);
	DDX_Text(pDX, IDC_ALBUM_TITLE_EDIT, mTitleValue);
}


void CAlbumDlg::LoadAlbumByID(int id)
{
	CString query;
	query.Format(gAlbumQuery, id);

	std::unique_ptr<CSqlStatement> stmt(theApp.mSQLiteDB.Statement(query));
	ASSERT(stmt);

	if (stmt->NextRow())
	{
		CArray<CString, LPCTSTR> values;

		for (int k = 0; k < stmt->Fields(); ++k)
		{
			// ������� ������ ���� '(null)'
			if (CString(stmt->ValueString(k)) != _T("(null)"))
				values.Add(stmt->ValueString(k));
			else
				values.Add(_T(""));
		}

		mTitleValue = values[AlbumType::title];
		mArtistValue = _ttoi(values[AlbumType::artistId]);
	}
}


void CAlbumDlg::FillArtistsCombo()
{
	CString query;
	query.Format(gArtistsQuery);

	std::unique_ptr<CSqlStatement> stmt(theApp.mSQLiteDB.Statement(query));
	ASSERT(stmt);

	while (stmt->NextRow())
	{		
		CString value;
		value = stmt->ValueString(ArtistType::artistName);
		mArtistsCombo.AddString(value);
	}
}


void CAlbumDlg::FillTracksList()
{
	//TODO:
}


BEGIN_MESSAGE_MAP(CAlbumDlg, CDialogEx)
END_MESSAGE_MAP()


// CAlbumDlg message handlers


BOOL CAlbumDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	HICON hIcon = AfxGetApp()->LoadIcon(IDI_CD);
	ASSERT(hIcon);
	SetIcon(hIcon, TRUE);

	FillArtistsCombo();
	mArtistsCombo.SetCurSel(mArtistValue - 1);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
