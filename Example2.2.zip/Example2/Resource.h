//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Example2.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_Example2TYPE                130
#define IDB_LOGO                        310
#define IDC_SORTBY_COMBO                32771
#define ID_TABLES_ALBUMS                32772
#define ID_TABLES_ARTISTS               32773
#define ID_TABLES_TRACKS                32774
#define ID_TABLES_MEDIATYPES            32775
#define ID_TABLES_GENRES                32776
#define ID_TABLES_PLAYLISTS             32777
#define ID_TABLES_PLAYLISTTRACKS        32778
#define ID_TABLES_CUSTOMERS             32779
#define ID_TABLES_EMPLOYEES             32780
#define ID_TABLES_INVOICES              32781
#define ID_TABLES_INVOICEITEMS          32782
#define ID_NAVIGATION_NEXTPAGE          32785
#define ID_NAVIGATION_LASTPAGE          32786
#define ID_NAVIGATION_FIRSTPAGE         32787
#define ID_NAVIGATION_PRIORPAGE         32788
#define IDC_DETAIL_BUTTON				1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        312
#define _APS_NEXT_COMMAND_VALUE         32789
#define _APS_NEXT_CONTROL_VALUE         1053
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
