
// Example2View.h : interface of the CExample2View class
//

#pragma once

#include <memory>


extern const int sRowCountInPageConst;


class CExample2View : public CScrollView
{
protected: // create from serialization only
	CExample2View();
	DECLARE_DYNCREATE(CExample2View)

// Attributes
public:
	CExample2Doc* GetDocument() const;

// Operations
public:

// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CExample2View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif


protected:
	static const int cTwipsInPoint = 20;

	int mMapMode;	// MM_TWIPS = 1/1440 inch
	int mFontSize;	// in points	
	CString mFontName;
	LONG mFontWeight;
	
	int mTotalWidth;
	int mRowHeight;
	CArray<int> mColumnMaxWidths;


	class Cell
	{
	public:
		Cell(){}
		explicit Cell(const CRect& cell) : mCell(cell) {}
		Cell(const CPoint& leftTop, const CPoint& rightBottom)
			: mCell(leftTop, rightBottom) {}
		~Cell(){}
		int Width() const { return mCell.Width(); }
		int Height() const { return mCell.Height(); }
		//CRect& GetCell() { return mCell; }
		LONG left() const { return mCell.left; }
		LONG top() const { return mCell.top; }
		LONG right() const { return mCell.right; }
		LONG bottom() const { return mCell.bottom; }
		operator CRect() const { return mCell; }
		CString mValue;
	private:		
		CRect mCell;
	};

	class Row
	{
	public:
		Row(){}
		~Row(){}
		int AddCell(const Cell& cell) { return mRow.Add(cell); }
		int CellCount() const { return mRow.GetCount(); }
		const Row& operator=(const Row& row)
		{
			mRow.Copy(row.mRow);
			return *this;
		}
		const Cell& operator[](int index) const
		{
			return mRow[index];
		}		
	private:
		CArray<Cell> mRow;
	};

	class Grid
	{
	public:
		Grid() {}
		~Grid() {}	
		int AddRow(const Row& row) { return mGrid.Add(row); }
		void RemoveRows() { mGrid.RemoveAll(); }
		int RowCount() const { return mGrid.GetCount(); }
		int CellCount() const { return mGrid.ElementAt(0).CellCount(); }
		const Row& operator[](int index) const
		{
			return mGrid[index];
		}
	private:
		CArray<Row> mGrid;
	};

	Grid mGrid;
	
	HFONT SetFont(CDC* pDC, const LOGFONT* lpLogFont);
	void CalcGridMetrics();	
	void CalcColumnMaxWidths(LONG charWidth, int space = 100);
	void CalcRowMetrics();

	void DrawHeader(CDC* pDC, CPoint pt);
	void DrawFrame(CDC* pDC, CPoint pt);
	void DrawContent(CDC* pDC, CPoint pt);

	void LayoutNavigationButtons(CPoint pt);
	void UpdateStateNavButtons();
	void LayoutDetailButtons(const CPoint& pt);


public:
	CButton mFirstPageButton,
		mPriorPageButton,
		mNextPageButton,
		mLastPageButton;

	//CObArray mDetailButtons;
	CArray<std::shared_ptr<CButton>> mDetailButtons;

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
	virtual void OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/);
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnNavigationFirstpage();
	afx_msg void OnNavigationLastpage();
	afx_msg void OnNavigationNextpage();
	afx_msg void OnNavigationPriorpage();
	afx_msg void OnUpdateNavigationFirstpage(CCmdUI *pCmdUI);
	afx_msg void OnUpdateNavigationLastpage(CCmdUI *pCmdUI);
	afx_msg void OnUpdateNavigationNextpage(CCmdUI *pCmdUI);
	afx_msg void OnUpdateNavigationPriorpage(CCmdUI *pCmdUI);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
};

#ifndef _DEBUG  // debug version in Example2View.cpp
inline CExample2Doc* CExample2View::GetDocument() const
   { return reinterpret_cast<CExample2Doc*>(m_pDocument); }
#endif

