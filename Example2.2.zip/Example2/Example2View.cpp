
// Example2View.cpp : implementation of the CExample2View class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "Example2.h"
#endif

#include "Example2Doc.h"
#include "Example2View.h"
#include "MainFrm.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CExample2View

static const int sRowCountInPageConst = 50;


IMPLEMENT_DYNCREATE(CExample2View, CScrollView)

BEGIN_MESSAGE_MAP(CExample2View, CScrollView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CScrollView::OnFilePrintPreview)
	ON_WM_CREATE()
	ON_COMMAND(ID_NAVIGATION_FIRSTPAGE, &CExample2View::OnNavigationFirstpage)
	ON_COMMAND(ID_NAVIGATION_LASTPAGE, &CExample2View::OnNavigationLastpage)
	ON_COMMAND(ID_NAVIGATION_NEXTPAGE, &CExample2View::OnNavigationNextpage)
	ON_COMMAND(ID_NAVIGATION_PRIORPAGE, &CExample2View::OnNavigationPriorpage)
	ON_UPDATE_COMMAND_UI(ID_NAVIGATION_FIRSTPAGE, &CExample2View::OnUpdateNavigationFirstpage)
	ON_UPDATE_COMMAND_UI(ID_NAVIGATION_LASTPAGE, &CExample2View::OnUpdateNavigationLastpage)
	ON_UPDATE_COMMAND_UI(ID_NAVIGATION_NEXTPAGE, &CExample2View::OnUpdateNavigationNextpage)
	ON_UPDATE_COMMAND_UI(ID_NAVIGATION_PRIORPAGE, &CExample2View::OnUpdateNavigationPriorpage)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_SETCURSOR()
END_MESSAGE_MAP()

// CExample2View construction/destruction

CExample2View::CExample2View()
	: mMapMode(MM_TWIPS)
	, mFontSize(10)
	, mFontName(_T("Consolas"))
	, mFontWeight(FW_BOLD)
	, mRowHeight(0)
	, mTotalWidth(0)
{
	// TODO: add construction code here	
}

CExample2View::~CExample2View()
{
}

BOOL CExample2View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	cs.style |= WS_CLIPCHILDREN | WS_CLIPSIBLINGS;

	return CScrollView::PreCreateWindow(cs);
}

// CExample2View drawing

void CExample2View::OnDraw(CDC* pDC)
{
	/*CExample2Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;*/

	// ������
	pDC->SetWindowOrg(-100, 100);

	// ��������� ����� 
	CPoint pt(0, 0);
	DrawHeader(pDC, pt);
	DrawContent(pDC, pt);
	DrawFrame(pDC, pt);
}

void CExample2View::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();	

	//CSize sizeTotal;
	//// TODO: calculate the total size of this view
	//sizeTotal.cx = sizeTotal.cy = 100;
	//SetScrollSizes(MM_TEXT, sizeTotal);
}


// CExample2View printing

BOOL CExample2View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CExample2View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CExample2View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}


// CExample2View diagnostics

#ifdef _DEBUG
void CExample2View::AssertValid() const
{
	CScrollView::AssertValid();
}

void CExample2View::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CExample2Doc* CExample2View::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CExample2Doc)));
	return (CExample2Doc*)m_pDocument;
}
#endif //_DEBUG


HFONT CExample2View::SetFont(CDC* pDC, const LOGFONT* lpLogFont)
{
	static HFONT hOldFont;
	//static HGDIOBJ hOldFont;

	CFont font;
	font.CreateFontIndirect(lpLogFont);

	if (hOldFont)
		::DeleteObject(hOldFont);

	hOldFont = reinterpret_cast<HFONT>(pDC->SelectObject(&font));
	//hOldFont = static_cast<HGDIOBJ>(pDC->SelectObject(&font));
	//TRACE("hOldFont = %08X\n", hOldFont);	

	HFONT hFont = static_cast<HFONT>(font.Detach());
	//TRACE("hFont = %08X\n", hFont);

	return hOldFont;
}


void CExample2View::CalcColumnMaxWidths(LONG charWidth, int space)
{
	CArray<int> widths;

	const int fieldCount = GetDocument()->mTable.FieldCount();
	CString fieldName;

	// ��������� ����� �������� ����� �������
	for (int k = 0; k < fieldCount; ++k)
	{
		fieldName = GetDocument()->mTable[0][k].FieldName();		
		int len = fieldName.GetLength();		
		widths.Add(len);
	}

	CString fieldValue;

	// ��������� ����. ����� ������ ����� 
	for (int i = 0; i < GetDocument()->mTable.RecordCount(); ++i)
	{
		for (int k = 0; k < fieldCount; ++k)
		{
			fieldValue = GetDocument()->mTable[i][k].FieldValue();
			int len = fieldValue.GetLength();

			if (widths[k] < len)	widths[k] = len;
		}
	}

	// ��������� ����.������ ��������
	for (int k = 0; k < widths.GetCount(); ++k)
	{
		widths[k] *= charWidth;
		widths[k] += space;
	}

	mColumnMaxWidths.RemoveAll();

	// ��������� ��������� 
	for (int k = 0; k < widths.GetCount(); ++k)
	{
		mColumnMaxWidths.Add(widths[k]);
	}
}


void CExample2View::CalcRowMetrics()
{
	TEXTMETRIC tm{ 0 };	//memset(&tm, 0, sizeof(TEXTMETRIC));
	LOGFONT lf{ 0 };	//memset(&lf, 0, sizeof(LOGFONT));
	_tcscpy_s(lf.lfFaceName, mFontName);
	lf.lfHeight = -mFontSize * cTwipsInPoint;
	lf.lfWeight = mFontWeight;

	CClientDC dc(this);
	dc.SetMapMode(mMapMode);
	HFONT hOldFont = SetFont(&dc, &lf);
	dc.GetTextMetrics(&tm);
	dc.SelectObject(hOldFont);

	// TODO: ������ ������ 
	//--> begin
	CSize buttonSize(76, 23);
	dc.DPtoLP(&buttonSize);
	mRowHeight = tm.tmHeight + tm.tmExternalLeading;
	if (mRowHeight < buttonSize.cy)		mRowHeight = buttonSize.cy;
	//--> end

	// ������ �������		
	CalcColumnMaxWidths(tm.tmAveCharWidth);

	int totalWidth = 0;
	for (int i = 0; i < mColumnMaxWidths.GetCount(); ++i)
	{
		totalWidth += mColumnMaxWidths[i];
	}

	mTotalWidth = totalWidth;
}


void CExample2View::CalcGridMetrics()
{
	// TODO: CalcGridMetrics
	TEXTMETRIC tm{ 0 };
	LOGFONT lf{ 0 };
	_tcscpy_s(lf.lfFaceName, mFontName);
	lf.lfHeight = -mFontSize * cTwipsInPoint;
	lf.lfWeight = mFontWeight;

	CClientDC dc(this);
	dc.SetMapMode(mMapMode);
	HFONT hOldFont = SetFont(&dc, &lf);
	dc.GetTextMetrics(&tm);
	dc.SelectObject(hOldFont);

	CSize buttonSize(76, 23);
	dc.DPtoLP(&buttonSize);
	mRowHeight = tm.tmHeight + tm.tmExternalLeading;
	if (mRowHeight < buttonSize.cy)		mRowHeight = buttonSize.cy;

	mGrid.RemoveRows();

	int fieldCount = GetDocument()->mTable.FieldCount();
	CPoint leftTop(0, 0), rightBottom(0, -mRowHeight);
	Row row;

	for (int k = 0; k < fieldCount; ++k)
	{
		rightBottom.x += mColumnMaxWidths[k];

		Cell cell(leftTop, rightBottom);
		cell.mValue = GetDocument()->mTable[0][k].FieldName();
		row.AddCell(cell);

		leftTop.x += mColumnMaxWidths[k];
	}

	mGrid.AddRow(row);

	int recordCount = GetDocument()->mTable.RecordCount();

	leftTop.y -= mRowHeight * 1.5;
	rightBottom.y = leftTop.y - mRowHeight;

	for (int i = 0; i < recordCount; ++i)
	{
		Row row;
		leftTop.x = 0;
		rightBottom.x = -mRowHeight;

		for (int k = 0; k < fieldCount; ++k)
		{
			rightBottom.x += mColumnMaxWidths[k];
			rightBottom.y = leftTop.y - mRowHeight;

			Cell cell(leftTop, rightBottom);
			cell.mValue = GetDocument()->mTable[i][k].FieldValue();
			row.AddCell(cell);

			leftTop.x += mColumnMaxWidths[k];
		}

		mGrid.AddRow(row);
		leftTop.y -= mRowHeight;
	}

	/*TRACE("(%d, %d)\n", mGrid[0].CellCount(), mGrid.RowCount());

	for (int i = 0; i < mGrid.RowCount(); ++i)
	{
	for (int k = 0; k < mGrid.CellCount(); k++)
	{
	TRACE("(%d, %d, %d, %d)\n",
	mGrid[i][k].left(), mGrid[i][k].top(),
	mGrid[i][k].right(), mGrid[i][k].bottom());
	}
	TRACE(_T("%s\n"), _T("----------------------"));
	}		*/
}


void CExample2View::DrawHeader(CDC* pDC, CPoint pt)
{
	// ����� ��������� �������
	LOGFONT lf{ 0 }; 	//memset(&lf, 0, sizeof(LOGFONT));
	_tcscpy_s(lf.lfFaceName, mFontName);
	lf.lfHeight = -mFontSize * cTwipsInPoint;
	lf.lfWeight = mFontWeight;
	HFONT hOldFont = SetFont(pDC, &lf);

	/*pDC->SetTextColor(RGB(0, 0, 255));
	pDC->SetBkColor(RGB(255, 255, 0));*/

	const int fieldCount = GetDocument()->mTable.FieldCount();
	CString fieldName;

	for (int k = 0; k < fieldCount; ++k)
	{
		fieldName = GetDocument()->mTable[0][k].FieldName();
		fieldName.MakeUpper();
		pDC->TextOut(pt.x, pt.y, fieldName);
		pt.x += mColumnMaxWidths[k];
	}

	pDC->SelectObject(hOldFont);
}


void CExample2View::DrawFrame(CDC* pDC, CPoint pt)
{
	const int dx = 70;
	int rowCount = GetDocument()->mTable.RecordCount();
	int cy = mRowHeight  * (rowCount + 2);

	CPen pen;
	pen.CreatePen(PS_SOLID, 1, RGB(0, 0, 0));
	CPen* pOldPen = pDC->SelectObject(&pen);

	// ����� ������ �������
	pDC->MoveTo(pt.x - dx, pt.y);
	pDC->LineTo(pt.x + mTotalWidth - dx, pt.y);
	pDC->LineTo(pt.x + mTotalWidth - dx, pt.y - cy);
	pDC->LineTo(pt.x - dx, pt.y - cy);
	pDC->LineTo(pt.x - dx, pt.y);

	// ����� ��� ���������� �������
	pDC->MoveTo(pt.x - dx, pt.y - mRowHeight);
	pDC->LineTo(pt.x + mTotalWidth - dx, pt.y - mRowHeight);

	// ������� ���������
	/*CBrush brush;
	brush.CreateSolidBrush(RGB(255, 255, 0));
	CBrush* pOldBrush = pDC->SelectObject(&brush);
	CRect rc(pt.x - dx, pt.y, pt.x + mTotalWidth - dx, pt.y - mRowHeight);
	pDC->FillRect(rc, &brush);
	pDC->SelectObject(pOldBrush);*/

	// ������������ ��������
	int cx = mColumnMaxWidths[0];
	for (int i = 1; i < mColumnMaxWidths.GetCount(); ++i)
	{
		pDC->MoveTo(pt.x + cx - dx, pt.y);
		pDC->LineTo(pt.x + cx - dx, pt.y - cy);
		cx += mColumnMaxWidths[i];
	}

	pDC->SelectObject(pOldPen);
}


void CExample2View::DrawContent(CDC* pDC, CPoint pt)
{
	LOGFONT lf{ 0 };	//memset(&lf, 0, sizeof(LOGFONT));
	_tcscpy_s(lf.lfFaceName, mFontName);
	lf.lfHeight = -(mFontSize - 2) * cTwipsInPoint;
	lf.lfWeight = FW_NORMAL;

	HFONT hOldFont = SetFont(pDC, &lf);

	/*pDC->SetTextColor(RGB(0, 0, 0));
	pDC->SetBkColor(RGB(255, 255, 255));*/

	int cy = pt.y - mRowHeight * 1.5;

	const int fieldCount = GetDocument()->mTable.FieldCount();
	//TRACE("field count = %d\n", fieldCount);		
	int recordCount = GetDocument()->mTable.RecordCount();
	//TRACE("record count = %d\n", recordCount);

	CString fieldValue;	
	for (int i = 0; i < recordCount; ++i)
	{
		for (int k = 0, cx = 0; k < fieldCount; ++k)
		{
			fieldValue = GetDocument()->mTable[i][k].FieldValue();
			// ���������� ������� ��������
			if (fieldValue != _T("(null)"))
				pDC->TextOut(pt.x + cx, pt.y + cy, fieldValue);

			cx += mColumnMaxWidths[k];
		}
		cy -= mRowHeight;
	}

	pDC->SelectObject(hOldFont);
}


void CExample2View::LayoutNavigationButtons(CPoint pt)
{
	// ����������� ������ ���������	

	int mapMode;
	CSize totalSize, pageSize, lineSize;
	GetDeviceScrollSizes(mapMode, totalSize, pageSize, lineSize);

	CPoint scrlPos = GetDeviceScrollPosition();	

	const CSize buttonSize(76, 23);
	int cx = pt.x - scrlPos.x;
	int cy = pt.y + totalSize.cy - scrlPos.y - buttonSize.cy;

	CPoint first(cx, cy);
	CPoint prior(first.x + buttonSize.cx, cy);
	CPoint next(prior.x + buttonSize.cx, cy);
	CPoint last(next.x + buttonSize.cx, cy);

	mFirstPageButton.SetWindowPos(&wndTop, first.x, first.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
	mPriorPageButton.SetWindowPos(&wndTop, prior.x, prior.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
	mNextPageButton.SetWindowPos(&wndTop, next.x, next.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
	mLastPageButton.SetWindowPos(&wndTop, last.x, last.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);	
}


void CExample2View::UpdateStateNavButtons()
{
	mFirstPageButton.EnableWindow(GetDocument()->mCurRowN != 0);
	mLastPageButton.EnableWindow(GetDocument()->mTable.RecordCount() == sRowCountInPageConst);
	mNextPageButton.EnableWindow(GetDocument()->mTable.RecordCount() == sRowCountInPageConst);
	mPriorPageButton.EnableWindow(GetDocument()->mCurRowN != 0);
}


// CExample2View message handlers


void CExample2View::OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/)
{
	// ������������� ���������� ������� ����	
	int rowCount = GetDocument()->mTable.RecordCount();
	TRACE(_T("rows count = %d\n"), rowCount);

	CalcRowMetrics();
	TRACE(_T("columns count = %d\n"), mColumnMaxWidths.GetCount());
	//TRACE(_T("row height = %d\n"), mRowHeight);

	// ���.������� ����	
	const int cx = mTotalWidth + 500;
	const int cy = mRowHeight * (rowCount + 5);

	CSize sizeTotal(cx, cy);
	CSize sizePage(sizeTotal.cx / 2, sizeTotal.cy / 2);
	CSize sizeLine(sizeTotal.cx / 50, sizeTotal.cy / 50);

	SetScrollSizes(mMapMode, sizeTotal, sizePage, sizeLine);
	Invalidate();

	CPoint pt(0, 0);
	LayoutNavigationButtons(pt);
	UpdateStateNavButtons();
	//LayoutDetailButtons(pt);	

	//CreateGrid();
	CalcGridMetrics();
}



int CExample2View::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CScrollView::OnCreate(lpCreateStruct) == -1)
		return -1;

	// ������� ������ �������
	mFirstPageButton.Create(_T("First"), BS_PUSHBUTTON, CRect(0, 0, 76, 23), this, ID_NAVIGATION_FIRSTPAGE);
	mPriorPageButton.Create(_T("Prior"), BS_PUSHBUTTON, CRect(0, 0, 76, 23), this, ID_NAVIGATION_PRIORPAGE);
	mNextPageButton.Create(_T("Next"), BS_PUSHBUTTON, CRect(0, 0, 76, 23), this, ID_NAVIGATION_NEXTPAGE);
	mLastPageButton.Create(_T("Last"), BS_PUSHBUTTON, CRect(0, 0, 76, 23), this, ID_NAVIGATION_LASTPAGE);

	CFont font;
	LOGFONT lf{ 0 };
	_tcscpy_s(lf.lfFaceName, _T("Consolas"));
	lf.lfHeight = -12;
	lf.lfWeight = FW_SEMIBOLD;
	font.CreateFontIndirect(&lf);
	mFirstPageButton.SetFont(&font);
	mPriorPageButton.SetFont(&font);
	mNextPageButton.SetFont(&font);
	mLastPageButton.SetFont(&font);
	font.Detach();

	return 0;
}


void CExample2View::OnNavigationFirstpage()
{
	TRACE("OnNavigationFirstpage\n");
	GetDocument()->mCurRowN = 0;
	GetDocument()->LoadPartDataFromTable();
	GetDocument()->UpdateAllViews(NULL);
}


void CExample2View::OnNavigationLastpage()
{
	TRACE("OnNavigationLastpage\n");	
	int recCount = GetDocument()->mTotalRecords;
	recCount -= recCount % sRowCountInPageConst;
	GetDocument()->mCurRowN = recCount;
	GetDocument()->LoadPartDataFromTable();
	GetDocument()->UpdateAllViews(NULL);
}


void CExample2View::OnNavigationNextpage()
{
	TRACE("OnNavigationNextpage\n");
	GetDocument()->mCurRowN += sRowCountInPageConst;
	GetDocument()->LoadPartDataFromTable();
	GetDocument()->UpdateAllViews(NULL);
}


void CExample2View::OnNavigationPriorpage()
{
	TRACE("OnNavigationPriorpage\n");
	GetDocument()->mCurRowN -= sRowCountInPageConst;
	GetDocument()->LoadPartDataFromTable();
	GetDocument()->UpdateAllViews(NULL);
}


void CExample2View::OnUpdateNavigationFirstpage(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->mCurRowN != 0);
}


void CExample2View::OnUpdateNavigationLastpage(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->mTable.RecordCount() == sRowCountInPageConst);
}


void CExample2View::OnUpdateNavigationNextpage(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->mTable.RecordCount() == sRowCountInPageConst);
}


void CExample2View::OnUpdateNavigationPriorpage(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->mCurRowN != 0);
}


void CExample2View::OnMouseMove(UINT nFlags, CPoint point)
{		
	CClientDC dc(this);
	dc.SetMapMode(mMapMode);		
	dc.DPtoLP(&point);	
	
	CPoint scrlPos = GetScrollPosition();
	point.Offset(scrlPos);	

//	TRACE("(%d, %d)\n", point.x, point.y);

	CScrollView::OnMouseMove(nFlags, point);
}


void CExample2View::OnLButtonDown(UINT nFlags, CPoint point)
{	
	CClientDC dc(this);
	dc.SetMapMode(mMapMode);
	dc.DPtoLP(&point);
	CPoint scrlPos = GetScrollPosition();
	point.Offset(scrlPos);
	TRACE("(%d, %d)\n", point.x, point.y);

	CRect rect;	
	for (int i = 0; i < mGrid.RowCount(); ++i)
	{
		for (int k = 0; k < mGrid.CellCount(); ++k)
		{
			rect = mGrid[i][k];
			rect.NormalizeRect();

			if (rect.PtInRect(point))
			{
				TRACE("(%d, %d, %d, %d)\n",
					mGrid[i][k].left(), mGrid[i][k].top(),
					mGrid[i][k].right(), mGrid[i][k].bottom());
				TRACE(_T("cell value: %s\n"), mGrid[i][k].mValue);
				// TODO: OnLButtonDown
				CString message;
				message.Format(_T("This function isn't yet complete.\n\n%s"), mGrid[i][k].mValue);
				AfxMessageBox(message, MB_OK | MB_ICONINFORMATION);
			}
		}		
	}

	CScrollView::OnLButtonDown(nFlags, point);
}


BOOL CExample2View::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{

	::SetCursor(AfxGetApp()->LoadStandardCursor(IDC_HAND));
	return TRUE;

	//return CScrollView::OnSetCursor(pWnd, nHitTest, message);
}
