//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Example1.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_Example1TYPE                130
#define IDB_LOGO                        310
#define IDB_FIRSTPAGE                   313
#define IDB_PRIORPAGE                   314
#define IDB_NEXTPAGE                    315
#define IDB_BITMAP1                     316
#define IDB_LASTPAGE                    316
#define ID_TABLES_ALBUMS                32771
#define ID_TABLES_ARTISTS               32772
#define ID_TABLES_CUSTOMERS             32773
#define ID_TABLES_EMPLOYEES             32775
#define ID_TABLES_GENRES                32776
#define ID_TABLES_INVOICES              32778
#define ID_TABLES_MEDIATYPES            32779
#define ID_TABLES_PLAYLISTTRACK         32780
#define ID_TABLES_TRACKS                32782
#define ID_TABLES_PLAYLISTS             32783
#define ID_TABLES_INVOICEITEMS          32785
#define ID_NAVIGATION_NEXTPAGE          32798
#define ID_NAVIGATION_LASTPAGE          32799
#define ID_NAVIGATION_FIRSTPAGE         32800
#define ID_NAVIGATION_PRIORPAGE         32801

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        317
#define _APS_NEXT_COMMAND_VALUE         32803
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           311
#endif
#endif
