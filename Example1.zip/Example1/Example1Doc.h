
// Example1Doc.h : interface of the CExample1Doc class
//


#pragma once

#include "DbSqlite.h"


class CExample1Doc : public CDocument
{
protected: // create from serialization only
	CExample1Doc();
	DECLARE_DYNCREATE(CExample1Doc)

// Attributes
public:

// Operations
public:

// Overrides
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
#ifdef SHARED_HANDLERS
	virtual void InitializeSearchContent();
	virtual void OnDrawThumbnail(CDC& dc, LPRECT lprcBounds);
#endif // SHARED_HANDLERS

// Implementation
public:
	virtual ~CExample1Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

private:	

protected:

public:	
	CDbSQLite mSQLiteDB;	
	CSqlStatement* mSQLiteStatement;		

	bool mIsDbConnected;
	CString mDBFilename;	
	CString mTableName;	
	int mCurRowN;

	int GetRecordCount();
	int GetAllRecordCount();

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()

#ifdef SHARED_HANDLERS
	// Helper function that sets search content for a Search Handler
	void SetSearchContent(const CString& value);
#endif // SHARED_HANDLERS
public:
	afx_msg void OnTablesAlbums();
	afx_msg void OnTablesCustomers();
	afx_msg void OnTablesArtists();
	afx_msg void OnTablesTracks();
	afx_msg void OnTablesGenres();
	afx_msg void OnTablesMediatypes();
	afx_msg void OnTablesPlaylists();	
	afx_msg void OnTablesPlaylisttrack();
	afx_msg void OnTablesEmployees();
	afx_msg void OnTablesInvoices();
	afx_msg void OnTablesInvoiceitems();
	afx_msg void OnUpdateTablesAlbums(CCmdUI *pCmdUI);
	afx_msg void OnUpdateTablesCustomers(CCmdUI *pCmdUI);
	afx_msg void OnUpdateTablesArtists(CCmdUI *pCmdUI);
	afx_msg void OnUpdateTablesTracks(CCmdUI *pCmdUI);
	afx_msg void OnUpdateTablesGenres(CCmdUI *pCmdUI);
	afx_msg void OnUpdateTablesMediatypes(CCmdUI *pCmdUI);
	afx_msg void OnUpdateTablesPlaylists(CCmdUI *pCmdUI);
	afx_msg void OnUpdateTablesPlaylisttrack(CCmdUI *pCmdUI);
	afx_msg void OnUpdateTablesEmployees(CCmdUI *pCmdUI);
	afx_msg void OnUpdateTablesInvoices(CCmdUI *pCmdUI);
	afx_msg void OnUpdateTablesInvoiceitems(CCmdUI *pCmdUI);
};
