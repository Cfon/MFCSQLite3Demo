
// Example1View.h : interface of the CExample1View class
//

#pragma once

#include "DbSqlite.h"


class CExample1View : public CScrollView
{
protected: // create from serialization only
	CExample1View();
	DECLARE_DYNCREATE(CExample1View)

// Attributes
public:
	CExample1Doc* GetDocument() const;

// Operations
public:

// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void OnInitialUpdate(); // called first time after construct

// Implementation
public:
	virtual ~CExample1View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
public:
	static const int cRowCountInPage = 50;

private:	
	static const int cPointInTwips = 20;

	int mMapMode;	// MM_TWIPS = 1/1440 inch
	int mFontSize;	// in points	
	CString mFontName;
	LONG mFontWeight;
	int mLineHeight;
	
	CArray<int> mColumnMaxWidths;
	int mTotalWidth;

	HFONT SetFont(const LOGFONT& lf, CDC* pDC);	
	void CalcColumnMaxWidths(LONG charWidth, int space=100);	
	void CalcRowMetrics();

	void DrawHeader(CDC* pDC, CPoint& pt);
	void DrawFrame(CDC* pDC, CPoint& pt);
	void DrawContent(CDC* pDC, CPoint& pt);
	void DrawTable(CDC* pDC, CPoint& pt);
	
	void LayoutNavigationButtons(CDC* pDC, const CPoint& atPoint);
	void LayoutNavigationButtons(const CPoint& atPoint);
	void UpdateStateNavButtons();

public:		
	CButton mFirstPageButton, 
		mPriorPageButton, 
		mNextPageButton, 
		mLastPageButton;

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
public:
	virtual void OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/);	
	afx_msg void OnFirstButton();
	afx_msg void OnLastButton();
	afx_msg void OnNextButton();
	afx_msg void OnPriorButton();	
	afx_msg void OnUpdateFirstButton(CCmdUI *pCmdUI);
	afx_msg void OnUpdateLastButton(CCmdUI *pCmdUI);
	afx_msg void OnUpdateNextButton(CCmdUI *pCmdUI);
	afx_msg void OnUpdatePriorButton(CCmdUI *pCmdUI);	
};

#ifndef _DEBUG  // debug version in Example1View.cpp
inline CExample1Doc* CExample1View::GetDocument() const
   { return reinterpret_cast<CExample1Doc*>(m_pDocument); }
#endif

