
// Example1View.cpp : implementation of the CExample1View class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "Example1.h"
#endif

#include "Example1Doc.h"
#include "Example1View.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CExample1View

IMPLEMENT_DYNCREATE(CExample1View, CScrollView)

BEGIN_MESSAGE_MAP(CExample1View, CScrollView)
	ON_WM_CREATE()
END_MESSAGE_MAP()

// CExample1View construction/destruction

CExample1View::CExample1View()	
	: mMapMode(MM_TWIPS)	
	, mFontSize(10)
	, mFontName(_T("Consolas"))
	, mFontWeight(FW_BOLD)
	, mLineHeight(0)	
	, mTotalWidth(0)
{		
}

CExample1View::~CExample1View()
{
}

BOOL CExample1View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

// CExample1View drawing

void CExample1View::OnDraw(CDC* pDC)
{	
	CExample1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// ������
	pDC->SetWindowOrg(-100, 100);			

	// ��������� ����� 
	CPoint pt(0, 0);	
	
	DrawTable(pDC, pt);
}

void CExample1View::OnInitialUpdate()
{	
	//TRACE("CExample1View::OnInitialUpdate\n");
	CScrollView::OnInitialUpdate();			

	//CRect rc(0, 0, 76, 23);
	//CRect rc(0, -cY+500, mColumnMaxWidths[0], -cY - mLineHeight * 1.5 + 500);	
	//dc.LPtoDP(rc);	
	//CFont newfont;
	//newfont.CreateStockObject(ANSI_VAR_FONT);			
	//mButton.Create(_T("Next"), WS_VISIBLE | WS_TABSTOP, rc, this, 1);
	//mButton.SetFont(&newfont);
	//newfont.Detach();
}


// CExample1View diagnostics

#ifdef _DEBUG
void CExample1View::AssertValid() const
{
	CScrollView::AssertValid();
}

void CExample1View::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CExample1Doc* CExample1View::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CExample1Doc)));
	return (CExample1Doc*)m_pDocument;
}
#endif //_DEBUG


// CExample1View message handlers


int CExample1View::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CScrollView::OnCreate(lpCreateStruct) == -1)
		return -1;	

	return 0;
}


HFONT CExample1View::SetFont(const LOGFONT& lf, CDC* pDC)
{
	static HFONT hFont;
	CFont font;

	font.CreateFontIndirect(&lf);
	HFONT hOldFont = reinterpret_cast<HFONT>(pDC->SelectObject(&font));
	//TRACE(_T("hOldFont = %08X\n"), hOldFont);
	
	if (hOldFont) ::DeleteObject(hOldFont);

	hFont = static_cast<HFONT>(font.Detach());
	//TRACE(_T("hFont = %08X\n"), hFont);
	return hOldFont;
}


void CExample1View::CalcColumnMaxWidths(LONG charWidth, int space)
{	
	CArray<int> widths;
	
	const int cFieldCount = GetDocument()->mSQLiteStatement->Fields();
	CString fieldName;

	// ��������� ����� �������� ����� �������
	for (int i = 0; i < cFieldCount; ++i)
	{
		fieldName = GetDocument()->mSQLiteStatement->FieldName(i);
		widths.Add(fieldName.GetLength());
	}

	CString fieldValue;

	// ��������� ����. ����� ������ ����� 
	while (GetDocument()->mSQLiteStatement->NextRow())
	{		
		for (int i = 0; i < cFieldCount; ++i)
		{
			fieldValue = GetDocument()->mSQLiteStatement->ValueString(i);
			int len = fieldValue.GetLength();

			if (widths[i] < len)	widths[i] = len;			
		}
	}

	// ��������� ����.������ ��������
	for (int i = 0; i < widths.GetCount(); ++i)
	{
		widths[i] *= charWidth;
		widths[i] += space;
	}	
	
	mColumnMaxWidths.RemoveAll();

	// ��������� ��������� 
	for (int i = 0; i < widths.GetCount(); ++i)
	{
		mColumnMaxWidths.Add(widths[i]);
	}	
}

void CExample1View::DrawHeader(CDC* pDC, CPoint& pt)
{	
	const int cFieldCount = GetDocument()->mSQLiteStatement->Fields();	
	CString fieldName;
	
	for (int i = 0; i < cFieldCount; ++i)
	{
		fieldName = GetDocument()->mSQLiteStatement->FieldName(i);
		fieldName.MakeUpper();
		pDC->TextOut(pt.x, pt.y, fieldName);
		pt.x += mColumnMaxWidths[i];
	}
}



void CExample1View::DrawFrame(CDC* pDC, CPoint& pt)
{
	// TODO: ������ �����
	pt.x = 0;
	pt.y -= mLineHeight;

	pDC->MoveTo(0, pt.y);
	pDC->LineTo(mTotalWidth, pt.y);
	//pDC->MoveTo(mColumnMaxWidths[0], 0);
	//pDC->LineTo(mColumnMaxWidths[0], -mLineHeight * (mRecordCount+3));
}


void CExample1View::DrawContent(CDC* pDC, CPoint& pt)
{		
	pt.y -= mLineHeight / 2;

	const int cFieldCount = GetDocument()->mSQLiteStatement->Fields();
	CString fieldValue;

	while (GetDocument()->mSQLiteStatement->NextRow())
	{
		for (int i = 0; i < cFieldCount; ++i)
		{
			fieldValue = GetDocument()->mSQLiteStatement->ValueString(i);
			// ���������� ������� ��������
			if (fieldValue != _T("(null)"))
				pDC->TextOut(pt.x, pt.y, fieldValue);

			pt.x += mColumnMaxWidths[i];
		}

		pt.x = 0;
		pt.y -= mLineHeight;
	}
}


void CExample1View::OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/)
{
	//TRACE(_T("CExample1View::OnUpdate\n"));

	CClientDC dc(this);
	dc.SetMapMode(mMapMode);

	LOGFONT lf;
	memset(&lf, 0, sizeof(LOGFONT));
	_tcscpy_s(lf.lfFaceName, mFontName);
	lf.lfHeight = -mFontSize * 20;
	lf.lfWeight = mFontWeight;
	SetFont(lf, &dc);

	TEXTMETRIC tm;
	memset(&tm, 0, sizeof(TEXTMETRIC));
	dc.GetTextMetrics(&tm);

	// ���������� ������ ������ ������
	mLineHeight = tm.tmHeight + tm.tmExternalLeading;

	// ���������� ������ �������	
	CalcColumnMaxWidths(tm.tmAveCharWidth);	
	mTotalWidth = 0;
	
	for (int i = 0; i < mColumnMaxWidths.GetCount(); ++i)
	{
		mTotalWidth += mColumnMaxWidths[i];
	}

	TRACE(_T("columns count = %d\n"), mColumnMaxWidths.GetCount());

	int recordCount = GetDocument()->GetRecordCount();
	TRACE(_T("record count = %d\n"), recordCount);

	// ������������� ������� ����	
	const int cX = mTotalWidth;
	const int cY = mLineHeight * (recordCount + 5);

	CSize sizeTotal(cX, cY);
	CSize sizePage(sizeTotal.cx / 2, sizeTotal.cy / 2);
	CSize sizeLine(sizeTotal.cx / 50, sizeTotal.cy / 50);

	SetScrollSizes(mMapMode, sizeTotal, sizePage, sizeLine);
	Invalidate();
}


void CExample1View::DrawTable(CDC* pDC, CPoint& pt)
{
	// ����� ��������� �������
	LOGFONT lf;
	memset(&lf, 0, sizeof(LOGFONT));
	_tcscpy_s(lf.lfFaceName, mFontName);
	lf.lfHeight = -mFontSize * 20;
	lf.lfWeight = mFontWeight;
	SetFont(lf, pDC);

	DrawHeader(pDC, pt);
	
	CPen pen;
	pen.CreatePen(PS_DASH, 1, RGB(0, 0, 0));
	pDC->SelectObject(&pen);

	DrawFrame(pDC, pt);

	// �����  ������ 
	_tcscpy_s(lf.lfFaceName, mFontName);
	lf.lfHeight = -(mFontSize - 2) * 20;
	lf.lfWeight = FW_NORMAL;
	SetFont(lf, pDC);
	
	DrawContent(pDC, pt);
}
