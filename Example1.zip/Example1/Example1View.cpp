
// Example1View.cpp : implementation of the CExample1View class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "Example1.h"
#endif

#include "Example1Doc.h"
#include "Example1View.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CExample1View

IMPLEMENT_DYNCREATE(CExample1View, CScrollView)

BEGIN_MESSAGE_MAP(CExample1View, CScrollView)
	ON_WM_CREATE()
	ON_COMMAND(ID_NAVIGATION_FIRSTPAGE, &CExample1View::OnFirstButton)
	ON_COMMAND(ID_NAVIGATION_LASTPAGE, &CExample1View::OnLastButton)
	ON_COMMAND(ID_NAVIGATION_NEXTPAGE, &CExample1View::OnNextButton)
	ON_COMMAND(ID_NAVIGATION_PRIORPAGE, &CExample1View::OnPriorButton)
	ON_UPDATE_COMMAND_UI(ID_NAVIGATION_FIRSTPAGE, &CExample1View::OnUpdateFirstButton)
	ON_UPDATE_COMMAND_UI(ID_NAVIGATION_LASTPAGE, &CExample1View::OnUpdateLastButton)
	ON_UPDATE_COMMAND_UI(ID_NAVIGATION_NEXTPAGE, &CExample1View::OnUpdateNextButton)
	ON_UPDATE_COMMAND_UI(ID_NAVIGATION_PRIORPAGE, &CExample1View::OnUpdatePriorButton)	
END_MESSAGE_MAP()

// CExample1View construction/destruction

CExample1View::CExample1View()	
	: mMapMode(MM_TWIPS)	
	, mFontSize(10)
	, mFontName(_T("Consolas"))
	, mFontWeight(FW_BOLD)
	, mLineHeight(0)	
	, mTotalWidth(0)	
{			
}

CExample1View::~CExample1View()
{
}

BOOL CExample1View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

// CExample1View drawing

void CExample1View::OnDraw(CDC* pDC)
{	
	CExample1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// ������
	pDC->SetWindowOrg(-100, 100);			

	// ��������� ����� 
	CPoint pt(0, 0);		
	DrawTable(pDC, pt);
}

void CExample1View::OnInitialUpdate()
{	
	//TRACE("CExample1View::OnInitialUpdate\n");
	CScrollView::OnInitialUpdate();		
}


// CExample1View diagnostics

#ifdef _DEBUG
void CExample1View::AssertValid() const
{
	CScrollView::AssertValid();
}

void CExample1View::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CExample1Doc* CExample1View::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CExample1Doc)));
	return (CExample1Doc*)m_pDocument;
}
#endif //_DEBUG


void CExample1View::LayoutNavigationButtons(CDC* pDC, const CPoint& atPoint)
{
	// ����������� ������ ��������� �� ��������� 
	CPoint first, prior, next, last;

	const CPoint scrlPos = GetScrollPosition();
	TRACE("(%d, %d)\n", scrlPos.x, scrlPos.y);

	CPoint pt(atPoint.x, -atPoint.y - scrlPos.y + 500);
	pDC->LPtoDP(&pt);

	first.Offset(pt);
	prior.Offset(pt + CPoint(76, 0));
	next.Offset(pt + CPoint(152, 0));
	last.Offset(pt + CPoint(228, 0));

	TRACE("(%d, %d)\n", first.x, first.y);

	mFirstPageButton.SetWindowPos(&wndTop, first.x, first.y, 0, 0, SWP_NOSIZE |  SWP_SHOWWINDOW);
	mPriorPageButton.SetWindowPos(&wndTop, prior.x, prior.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
	mNextPageButton.SetWindowPos(&wndTop, next.x, next.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
	mLastPageButton.SetWindowPos(&wndTop, last.x, last.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);	
}


void CExample1View::LayoutNavigationButtons(const CPoint& atPoint)
{		
	// ����������� ������ ��������� �� ���������

	CSize totalSize, pageSize, lineSize;
	GetDeviceScrollSizes(mMapMode, totalSize, pageSize, lineSize);	

	const CPoint scrlPos = GetDeviceScrollPosition();
	//TRACE("scrlPos: (%d, %d)\n", scrlPos.x, scrlPos.y);

	const CSize cButtonSize(76, 23);	
	int cy = atPoint.y + totalSize.cy - scrlPos.y - cButtonSize.cy;

	const CPoint first(atPoint.x, cy);
	const CPoint prior(first.x + cButtonSize.cx, cy);
	const CPoint next(prior.x + cButtonSize.cx, cy);
	const CPoint last(next.x + cButtonSize.cx, cy);

	mFirstPageButton.SetWindowPos(&wndTop, first.x, first.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
	mPriorPageButton.SetWindowPos(&wndTop, prior.x, prior.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
	mNextPageButton.SetWindowPos(&wndTop, next.x, next.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
	mLastPageButton.SetWindowPos(&wndTop, last.x, last.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
}


void CExample1View::UpdateStateNavButtons()
{
	mFirstPageButton.EnableWindow(GetDocument()->mCurRowN != 0);
	mLastPageButton.EnableWindow(GetDocument()->GetRecordCount() == cRowCountInPage); 
	mNextPageButton.EnableWindow(GetDocument()->GetRecordCount() == cRowCountInPage); 
	mPriorPageButton.EnableWindow(GetDocument()->mCurRowN != 0);
}


// CExample1View message handlers


int CExample1View::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CScrollView::OnCreate(lpCreateStruct) == -1)
		return -1;	


	// ������� ������ �������
	mFirstPageButton.Create(_T("First"), BS_PUSHBUTTON, CRect(0, 0, 76, 23), this, ID_NAVIGATION_FIRSTPAGE);
	mPriorPageButton.Create(_T("Prior"), BS_PUSHBUTTON, CRect(0, 0, 76, 23), this, ID_NAVIGATION_PRIORPAGE);
	mNextPageButton.Create(_T("Next"), BS_PUSHBUTTON, CRect(0, 0, 76, 23), this, ID_NAVIGATION_NEXTPAGE);
	mLastPageButton.Create(_T("Last"), BS_PUSHBUTTON, CRect(0, 0, 76, 23), this, ID_NAVIGATION_LASTPAGE);
	
	return 0;
}


HFONT CExample1View::SetFont(const LOGFONT& lf, CDC* pDC) 
{
	static HFONT hFont;
	CFont font;

	font.CreateFontIndirect(&lf);
	HFONT hOldFont = reinterpret_cast<HFONT>(pDC->SelectObject(&font));
	//TRACE(_T("hOldFont = %08X\n"), hOldFont);	
	
	if (hOldFont) ::DeleteObject(hOldFont);
	hFont = static_cast<HFONT>(font.Detach());
	//TRACE(_T("hFont = %08X\n"), hFont);
	return hOldFont;
}


void CExample1View::CalcColumnMaxWidths(LONG charWidth, int space)
{	
	CArray<int> widths;
	
	const int cFieldCount = GetDocument()->mSQLiteStatement->Fields();
	CString fieldName;

	// ��������� ����� �������� ����� �������
	for (int i = 0; i < cFieldCount; ++i)
	{
		fieldName = GetDocument()->mSQLiteStatement->FieldName(i);
		widths.Add(fieldName.GetLength());
	}

	CString fieldValue;

	// ��������� ����. ����� ������ ����� 
	while (GetDocument()->mSQLiteStatement->NextRow())
	{		
		for (int i = 0; i < cFieldCount; ++i)
		{
			fieldValue = GetDocument()->mSQLiteStatement->ValueString(i);
			int len = fieldValue.GetLength();

			if (widths[i] < len)	widths[i] = len;			
		}
	}

	// ��������� ����.������ ��������
	for (int i = 0; i < widths.GetCount(); ++i)
	{
		widths[i] *= charWidth;
		widths[i] += space;
	}	
	
	mColumnMaxWidths.RemoveAll();

	// ��������� ��������� 
	for (int i = 0; i < widths.GetCount(); ++i)
	{
		mColumnMaxWidths.Add(widths[i]);
	}	
}


void CExample1View::CalcRowMetrics()
{	
	CClientDC dc(this);
	dc.SetMapMode(mMapMode);

	LOGFONT lf{ 0 };
	//memset(&lf, 0, sizeof(LOGFONT));
	_tcscpy_s(lf.lfFaceName, mFontName);
	lf.lfHeight = -mFontSize * cPointInTwips;
	lf.lfWeight = mFontWeight;
	SetFont(lf, &dc);

	TEXTMETRIC tm{ 0 };
	//memset(&tm, 0, sizeof(TEXTMETRIC));
	dc.GetTextMetrics(&tm);

	// ������ ������ 
	mLineHeight = tm.tmHeight + tm.tmExternalLeading;

	// ������ �������	
	CalcColumnMaxWidths(tm.tmAveCharWidth);
	
	int totalWidth = 0;
	for (int i = 0; i < mColumnMaxWidths.GetCount(); ++i)
	{
		totalWidth += mColumnMaxWidths[i];
	}

	mTotalWidth = totalWidth;	
}


void CExample1View::DrawHeader(CDC* pDC, CPoint& pt)
{	
	// ����� ��������� �������
	LOGFONT lf{ 0 };
	//memset(&lf, 0, sizeof(LOGFONT));
	_tcscpy_s(lf.lfFaceName, mFontName);
	lf.lfHeight = -mFontSize * cPointInTwips;
	lf.lfWeight = mFontWeight;
	HFONT hOldFont = SetFont(lf, pDC);

	const int cFieldCount = GetDocument()->mSQLiteStatement->Fields();	
	CString fieldName;
	
	for (int i = 0; i < cFieldCount; ++i)
	{
		fieldName = GetDocument()->mSQLiteStatement->FieldName(i);
		fieldName.MakeUpper();
		pDC->TextOut(pt.x, pt.y, fieldName);
		pt.x += mColumnMaxWidths[i];
	}

	pDC->SelectObject(hOldFont);
}



void CExample1View::DrawFrame(CDC* pDC, CPoint& pt)
{	
	CPen pen;
	pen.CreatePen(PS_DOT, 1, RGB(0, 0, 0));
	CPen* pOldPen = pDC->SelectObject(&pen);

	pt.x = 0;
	pt.y -= mLineHeight;

	pDC->MoveTo(0, pt.y);
	pDC->LineTo(mTotalWidth, pt.y);
	//pDC->MoveTo(mColumnMaxWidths[0], 0);
	//pDC->LineTo(mColumnMaxWidths[0], -mLineHeight * (mRecordCount+3));

	pDC->SelectObject(pOldPen);
}


void CExample1View::DrawContent(CDC* pDC, CPoint& pt)
{		
	// �����  ������ 
	LOGFONT lf{ 0 };
	//memset(&lf, 0, sizeof(LOGFONT));
	_tcscpy_s(lf.lfFaceName, mFontName);
	lf.lfHeight = -(mFontSize - 2) * cPointInTwips;
	lf.lfWeight = FW_NORMAL;
	SetFont(lf, pDC);

	pt.y -= mLineHeight / 2;

	const int cFieldCount = GetDocument()->mSQLiteStatement->Fields();
	CString fieldValue;

	while (GetDocument()->mSQLiteStatement->NextRow())
	{
		for (int i = 0; i < cFieldCount; ++i)
		{
			fieldValue = GetDocument()->mSQLiteStatement->ValueString(i);
			// ���������� ������� ��������
			if (fieldValue != _T("(null)"))
				pDC->TextOut(pt.x, pt.y, fieldValue);

			pt.x += mColumnMaxWidths[i];
		}

		pt.x = 0;
		pt.y -= mLineHeight;
	}
}


void CExample1View::OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/)
{
	TRACE(_T("CExample1View::OnUpdate\n"));

	// ������������� ���������� ������� ����	

	CalcRowMetrics();
	TRACE(_T("columns count = %d\n"), mColumnMaxWidths.GetCount());

	int rowCount = GetDocument()->GetRecordCount();
	TRACE(_T("rows count = %d\n"), rowCount);

	// ���.������� ����	
	const int cX = mTotalWidth;
	const int cY = mLineHeight * (rowCount + 5);

	CSize sizeTotal(cX, cY);
	CSize sizePage(sizeTotal.cx / 2, sizeTotal.cy / 2);
	CSize sizeLine(sizeTotal.cx / 50, sizeTotal.cy / 50);

	SetScrollSizes(mMapMode, sizeTotal, sizePage, sizeLine);	
	Invalidate();

	//ScrollToPosition(CPoint(0, 0));	

	//CPoint pt(0, cY);
	//LayoutNavigationButtons(&dc, pt);	
	CPoint pt(0, 0);
	LayoutNavigationButtons(pt);
	UpdateStateNavButtons();	
}


void CExample1View::DrawTable(CDC* pDC, CPoint& pt)
{
	DrawHeader(pDC, pt);	
	DrawFrame(pDC, pt);		
	DrawContent(pDC, pt);
}


void CExample1View::OnFirstButton()
{		
	GetDocument()->mCurRowN = 0;
	GetDocument()->OnNewDocument();
	GetDocument()->UpdateAllViews(NULL);
}


void CExample1View::OnLastButton()
{
	int recCount = GetDocument()->GetAllRecordCount();	
	recCount -= recCount % cRowCountInPage;
	GetDocument()->mCurRowN = recCount;	
	GetDocument()->OnNewDocument();
	GetDocument()->UpdateAllViews(NULL);
}


void CExample1View::OnNextButton()
{
	GetDocument()->mCurRowN += cRowCountInPage;
	GetDocument()->OnNewDocument();
	GetDocument()->UpdateAllViews(NULL);
}


void CExample1View::OnPriorButton()
{
	GetDocument()->mCurRowN -= cRowCountInPage;
	GetDocument()->OnNewDocument();
	GetDocument()->UpdateAllViews(NULL);
}


void CExample1View::OnUpdateFirstButton(CCmdUI *pCmdUI)
{	
	pCmdUI->Enable(GetDocument()->mCurRowN != 0);
}


void CExample1View::OnUpdateLastButton(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(!(GetDocument()->GetRecordCount() < cRowCountInPage));
}


void CExample1View::OnUpdateNextButton(CCmdUI *pCmdUI)
{	
	pCmdUI->Enable(!(GetDocument()->GetRecordCount() < cRowCountInPage));
}


void CExample1View::OnUpdatePriorButton(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->mCurRowN != 0);
}

