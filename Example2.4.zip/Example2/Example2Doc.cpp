
// Example2Doc.cpp : implementation of the CExample2Doc class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "Example2.h"
#endif

#include "Example2Doc.h"
#include "Example2View.h"
#include "MainFrm.h"
#include <memory>
#include <propkey.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CExample2Doc

CExample2Doc* gDocumentPtr;

LPCTSTR gTableNames[]
{
	_T("albums"),
	_T("artists"),
	_T("tracks"),
	_T("media_types"),
	_T("genres"),
	_T("playlists"),
	_T("customers"),
	_T("employees"),
	_T("invoices")
};

LPCTSTR gQueries[]
{	
	/* albums */
	_T("SELECT al.albumId, al.title, ar.name artist FROM albums al ")
		_T(" INNER JOIN artists ar ON al.artistId = ar.artistId ")//_T(" INNER JOIN artists ar USING (artistId) ")
		_T(" ORDER BY %d ASC LIMIT %d OFFSET %d"),	
	/* artists */
	_T("SELECT ar.artistId, ar.name, COUNT(ar.artistId) 'albums count' FROM artists ar ")
		_T(" LEFT JOIN albums al ON ar.artistId = al.artistId ")
		_T(" GROUP BY ar.artistId ")		
		_T(" ORDER BY %d ASC LIMIT %d OFFSET %d"),	
	/* tracks */
	_T("SELECT t.trackId, t.name, a.title album, m.name 'media type', g.name genre, composer FROM tracks t ")
		_T(" LEFT JOIN albums a ON t.albumId = a.albumId ")
		_T(" INNER JOIN media_types m ON t.mediaTypeId = m.mediaTypeId ")
		_T(" LEFT JOIN genres g ON t.genreId = g.genreId ")
		_T(" ORDER BY %d ASC LIMIT %d OFFSET %d"),
	
	/* media_types */
	_T("SELECT m.mediaTypeId, m.name, COUNT(t.mediaTypeId) 'tracks count' FROM media_types m ")
		_T(" INNER JOIN tracks t ON m.mediaTypeId = t.mediaTypeId ")
		_T(" GROUP BY m.mediaTypeId")
		_T(" ORDER BY %d ASC LIMIT %d OFFSET %d"),		
	/* genres */
	_T("SELECT g.genreId, g.name, COUNT(t.genreId) 'tracks count' FROM genres g ")
		_T(" LEFT JOIN tracks t ON g.genreId = t.genreId ")
		_T(" GROUP BY g.genreId")
		_T(" ORDER BY %d ASC LIMIT %d OFFSET %d"),
	/* playlists  */
	_T("SELECT p.playlistId, p.name, COUNT(pt.trackId) 'tracks count' FROM playlists p ")
		_T(" LEFT JOIN playlist_track pt ON p.playlistId = pt.playlistId ")
		_T(" LEFT JOIN tracks t ON pt.trackId = t.trackId ")
		_T(" GROUP BY p.playlistId")
		_T(" ORDER BY %d ASC LIMIT %d OFFSET %d"),				
	/* customers */
	_T("SELECT customerId, lastName, firstName, company, city FROM customers ")
		_T(" ORDER BY %d ASC LIMIT %d OFFSET %d"),	
	/* employees */
	_T("SELECT employeeId, lastName, firstName, title, reportsTo, strftime('%%Y-%%m-%%d',birthDate) birthDate FROM employees ")
		_T(" ORDER BY %d ASC LIMIT %d OFFSET %d"),	
	/* invoices */
	_T("SELECT i.invoiceId, strftime('%%Y-%%m-%%d',i.invoiceDate) date, i.total, (c.lastName||', '||c.firstName) customer, c.city FROM invoices i ")
		_T(" INNER JOIN customers c ON i.customerId = c.customerId ")
		_T(" ORDER BY %d ASC LIMIT %d OFFSET %d"),
};


IMPLEMENT_DYNCREATE(CExample2Doc, CDocument)

BEGIN_MESSAGE_MAP(CExample2Doc, CDocument)
	ON_COMMAND(ID_TABLES_ALBUMS, &CExample2Doc::OnTablesAlbums)
	ON_COMMAND(ID_TABLES_CUSTOMERS, &CExample2Doc::OnTablesCustomers)
	ON_COMMAND(ID_TABLES_TRACKS, &CExample2Doc::OnTablesTracks)
	ON_COMMAND(ID_TABLES_ARTISTS, &CExample2Doc::OnTablesArtists)
	ON_COMMAND(ID_TABLES_EMPLOYEES, &CExample2Doc::OnTablesEmployees)
	ON_COMMAND(ID_TABLES_GENRES, &CExample2Doc::OnTablesGenres)	
	ON_COMMAND(ID_TABLES_INVOICES, &CExample2Doc::OnTablesInvoices)
	ON_COMMAND(ID_TABLES_MEDIATYPES, &CExample2Doc::OnTablesMediatypes)
	ON_COMMAND(ID_TABLES_PLAYLISTS, &CExample2Doc::OnTablesPlaylists)	
	ON_UPDATE_COMMAND_UI(ID_TABLES_ALBUMS, &CExample2Doc::OnUpdateTablesAlbums)
	ON_UPDATE_COMMAND_UI(ID_TABLES_ARTISTS, &CExample2Doc::OnUpdateTablesArtists)
	ON_UPDATE_COMMAND_UI(ID_TABLES_CUSTOMERS, &CExample2Doc::OnUpdateTablesCustomers)
	ON_UPDATE_COMMAND_UI(ID_TABLES_EMPLOYEES, &CExample2Doc::OnUpdateTablesEmployees)
	ON_UPDATE_COMMAND_UI(ID_TABLES_GENRES, &CExample2Doc::OnUpdateTablesGenres)	
	ON_UPDATE_COMMAND_UI(ID_TABLES_INVOICES, &CExample2Doc::OnUpdateTablesInvoices)
	ON_UPDATE_COMMAND_UI(ID_TABLES_MEDIATYPES, &CExample2Doc::OnUpdateTablesMediatypes)
	ON_UPDATE_COMMAND_UI(ID_TABLES_PLAYLISTS, &CExample2Doc::OnUpdateTablesPlaylists)	
	ON_UPDATE_COMMAND_UI(ID_TABLES_TRACKS, &CExample2Doc::OnUpdateTablesTracks)
END_MESSAGE_MAP()


// CExample2Doc construction/destruction

CExample2Doc::CExample2Doc()
	: mCurRowN(0)
	, mSortByN(1)
	, mMainFramePtr(nullptr)
{
	gDocumentPtr = this;
}

CExample2Doc::~CExample2Doc()
{
}

BOOL CExample2Doc::OnNewDocument()
{
	TRACE("OnNewDocument\n");
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)
	
	// ������������� ��������� �� ���������
	mMainFramePtr = gMainFramePtr;
	ASSERT(mMainFramePtr);

	// ������������� ������	
	mTableNameType = TableNameType::customers;
	ResetData();

	return TRUE;
}


int CExample2Doc::GetTotalRecordCount()
{
	// ����� ����� ������� �������� �������
	int totalRecords = 0;
	
	CString query;
	query.Format(_T("SELECT COUNT(*) FROM %s"), gTableNames[mTableNameType]);

	std::unique_ptr<CSqlStatement> stmt(theApp.mSQLiteDB.Statement(query));
	ASSERT(stmt);

	if (stmt->NextRow())
	{
		totalRecords = stmt->ValueInt(0);
	}

	TRACE("total records = %d\n", totalRecords);
	return totalRecords;
}


void CExample2Doc::LoadPartDataFromTable()
{ 	
	// ������ � ��	
	CString query;
	query.Format(gQueries[mTableNameType], 
		mSortByN, 
		sRowCountInPageConst,
		mCurRowN);

	std::unique_ptr<CSqlStatement> stmt(theApp.mSQLiteDB.Statement(query));
	ASSERT(stmt);

	// ��������� ��������� ������� � ��������� ����
	mTable.RemoveRecords();

	int fieldCount = stmt->Fields();
	CString fieldName, fieldValue;

	while (stmt->NextRow())
	{
		CRecord record;
		for (int i = 0; i < fieldCount; ++i)
		{
			fieldName = stmt->FieldName(i);
			fieldValue = stmt->ValueString(i);
			CField field(fieldName, fieldValue);
			record.AddField(field);
		}
		mTable.AddRecord(record);
	}

}


void CExample2Doc::ResetData()
{
	mCurRowN = 0;
	mSortByN = 1;
	mTotalRecords = GetTotalRecordCount();		

	mMainFramePtr->FillSortByCombo();
	mSortByN = mMainFramePtr->mSortByCombo.GetCurSel() + 1;

	LoadPartDataFromTable();	
}


// CExample2Doc serialization

void CExample2Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

#ifdef SHARED_HANDLERS

// Support for thumbnails
void CExample2Doc::OnDrawThumbnail(CDC& dc, LPRECT lprcBounds)
{
	// Modify this code to draw the document's data
	dc.FillSolidRect(lprcBounds, RGB(255, 255, 255));

	CString strText = _T("TODO: implement thumbnail drawing here");
	LOGFONT lf;

	CFont* pDefaultGUIFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	pDefaultGUIFont->GetLogFont(&lf);
	lf.lfHeight = 36;

	CFont fontDraw;
	fontDraw.CreateFontIndirect(&lf);

	CFont* pOldFont = dc.SelectObject(&fontDraw);
	dc.DrawText(strText, lprcBounds, DT_CENTER | DT_WORDBREAK);
	dc.SelectObject(pOldFont);
}

// Support for Search Handlers
void CExample2Doc::InitializeSearchContent()
{
	CString strSearchContent;
	// Set search contents from document's data. 
	// The content parts should be separated by ";"

	// For example:  strSearchContent = _T("point;rectangle;circle;ole object;");
	SetSearchContent(strSearchContent);
}

void CExample2Doc::SetSearchContent(const CString& value)
{
	if (value.IsEmpty())
	{
		RemoveChunk(PKEY_Search_Contents.fmtid, PKEY_Search_Contents.pid);
	}
	else
	{
		CMFCFilterChunkValueImpl *pChunk = NULL;
		ATLTRY(pChunk = new CMFCFilterChunkValueImpl);
		if (pChunk != NULL)
		{
			pChunk->SetTextValue(PKEY_Search_Contents, value, CHUNK_TEXT);
			SetChunkValue(pChunk);
		}
	}
}

#endif // SHARED_HANDLERS

// CExample2Doc diagnostics

#ifdef _DEBUG
void CExample2Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CExample2Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CExample2Doc commands



void CExample2Doc::OnTablesAlbums()
{
	TRACE("OnTablesAlbums\n");	
	mTableNameType = TableNameType::albums;
	ResetData();
	UpdateAllViews(NULL);
}



void CExample2Doc::OnTablesCustomers()
{
	TRACE("OnTablesCustomers\n");
	mTableNameType = TableNameType::customers;
	ResetData();
	UpdateAllViews(NULL);
}


void CExample2Doc::OnTablesTracks()
{
	TRACE("OnTablesTracks\n");
	mTableNameType = TableNameType::tracks;
	ResetData();
	UpdateAllViews(NULL);
}


void CExample2Doc::OnTablesArtists()
{
	TRACE("OnTablesArtists\n");
	mTableNameType = TableNameType::artists;
	ResetData();
	UpdateAllViews(NULL);
}


void CExample2Doc::OnTablesEmployees()
{
	TRACE("OnTablesEmployees\n");
	mTableNameType = TableNameType::employees;
	ResetData();
	UpdateAllViews(NULL);
}


void CExample2Doc::OnTablesGenres()
{
	TRACE("OnTablesGenres\n");
	mTableNameType = TableNameType::genres;
	ResetData();
	UpdateAllViews(NULL);
}



void CExample2Doc::OnTablesInvoices()
{
	TRACE("OnTablesInvoices\n");
	mTableNameType = TableNameType::invoices;
	ResetData();
	UpdateAllViews(NULL);
}


void CExample2Doc::OnTablesMediatypes()
{
	TRACE("OnTablesMediatypes\n");
	mTableNameType = TableNameType::mediaTypes;
	ResetData();
	UpdateAllViews(NULL);
}


void CExample2Doc::OnTablesPlaylists()
{
	TRACE("OnTablesPlaylists\n");
	mTableNameType = TableNameType::playlists;
	ResetData();
	UpdateAllViews(NULL);
}




void CExample2Doc::OnUpdateTablesAlbums(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio(mTableNameType == TableNameType::albums);
}


void CExample2Doc::OnUpdateTablesCustomers(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio(mTableNameType == TableNameType::customers);
}


void CExample2Doc::OnUpdateTablesArtists(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio(mTableNameType == TableNameType::artists);
}


void CExample2Doc::OnUpdateTablesTracks(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio(mTableNameType == TableNameType::tracks);
}


void CExample2Doc::OnUpdateTablesGenres(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio(mTableNameType == TableNameType::genres);
}


void CExample2Doc::OnUpdateTablesMediatypes(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio(mTableNameType == TableNameType::mediaTypes);
}


void CExample2Doc::OnUpdateTablesPlaylists(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio(mTableNameType == TableNameType::playlists);
}


void CExample2Doc::OnUpdateTablesEmployees(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio(mTableNameType == TableNameType::employees);
}


void CExample2Doc::OnUpdateTablesInvoices(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio(mTableNameType == TableNameType::invoices);
}
