#pragma once
#include "afxwin.h"

// �������� ����� ��������� � CEmployeeDlg
enum EmployeeType
{
	empEmployeeId,
	empLastName,
	empFirstName,
};

// CCustomerDlg dialog

class CCustomerDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CCustomerDlg)

public:
	CCustomerDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCustomerDlg();

// Dialog Data
	enum { IDD = IDD_CUSTOMER };

	enum CustomerType
	{
		firstName = 1,
		lastName,
		company,
		address,
		city,
		state,
		country,
		postalcode,
		phone,
		fax,
		email,
		supportRepId
	};	

	void LoadCustomerByID(int id);	
private:
	void FillSupportRepCombo();
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	CComboBox mSupportRepCombo;
	/*CEdit mLastNameEdit;
	CEdit mFirstNameEdit;
	CEdit mCompanyEdit;
	CEdit mAddressEdit;
	CEdit mCityEdit;
	CEdit mCoutryEdit;
	CEdit mEmailEdit;
	CEdit mFaxEdit;
	CEdit mPhoneEdit;
	CEdit mPostalCodeEdit;
	CEdit mStateEdit;*/
	CString mAddressValue;
	CString mCityValue;
	CString mCompanyValue;
	CString mCountryValue;
	CString mEmailValue;
	CString mFaxValue;
	CString mFirstNameValue;
	CString mLastNameValue;
	CString mPhoneValue;
	CString mPostalCodeValue;
	CString mStateValue;
	int mSupportRepValue;
	CStatic mPicture;
};
