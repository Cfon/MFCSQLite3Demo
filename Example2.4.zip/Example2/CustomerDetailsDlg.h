#pragma once


// CCustomerDetailsDlg dialog

class CCustomerDetailsDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CCustomerDetailsDlg)

public:
	CCustomerDetailsDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCustomerDetailsDlg();

// Dialog Data
	enum { IDD = IDD_CUSTOMER_DETAILS };

	int mID;

	void LoadCustomerByID(int id);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
};
