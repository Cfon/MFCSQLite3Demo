//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Example2.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_Example2TYPE                130
#define IDB_LOGO                        310
#define IDD_CUSTOMER                    312
#define IDD_ALBUM                       321
#define IDI_ALBUM                       322
#define IDI_CUSTOMER                    329
#define IDD_ARTIST                      332
#define IDI_ARTIST                      334
#define IDC_CUSTOMER_INVOICES_BUTTON    1054
#define IDC_CUSTOMER_FIRSTNAME_EDIT     1055
#define IDC_CUSTOMER_LASTNAME_EDIT      1056
#define IDC_CUSTOMER_COMPANY_EDIT       1057
#define IDC_CUSTOMER_ADDRESS_EDIT       1058
#define IDC_CUSTOMER_CITY_EDIT          1059
#define IDC_CUSTOMER_STATE_EDIT         1060
#define IDC_CUSTOMER_COUNTRY_EDIT       1061
#define IDC_CUSTOMER_POSTALCODE_EDIT    1062
#define IDC_CUSTOMER_PHONE_EDIT         1063
#define IDC_CUSTOMER_FAX_EDIT           1064
#define IDC_CUSTOMER_EMAIL_EDIT         1065
#define IDC_CUSTOMER_SUPPORTREP_COMBO   1066
#define IDC_CUSTOMER_NEW_BUTTON         1067
#define IDC_ALBUM_TITLE_EDIT            1080
#define IDC_ALBUM_ARTISTS_COMBO         1082
#define IDC_ALBUM_ADDTRACK_BUTTON       1084
#define IDC_ALBUM_TRACKS_LIST           1085
#define IDC_CUSTOMER_PICTURE            1086
#define IDC_ARTIST_NAME_EDIT            1087
#define IDC_ARTIST_ALBUMS_LIST          1088
#define IDC_ARTIST_PICTURE              1090
#define IDC_ARTIST_ALBUMCOUNT_EDIT      1091
#define IDC_SORTBY_COMBO                32771
#define ID_TABLES_ALBUMS                32772
#define ID_TABLES_ARTISTS               32773
#define ID_TABLES_TRACKS                32774
#define ID_TABLES_MEDIATYPES            32775
#define ID_TABLES_GENRES                32776
#define ID_TABLES_PLAYLISTS             32777
#define ID_TABLES_PLAYLISTTRACKS        32778
#define ID_TABLES_CUSTOMERS             32779
#define ID_TABLES_EMPLOYEES             32780
#define ID_TABLES_INVOICES              32781
#define ID_TABLES_INVOICEITEMS          32782
#define ID_NAVIGATION_NEXTPAGE          32785
#define ID_NAVIGATION_LASTPAGE          32786
#define ID_NAVIGATION_FIRSTPAGE         32787
#define ID_NAVIGATION_PRIORPAGE         32788

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        335
#define _APS_NEXT_COMMAND_VALUE         32789
#define _APS_NEXT_CONTROL_VALUE         1092
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
