
// Example2View.h : interface of the CExample2View class
//

#pragma once


#include <memory>


extern const int sRowCountInPageConst;


class CExample2View : public CScrollView
{
protected: // create from serialization only
	CExample2View();
	DECLARE_DYNCREATE(CExample2View)

// Attributes
public:
	CExample2Doc* GetDocument() const;

// Operations
public:

// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CExample2View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	int mMapMode;	// MM_TWIPS 
	int mFontSize;	// in points	
	CString mFontName;
	LONG mFontWeight;
	

	class Cell
	{
	public:
		Cell() : mRect(0, 0, 0, 0) {}
		Cell(const CPoint& topLeft, const CPoint& bottomRight)
		{
			mRect.SetRect(topLeft, bottomRight);
		}
		~Cell() {}
		const CPoint& TopLeft() const { return mRect.TopLeft(); }
		const CPoint& BottomRight() const { return mRect.BottomRight(); }
		void SetSize(const CRect& rect)
		{
			mRect = rect;
		}
		LONG left() const { return mRect.left; }
		LONG top() const { return mRect.top; }
		LONG right() const { return mRect.right; }
		LONG bottom() const { return mRect.bottom; }
		int Width() const { return mRect.Width(); }
		int Height() const { return mRect.Height(); }
		operator CRect() const { return mRect; }
		CString mValue;
	private:		
		CRect mRect;
	};


	class Row
	{
	public:
		Row() { /*mCells.Add(Cell()); */}
		~Row() {}
		
		void AddCell(const Cell& cell) { mCells.Add(cell); }
		int CellCount() const { return mCells.GetCount(); }
		const Row& operator=(const Row& row)
		{
			mCells.Copy(row.mCells);
			return *this;
		}
		const Cell& operator[](UINT index) const { return mCells[index]; }
		Cell& operator[](UINT index) { return mCells[index]; }
		int Height() const
		{
			return mCells[0].Height();
		}
		int Width() const
		{
			int width = 0;
			for (int k = 0; k < CellCount(); ++k)
			{
				width += mCells[k].Width();
			}
			return width;
		}
	private:
		Row(const Row&);
		CArray<Cell> mCells;
	};


	class Grid
	{
	public:
		Grid() 
		{
			/*mMaxWidthCells.Add(0);
			mRows.Add(Row());*/
		}
		~Grid() {}
		void AddRow(const Row& row) { mRows.Add(row); }
		void RemoveRows() { mRows.RemoveAll();/* mRows.Add(Row()); */}
		int RowCount() const { return mRows.GetCount(); }
		int CellCount() const { return mRows[0].CellCount(); }
		const Grid& operator=(const Grid& grid)
		{
			mRows.Copy(grid.mRows);
			return *this;
		}
		const Row& operator[](UINT index) const { return mRows[index]; }
		Row& operator[](UINT index) { return mRows[index]; }
		int Height() const
		{
			int height = 0;
			for (int i = 0; i < RowCount(); ++i)
			{
				height += mRows[i].Height();
			}
			return height;
		}
		int Width() const
		{
			int width = 0;
			for (int k = 0; k < mMaxWidthCells.GetCount(); ++k)
			{
				width += mMaxWidthCells[k];
			}
			return width;
		}
		CSize GetGridSize() const
		{
			CSize size(0, 0);			
			size.cx = Width();
			size.cy = Height();
			return size;
		}
		CPoint TopLeft() const
		{
			return CPoint(mRows[0][0].left(), mRows[0][0].top());
		}
		CPoint BottomRight() const
		{
			return CPoint(mRows[RowCount() - 1][CellCount() - 1].right(),
				mRows[RowCount() - 1][CellCount() - 1].bottom());
		}
		void RecalcMaxWidthCell(LONG charWidth, int space=100)
		{
			CArray<int> widths;
			for (int k = 0; k < CellCount(); ++k)
			{
				widths.Add(0);
			}

			CString value;
			for (int i = 0; i < RowCount(); ++i)
			{
				for (int k = 0; k < CellCount(); ++k)
				{
					value = mRows[i][k].mValue;
					int len = value.GetLength();
					int width = charWidth * len + space;
					
					if (widths[k] < width)
						widths[k] = width;
				}
			}
			
			mMaxWidthCells.Copy(widths);
		}	
		int GetMaxWidthCell(int index) const { return mMaxWidthCells[index]; }
	private:
		Grid(const Grid&);
		CArray<int> mMaxWidthCells;
		CArray<Row> mRows;
	};

	Grid mGrid;

	
	HFONT SetFont(CDC* pDC, const LOGFONT* lpLogFont);		
	void DrawGrid(CDC* pDC, CPoint pt);
	void DrawFrame(CDC* pDC, CPoint pt);

	void LayoutNavigationButtons(CPoint pt);
	void UpdateStateNavButtons();

	void ShowCustomerDlg(int custId);
	void ShowAlbumDlg(int albumId);
	void ShowArtistDlg(int artistId);
public:
	CButton mFirstPageButton,
		mPriorPageButton,
		mNextPageButton,
		mLastPageButton;

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
	virtual void OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/);
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnNavigationFirstpage();
	afx_msg void OnNavigationLastpage();
	afx_msg void OnNavigationNextpage();
	afx_msg void OnNavigationPriorpage();
	afx_msg void OnUpdateNavigationFirstpage(CCmdUI *pCmdUI);
	afx_msg void OnUpdateNavigationLastpage(CCmdUI *pCmdUI);
	afx_msg void OnUpdateNavigationNextpage(CCmdUI *pCmdUI);
	afx_msg void OnUpdateNavigationPriorpage(CCmdUI *pCmdUI);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
};

#ifndef _DEBUG  // debug version in Example2View.cpp
inline CExample2Doc* CExample2View::GetDocument() const
   { return reinterpret_cast<CExample2Doc*>(m_pDocument); }
#endif

