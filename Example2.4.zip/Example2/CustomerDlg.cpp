// CustomerDetailsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "CustomerDlg.h"
#include "afxdialogex.h"
#include <memory>


// CCustomerDlg dialog



const LPCTSTR gCustomerQuery =
	_T("SELECT customerId, firstName, lastName, ")
		_T(" company, address, city, state, country, ")
		_T(" postalcode, phone, fax, email, ")
		_T(" supportRepId FROM customers ")		
		_T(" WHERE customerId = %d");

const LPCTSTR gEmployeeQuery = 
	_T("SELECT employeeId, lastName, firstName FROM employees");	

IMPLEMENT_DYNAMIC(CCustomerDlg, CDialogEx)

CCustomerDlg::CCustomerDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CCustomerDlg::IDD, pParent)
	, mAddressValue(_T(""))
	, mCityValue(_T(""))
	, mCompanyValue(_T(""))
	, mCountryValue(_T(""))
	, mEmailValue(_T(""))
	, mFaxValue(_T(""))
	, mFirstNameValue(_T(""))
	, mLastNameValue(_T(""))
	, mPhoneValue(_T(""))
	, mPostalCodeValue(_T(""))
	, mStateValue(_T(""))
	, mSupportRepValue(0)
{

}

CCustomerDlg::~CCustomerDlg()
{
}

void CCustomerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CUSTOMER_SUPPORTREP_COMBO, mSupportRepCombo);
	/*DDX_Control(pDX, IDC_CUSTOMER_LASTNAME_EDIT, mLastNameEdit);
	DDX_Control(pDX, IDC_CUSTOMER_FIRSTNAME_EDIT, mFirstNameEdit);
	DDX_Control(pDX, IDC_CUSTOMER_COMPANY_EDIT, mCompanyEdit);
	DDX_Control(pDX, IDC_CUSTOMER_ADDRESS_EDIT, mAddressEdit);
	DDX_Control(pDX, IDC_CUSTOMER_CITY_EDIT, mCityEdit);
	DDX_Control(pDX, IDC_CUSTOMER_COUNTRY_EDIT, mCoutryEdit);
	DDX_Control(pDX, IDC_CUSTOMER_EMAIL_EDIT, mEmailEdit);
	DDX_Control(pDX, IDC_CUSTOMER_FAX_EDIT, mFaxEdit);
	DDX_Control(pDX, IDC_CUSTOMER_PHONE_EDIT, mPhoneEdit);
	DDX_Control(pDX, IDC_CUSTOMER_POSTALCODE_EDIT, mPostalCodeEdit);
	DDX_Control(pDX, IDC_CUSTOMER_STATE_EDIT, mStateEdit);*/
	DDX_Text(pDX, IDC_CUSTOMER_ADDRESS_EDIT, mAddressValue);
	DDX_Text(pDX, IDC_CUSTOMER_CITY_EDIT, mCityValue);
	DDX_Text(pDX, IDC_CUSTOMER_COMPANY_EDIT, mCompanyValue);
	DDX_Text(pDX, IDC_CUSTOMER_COUNTRY_EDIT, mCountryValue);
	DDX_Text(pDX, IDC_CUSTOMER_EMAIL_EDIT, mEmailValue);
	DDX_Text(pDX, IDC_CUSTOMER_FAX_EDIT, mFaxValue);
	DDX_Text(pDX, IDC_CUSTOMER_FIRSTNAME_EDIT, mFirstNameValue);
	DDX_Text(pDX, IDC_CUSTOMER_LASTNAME_EDIT, mLastNameValue);
	DDX_Text(pDX, IDC_CUSTOMER_PHONE_EDIT, mPhoneValue);
	DDX_Text(pDX, IDC_CUSTOMER_POSTALCODE_EDIT, mPostalCodeValue);
	DDX_Text(pDX, IDC_CUSTOMER_STATE_EDIT, mStateValue);
	DDX_CBIndex(pDX, IDC_CUSTOMER_SUPPORTREP_COMBO, mSupportRepValue);
	DDX_Control(pDX, IDC_CUSTOMER_PICTURE, mPicture);
}


void CCustomerDlg::LoadCustomerByID(int id)
{	
	CString query;
	query.Format(gCustomerQuery, id);

	std::unique_ptr<CSqlStatement> stmt(theApp.mSQLiteDB.Statement(query));
	ASSERT(stmt);

	if (stmt->NextRow())
	{
		CArray<CString, LPCTSTR> values;

		for (int k = 0; k < stmt->Fields(); ++k)
		{
			// ������� ������ ���� '(null)'
			if (CString(stmt->ValueString(k)) != _T("(null)"))
				values.Add(stmt->ValueString(k));
			else
				values.Add(_T(""));
		}

		mFirstNameValue = values[CustomerType::firstName];
		mAddressValue = values[CustomerType::address];
		mCityValue = values[CustomerType::city];
		mCompanyValue = values[CustomerType::company];
		mCountryValue = values[CustomerType::country];
		mEmailValue = values[CustomerType::email];
		mFaxValue = values[CustomerType::fax];
		mLastNameValue = values[CustomerType::lastName];
		mPhoneValue = values[CustomerType::phone];
		mPostalCodeValue = values[CustomerType::postalcode];
		mStateValue = values[CustomerType::state];
		mSupportRepValue = _ttoi(values[CustomerType::supportRepId]);
	}
}


void CCustomerDlg::FillSupportRepCombo()
{
	CString query;
	query.Format(gEmployeeQuery);

	std::unique_ptr<CSqlStatement> stmt(theApp.mSQLiteDB.Statement(query));
	ASSERT(stmt);

	while (stmt->NextRow())
	{
		CString value;
		value = CString(stmt->ValueString(EmployeeType::empLastName)) + _T(", ") 
			+ CString(stmt->ValueString(EmployeeType::empFirstName));
		mSupportRepCombo.AddString(value);
	}
}


BEGIN_MESSAGE_MAP(CCustomerDlg, CDialogEx)	
END_MESSAGE_MAP()


// CCustomerDlg message handlers


BOOL CCustomerDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	HICON hIcon = AfxGetApp()->LoadIcon(IDI_CUSTOMER);
	ASSERT(hIcon);
	SetIcon(hIcon, TRUE);

	hIcon = (HICON)LoadImage(AfxGetApp()->m_hInstance,
		MAKEINTRESOURCE(IDI_CUSTOMER), IMAGE_ICON, 128, 128, 0);
	ASSERT(hIcon);
	mPicture.SetIcon(hIcon);

	/*CFont font;
	LOGFONT lf{ 0 };
	_tcscpy_s(lf.lfFaceName, _T("Consolas"));
	lf.lfHeight = -12;
	lf.lfWeight = FW_NORMAL;
	font.CreateFontIndirect(&lf);

	for (int i = IDC_FIRSTNAME; i <= IDC_SUPPORTREP; ++i)
	{
		CStatic* pFirstName = static_cast<CStatic*>(GetDlgItem(i));
		pFirstName->SetFont(&font);		
	}
	font.Detach();*/
	
	FillSupportRepCombo();
	mSupportRepCombo.SetCurSel(mSupportRepValue-1);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

