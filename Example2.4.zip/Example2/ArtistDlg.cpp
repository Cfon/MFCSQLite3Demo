// ArtistDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "ArtistDlg.h"
#include "afxdialogex.h"
#include <memory>


// CArtistDlg dialog

LPCTSTR gArtistQuery = 
	_T("SELECT ar.artistId, ar.name, COUNT(ar.artistId) 'albums count' ")
	_T(" FROM artists ar ")
	_T(" LEFT JOIN albums al USING (artistId)")
	_T(" WHERE artistId = %d");


LPCTSTR gAlbumsQuery =
	_T("SELECT albumId, title FROM albums")
	_T(" WHERE artistId = %d");


IMPLEMENT_DYNAMIC(CArtistDlg, CDialogEx)

CArtistDlg::CArtistDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_ARTIST, pParent)
	, mArtistName(_T(""))
	, mAlbumCount(0)
	, mArtistId(0)
{

}

CArtistDlg::~CArtistDlg()
{
}

void CArtistDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ARTIST_PICTURE, mPicture);
	DDX_Text(pDX, IDC_ARTIST_NAME_EDIT, mArtistName);
	DDX_Control(pDX, IDC_ARTIST_ALBUMS_LIST, mAlbumsList);
	DDX_Text(pDX, IDC_ARTIST_ALBUMCOUNT_EDIT, mAlbumCount);
}


void CArtistDlg::LoadArtistByID(int artistId)
{
	CString query;
	query.Format(gArtistQuery, artistId);

	std::unique_ptr<CSqlStatement> stmt(theApp.mSQLiteDB.Statement(query));
	ASSERT(stmt);

	if (stmt->NextRow())
	{
		CArray<CString, LPCTSTR> values;

		for (int k = 0; k < stmt->Fields(); ++k)
		{
			// ������� ������ ���� '(null)'
			if (CString(stmt->ValueString(k)) != _T("(null)"))
				values.Add(stmt->ValueString(k));
			else
				values.Add(_T(""));
		}

		mArtistId = _ttoi(values[ArtistType::artistId]);
		mArtistName = values[ArtistType::artistName];
		mAlbumCount = _ttoi(values[ArtistType::albumsCount]);
	}
}


void CArtistDlg::FillAlbumsList(int artistId)
{
	CString query;
	query.Format(gAlbumsQuery, artistId);

	std::unique_ptr<CSqlStatement> stmt(theApp.mSQLiteDB.Statement(query));
	ASSERT(stmt);

	/* ������� ��������� ������� */
	CString fieldName;
	fieldName = _T("#");
	mAlbumsList.InsertColumn(0, fieldName);
	mAlbumsList.SetColumnWidth(0, 60);

	for (int k = 1; k < stmt->Fields(); ++k)
	{				
		fieldName = stmt->FieldName(k);
		mAlbumsList.InsertColumn(k, fieldName);
		mAlbumsList.SetColumnWidth(k, 300);	
	}

	/* ������� ������ � ������� */
	LVITEM lv;
	lv.mask = LVIF_TEXT;

	CString value, id;
	int i = 0;
	while (stmt->NextRow())
	{
		lv.iItem = i;
		lv.iSubItem = 0;		
		id.Format(_T("%d"), i + 1);
		lv.pszText = id.GetBuffer(id.GetLength());
		mAlbumsList.InsertItem(&lv);

		for (int k = 1; k < stmt->Fields(); ++k)
		{				
			lv.iSubItem = k;
			value = stmt->ValueString(k);
			lv.pszText = value.GetBuffer(value.GetLength());
			mAlbumsList.SetItem(&lv);
		}
		++i;
	}
}


BEGIN_MESSAGE_MAP(CArtistDlg, CDialogEx)
END_MESSAGE_MAP()


// CArtistDlg message handlers


BOOL CArtistDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	HICON hIcon = AfxGetApp()->LoadIcon(IDI_ARTIST);
	ASSERT(hIcon);
	SetIcon(hIcon, TRUE);

	hIcon = (HICON)LoadImage(AfxGetApp()->m_hInstance,
		MAKEINTRESOURCE(IDI_ARTIST), IMAGE_ICON, 128, 128, 0);
	ASSERT(hIcon);
	mPicture.SetIcon(hIcon);

	mAlbumsList.SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT);
	FillAlbumsList(mArtistId);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}
