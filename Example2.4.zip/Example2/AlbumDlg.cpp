// AlbumDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "AlbumDlg.h"
#include "afxdialogex.h"
#include <memory>


// CAlbumDlg dialog


const LPCTSTR gAlbumQuery = 
	_T("SELECT albumId, title, artistId FROM albums ")
	_T(" WHERE albumId = %d");

const LPCTSTR gArtistsQuery =
	_T("SELECT artistId, name FROM artists");

const LPCTSTR gTracksQuery = 
	_T("SELECT trackId,	name, genreId, composer, unitPrice ")
	_T(" FROM tracks WHERE albumId = %d");

IMPLEMENT_DYNAMIC(CAlbumDlg, CDialogEx)

CAlbumDlg::CAlbumDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CAlbumDlg::IDD, pParent)	
	, mArtistId(0)
	, mTitle(_T(""))
	, mAlbumId(0)
{

}

CAlbumDlg::~CAlbumDlg()
{
}

void CAlbumDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ALBUM_ARTISTS_COMBO, mArtistsCombo);
	DDX_Control(pDX, IDC_ALBUM_TRACKS_LIST, mTracksList);	
	DDX_CBIndex(pDX, IDC_ALBUM_ARTISTS_COMBO, mArtistId);
	DDX_Text(pDX, IDC_ALBUM_TITLE_EDIT, mTitle);
}


void CAlbumDlg::LoadAlbumByID(int albumId)
{
	CString query;
	query.Format(gAlbumQuery, albumId);

	std::unique_ptr<CSqlStatement> stmt(theApp.mSQLiteDB.Statement(query));
	ASSERT(stmt);

	if (stmt->NextRow())
	{
		CArray<CString, LPCTSTR> values;

		for (int k = 0; k < stmt->Fields(); ++k)
		{
			// ������� ������ ���� '(null)'
			if (CString(stmt->ValueString(k)) != _T("(null)"))
				values.Add(stmt->ValueString(k));
			else
				values.Add(_T(""));
		}

		mAlbumId = _ttoi(values[AlbumType::albumId]);
		mTitle = values[AlbumType::title];
		mArtistId = _ttoi(values[AlbumType::artistId]);		
	}
}


void CAlbumDlg::FillArtistsCombo()
{
	CString query;
	query.Format(gArtistsQuery);

	std::unique_ptr<CSqlStatement> stmt(theApp.mSQLiteDB.Statement(query));
	ASSERT(stmt);

	while (stmt->NextRow())
	{		
		CString value;
		value = stmt->ValueString(ArtistType::artistName);
		mArtistsCombo.AddString(value);
	}
}


void CAlbumDlg::FillTracksList(int albumId)
{	
	CString query;
	query.Format(gTracksQuery, albumId);

	std::unique_ptr<CSqlStatement> stmt(theApp.mSQLiteDB.Statement(query));
	ASSERT(stmt);

	/* ������� ��������� ������� */
	CString fieldName;
	fieldName = _T("#");	
	mTracksList.InsertColumn(0, fieldName);
	mTracksList.SetColumnWidth(0, 60);

	for (int k = 1; k < stmt->Fields(); ++k)
	{
		fieldName = stmt->FieldName(k);				
		mTracksList.InsertColumn(k, fieldName);
		mTracksList.SetColumnWidth(k, 60);
	}

	/* ������� ������ � ������� */
	LVITEM lv;
	lv.mask = LVIF_TEXT;

	CString value, id;	
	int i = 0;
	while (stmt->NextRow())
	{
		lv.iItem = i;
		lv.iSubItem = 0;		
		id.Format(_T("%d"), i + 1);
		lv.pszText = id.GetBuffer(id.GetLength());
		mTracksList.InsertItem(&lv);		

		for (int k = 1; k < stmt->Fields(); ++k)
		{				
			lv.iSubItem = k;
			value = stmt->ValueString(k);
			lv.pszText = value.GetBuffer(value.GetLength());
			mTracksList.SetItem(&lv);
		}	
		++i;
	}
}


BEGIN_MESSAGE_MAP(CAlbumDlg, CDialogEx)
END_MESSAGE_MAP()


// CAlbumDlg message handlers


BOOL CAlbumDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	HICON hIcon = AfxGetApp()->LoadIcon(IDI_ALBUM);
	ASSERT(hIcon);
	SetIcon(hIcon, TRUE);

	mTracksList.SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT);	
	
	FillArtistsCombo();
	mArtistsCombo.SetCurSel(mArtistId - 1);
	FillTracksList(mAlbumId);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
