#pragma once
#include "afxwin.h"
#include "afxcmn.h"


// CArtistDlg dialog

class CArtistDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CArtistDlg)

public:
	CArtistDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CArtistDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ARTIST };
#endif

	enum ArtistType
	{
		artistId,
		artistName, // name
		albumsCount // COUNT(ar.artistId)
	};

	enum AlbumsType
	{
		albumId,
		title,
	};

	void LoadArtistByID(int artistId);
private:
	void FillAlbumsList(int artistId);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	CStatic mPicture;
	CString mArtistName;
	CListCtrl mAlbumsList;
	int mAlbumCount;
	int mArtistId;
};
