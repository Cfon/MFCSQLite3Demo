#pragma once
//#include "afxwin.h"
//#include "afxcmn.h"
#include "CustomDlg.h"


// CArtistDlg dialog

class CArtistDlg : public CCustomDlg
{
	DECLARE_DYNAMIC(CArtistDlg)

public:
	CArtistDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CArtistDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ARTIST };
#endif

	virtual void InitDialog(int artistId) override;
	virtual void SetControls(const CArrayStr& values, int id) override;

private:
	//void FillAlbumsList(int artistId);

protected:	
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	CStatic mPicture;
	CString mArtistName;
	CListCtrl mAlbumsList;
	int mAlbumCount;
	int mArtistId;
};


class ArtistDlgFactory : public CustomDlgFactory
{
public:
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg()
	{
		std::unique_ptr<CCustomDlg> dlg(new CArtistDlg);
		return dlg;
	}
};