#pragma once
//#include "afxwin.h"
//#include "afxcmn.h"
#include "CustomDlg.h"


// CAlbumDlg dialog

class CAlbumDlg : public CCustomDlg
{
	DECLARE_DYNAMIC(CAlbumDlg)

public:
	CAlbumDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CAlbumDlg();

// Dialog Data
	enum { IDD = IDD_ALBUM };

	virtual void InitDialog(int albumId) override;
	virtual void SetControls(const CArrayStr& values, int albumId) override;

private:	
	//void FillTracksList(int albumId);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	CComboBox mArtistsCombo;
	CListCtrl mTracksList;
	int mArtistId;
	CString mTitle;
	int mAlbumId;
};


class AlbumDlgFactory : public CustomDlgFactory
{
public:
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg()
	{
		std::unique_ptr<CCustomDlg> dlg(new CAlbumDlg);
		return dlg;
	}
};
