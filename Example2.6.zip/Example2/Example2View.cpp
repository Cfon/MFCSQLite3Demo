
// Example2View.cpp : implementation of the CExample2View class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "Example2.h"
#endif

#include "Example2Doc.h"
#include "Example2View.h"
#include "MainFrm.h"
#include "CustomerDlg.h"
#include "AlbumDlg.h"
#include "ArtistDlg.h"
#include "TrackDlg.h"
#include "PlaylistDlg.h"
#include <memory>


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CExample2View

static const int sRowCountInPageConst = 50;


IMPLEMENT_DYNCREATE(CExample2View, CScrollView)

BEGIN_MESSAGE_MAP(CExample2View, CScrollView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CScrollView::OnFilePrintPreview)
	ON_WM_CREATE()
	ON_COMMAND(ID_NAVIGATION_FIRSTPAGE, &CExample2View::OnNavigationFirstpage)
	ON_COMMAND(ID_NAVIGATION_LASTPAGE, &CExample2View::OnNavigationLastpage)
	ON_COMMAND(ID_NAVIGATION_NEXTPAGE, &CExample2View::OnNavigationNextpage)
	ON_COMMAND(ID_NAVIGATION_PRIORPAGE, &CExample2View::OnNavigationPriorpage)
	ON_UPDATE_COMMAND_UI(ID_NAVIGATION_FIRSTPAGE, &CExample2View::OnUpdateNavigationFirstpage)
	ON_UPDATE_COMMAND_UI(ID_NAVIGATION_LASTPAGE, &CExample2View::OnUpdateNavigationLastpage)
	ON_UPDATE_COMMAND_UI(ID_NAVIGATION_NEXTPAGE, &CExample2View::OnUpdateNavigationNextpage)
	ON_UPDATE_COMMAND_UI(ID_NAVIGATION_PRIORPAGE, &CExample2View::OnUpdateNavigationPriorpage)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_SETCURSOR()
END_MESSAGE_MAP()

// CExample2View construction/destruction

CExample2View::CExample2View()
	: mMapMode(MM_TWIPS)
	, mFontSize(10)
	, mFontName(_T("Consolas"))
	, mFontWeight(FW_BOLD)
{
	// TODO: add construction code here	
}

CExample2View::~CExample2View()
{
}

BOOL CExample2View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	cs.style |= WS_CLIPCHILDREN | WS_CLIPSIBLINGS;

	return CScrollView::PreCreateWindow(cs);
}

// CExample2View drawing

void CExample2View::OnDraw(CDC* pDC)
{
	//TRACE("OnDraw\n");
	/*CExample2Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;*/	

	// ��������� ����� ������
	CPoint pt(100, -100);

	DrawFrame(pDC, pt);
	DrawGrid(pDC, pt);
}

void CExample2View::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();	

	//CSize sizeTotal;
	//// TODO: calculate the total size of this view
	//sizeTotal.cx = sizeTotal.cy = 100;
	//SetScrollSizes(MM_TEXT, sizeTotal);
}


// CExample2View printing

BOOL CExample2View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CExample2View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CExample2View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}


// CExample2View diagnostics

#ifdef _DEBUG
void CExample2View::AssertValid() const
{
	CScrollView::AssertValid();
}

void CExample2View::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CExample2Doc* CExample2View::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CExample2Doc)));
	return (CExample2Doc*)m_pDocument;
}
#endif //_DEBUG


HFONT CExample2View::SetFont(CDC* pDC, const LOGFONT* lpLogFont)
{
	static HFONT hOldFont;
	//static HGDIOBJ hOldFont;

	CFont font;
	font.CreateFontIndirect(lpLogFont);

	if (hOldFont)
		::DeleteObject(hOldFont);

	hOldFont = reinterpret_cast<HFONT>(pDC->SelectObject(&font));
	//hOldFont = static_cast<HGDIOBJ>(pDC->SelectObject(&font));
	//TRACE("hOldFont = %08X\n", hOldFont);	

	HFONT hFont = static_cast<HFONT>(font.Detach());
	//TRACE("hFont = %08X\n", hFont);

	return hOldFont;
}


void CExample2View::DrawGrid(CDC* pDC, CPoint pt)
{
	// ����� ��������� �������
	LOGFONT lf{ 0 };
	_tcscpy_s(lf.lfFaceName, mFontName);
	lf.lfHeight = -mFontSize * 20;
	lf.lfWeight = mFontWeight;
	HFONT hOldFont = SetFont(pDC, &lf);

	int cellCount = mGrid.CellCount();
	int rowCount = mGrid.RowCount();
	CString value;

	for (int k = 0; k < cellCount; ++k)
	{
		value = mGrid[0][k].mValue;
		value.MakeUpper();
		pDC->TextOut(mGrid[0][k].left() + pt.x, mGrid[0][k].top() + pt.y, value);
	}

	pDC->SelectObject(hOldFont);

	// ����� ����������� �������
	lf.lfHeight = -(mFontSize - 2) * 20;
	lf.lfWeight = FW_NORMAL;
	hOldFont = SetFont(pDC, &lf);

	for (int i = 1; i < rowCount; ++i)
	{
		for (int k = 0; k < cellCount; ++k)
		{
			value = mGrid[i][k].mValue;
			// ���������� ������� ��������
			if (value != _T("(null)"))
				pDC->TextOut(mGrid[i][k].left() + pt.x,
					mGrid[i][k].top() + pt.y, value);
		}
	}

	pDC->SelectObject(hOldFont);
}


void CExample2View::DrawFrame(CDC* pDC, CPoint pt)
{	
	const int dx = 70;
	CPen pen;
	pen.CreatePen(PS_SOLID, 1, RGB(0, 0, 0));
	CPen* pOldPen = pDC->SelectObject(&pen);
	
	CSize gridSize = mGrid.GetGridSize();
	CPoint topLeft = mGrid.TopLeft();
	CPoint bottomRight = mGrid.BottomRight();	

	// ����� ������ �������
	pDC->MoveTo(pt.x - dx, topLeft.y + pt.y + dx);
	pDC->LineTo(bottomRight.x + pt.x + 200, topLeft.y + pt.y + dx);
	pDC->LineTo(bottomRight.x + pt.x + 200, bottomRight.y + pt.y);
	pDC->LineTo(topLeft.x + pt.x - dx, bottomRight.y + pt.y);
	pDC->LineTo(pt.x - dx, topLeft.y + pt.y + dx);

	// ����� ��� ���������� �������
	pDC->MoveTo(pt.x - dx, mGrid[0][0].bottom() + pt.y);
	pDC->LineTo(bottomRight.x + pt.x + 200, mGrid[0][0].bottom() + pt.y);

	// ������� ���������
	/*CBrush brush;
	brush.CreateSolidBrush(RGB(255, 255, 0));
	CBrush* pOldBrush = pDC->SelectObject(&brush);
	CRect rc(pt.x - dx, pt.y, pt.x + mTotalWidth - dx, pt.y - mRowHeight);
	pDC->FillRect(rc, &brush);
	pDC->SelectObject(pOldBrush);*/

	// ������������ ��������
	int cx = 0;
	for (int k = 0; k < mGrid.CellCount()-1; ++k)
	{
		cx += mGrid[0][k].Width();	
		pDC->MoveTo(cx + pt.x - dx, pt.y + dx);
		pDC->LineTo(cx + pt.x - dx, bottomRight.y + pt.y);
	}

	pDC->SelectObject(pOldPen);
}


void CExample2View::LayoutNavigationButtons(CPoint pt)
{
	// ����������� ������ ���������	

	int mapMode;
	CSize totalSize, pageSize, lineSize;
	GetDeviceScrollSizes(mapMode, totalSize, pageSize, lineSize);

	CPoint scrlPos = GetDeviceScrollPosition();	

	const CSize buttonSize(76, 23);
	int cx = pt.x - scrlPos.x;
	int cy = pt.y + totalSize.cy - scrlPos.y - buttonSize.cy;

	CPoint first(cx, cy);
	CPoint prior(first.x + buttonSize.cx, cy);
	CPoint next(prior.x + buttonSize.cx, cy);
	CPoint last(next.x + buttonSize.cx, cy);

	mFirstPageButton.SetWindowPos(&wndTop, first.x, first.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
	mPriorPageButton.SetWindowPos(&wndTop, prior.x, prior.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
	mNextPageButton.SetWindowPos(&wndTop, next.x, next.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
	mLastPageButton.SetWindowPos(&wndTop, last.x, last.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);	
}


void CExample2View::UpdateStateNavButtons()
{
	mFirstPageButton.EnableWindow(GetDocument()->mCurRowN != 0);
	mLastPageButton.EnableWindow(GetDocument()->mTable.RecordCount() == sRowCountInPageConst);
	mNextPageButton.EnableWindow(GetDocument()->mTable.RecordCount() == sRowCountInPageConst);
	mPriorPageButton.EnableWindow(GetDocument()->mCurRowN != 0);
}


void CExample2View::ShowCustomDlg(int id)
{
	TRACE("ShowCustomDlg\n");

	ASSERT(GetDocument()->mDlgFactory);
	if (!GetDocument()->mDlgFactory) return;

	std::unique_ptr<CCustomDlg> dlg =
		GetDocument()->mDlgFactory->CreateCustomDlg();

	ASSERT(dlg); // for me  
	if (!dlg) return; // for user

	dlg->InitDialog(id);

	if (dlg->DoModal() == IDOK)
	{
		// TODO: ��������� ����� ������
	}	
}


// CExample2View message handlers


void CExample2View::OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/)
{
	TRACE("OnUpdate\n");	
	// ������������� ������� �����	

	CClientDC dc(this);
	dc.SetMapMode(mMapMode);

	LOGFONT lf{ 0 };
	_tcscpy_s(lf.lfFaceName, mFontName);
	lf.lfHeight = -mFontSize * 20;
	lf.lfWeight = mFontWeight;
	HFONT hOldFont = SetFont(&dc, &lf);

	TEXTMETRIC tm{ 0 };
	dc.GetTextMetrics(&tm);
	dc.SelectObject(hOldFont);

	// ������ ������ 
	CSize buttonSize(76, 23);
	dc.DPtoLP(&buttonSize);
	int rowHeight = tm.tmHeight + tm.tmExternalLeading;
	if (rowHeight < buttonSize.cy)
		rowHeight = buttonSize.cy;	

	int fieldCount = GetDocument()->mTable.FieldCount();
	mGrid.RemoveRows();

	// ������ ���������
	Row row;
	for (int k = 0; k < fieldCount; ++k)
	{		
		Cell cell;
		cell.mValue = GetDocument()->mTable[0][k].FieldName();
		row.AddCell(cell);
	}

	// ��������� ������ ���������
	mGrid.AddRow(row);

	// ��������� ������ ������
	int recordCount = GetDocument()->mTable.RecordCount();
	for (int i = 0; i < recordCount; ++i)
	{
		Row row;		
		for (int k = 0; k < fieldCount; ++k)
		{
			Cell cell;
			cell.mValue = GetDocument()->mTable[i][k].FieldValue();
			row.AddCell(cell);
		}
		// ��������� ������ 
		mGrid.AddRow(row);
	}

	mGrid.RecalcMaxWidthCell(tm.tmAveCharWidth);

	// ������������� ��������� �����
	CPoint topLeft(0, 0), bottomRight(0, -rowHeight);

	for (int k = 0; k < mGrid.CellCount(); ++k)
	{		
		bottomRight.x += mGrid.GetMaxWidthCell(k);	
		mGrid[0][k].SetSize(CRect(topLeft, bottomRight));
		topLeft.x += mGrid.GetMaxWidthCell(k);
	}

	TRACE("row count = %d\n", mGrid.RowCount());
	TRACE("cell count = %d\n", mGrid.CellCount());
	
	topLeft.y -= rowHeight * 1.5;
	bottomRight.y = topLeft.y - rowHeight;

	for (int i = 1; i < mGrid.RowCount(); ++i)
	{				
		topLeft.x = 0;
		bottomRight.x = -rowHeight;

		for (int k = 0; k < mGrid.CellCount(); ++k)
		{
			bottomRight.x += mGrid.GetMaxWidthCell(k);
			bottomRight.y = topLeft.y - rowHeight;
			CRect rect(topLeft, bottomRight);			
			mGrid[i][k].SetSize(rect);
			topLeft.x += mGrid.GetMaxWidthCell(k);
		}
		
		topLeft.y -= rowHeight;
	}

	TRACE("grid width = %d\n", mGrid.Width());
	TRACE("grid height = %d\n", mGrid.Height());

	// ���.������� ����		
	const int cx = mGrid.Width() + 500;
	const int cy = mGrid.Height() + mGrid[0].Height()/2 - 500;	

	CSize sizeTotal(cx, -cy);
	CSize sizePage(sizeTotal.cx / 2, sizeTotal.cy / 2);
	CSize sizeLine(sizeTotal.cx / 50, sizeTotal.cy / 50);

	SetScrollSizes(mMapMode, sizeTotal, sizePage, sizeLine);
	Invalidate();
	
	// ����� ������
	CPoint pt(0, 0);
	LayoutNavigationButtons(pt);
	UpdateStateNavButtons();
	
	//CalcGridMetrics();
}



int CExample2View::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CScrollView::OnCreate(lpCreateStruct) == -1)
		return -1;

	// ������� ������ �������
	mFirstPageButton.Create(_T("First"), BS_PUSHBUTTON, CRect(0, 0, 76, 23), this, ID_NAVIGATION_FIRSTPAGE);
	mPriorPageButton.Create(_T("Prior"), BS_PUSHBUTTON, CRect(0, 0, 76, 23), this, ID_NAVIGATION_PRIORPAGE);
	mNextPageButton.Create(_T("Next"), BS_PUSHBUTTON, CRect(0, 0, 76, 23), this, ID_NAVIGATION_NEXTPAGE);
	mLastPageButton.Create(_T("Last"), BS_PUSHBUTTON, CRect(0, 0, 76, 23), this, ID_NAVIGATION_LASTPAGE);

	CFont font;
	LOGFONT lf{ 0 };
	_tcscpy_s(lf.lfFaceName, _T("Consolas"));
	lf.lfHeight = -12;
	lf.lfWeight = FW_SEMIBOLD;
	font.CreateFontIndirect(&lf);
	mFirstPageButton.SetFont(&font);
	mPriorPageButton.SetFont(&font);
	mNextPageButton.SetFont(&font);
	mLastPageButton.SetFont(&font);
	font.Detach();

	return 0;
}


void CExample2View::OnNavigationFirstpage()
{
	TRACE("OnNavigationFirstpage\n");
	GetDocument()->mCurRowN = 0;
	GetDocument()->LoadPartDataFromTable();
	GetDocument()->UpdateAllViews(NULL);
}


void CExample2View::OnNavigationLastpage()
{
	TRACE("OnNavigationLastpage\n");	
	int recCount = GetDocument()->mTotalRecords;
	recCount -= recCount % sRowCountInPageConst;
	GetDocument()->mCurRowN = recCount;
	GetDocument()->LoadPartDataFromTable();
	GetDocument()->UpdateAllViews(NULL);
}


void CExample2View::OnNavigationNextpage()
{
	TRACE("OnNavigationNextpage\n");
	GetDocument()->mCurRowN += sRowCountInPageConst;
	GetDocument()->LoadPartDataFromTable();
	GetDocument()->UpdateAllViews(NULL);
}


void CExample2View::OnNavigationPriorpage()
{
	TRACE("OnNavigationPriorpage\n");
	GetDocument()->mCurRowN -= sRowCountInPageConst;
	GetDocument()->LoadPartDataFromTable();
	GetDocument()->UpdateAllViews(NULL);
}


void CExample2View::OnUpdateNavigationFirstpage(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->mCurRowN != 0);
}


void CExample2View::OnUpdateNavigationLastpage(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->mTable.RecordCount() == sRowCountInPageConst);
}


void CExample2View::OnUpdateNavigationNextpage(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->mTable.RecordCount() == sRowCountInPageConst);
}


void CExample2View::OnUpdateNavigationPriorpage(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->mCurRowN != 0);
}


void CExample2View::OnMouseMove(UINT nFlags, CPoint point)
{		
	CPoint scrlPos = GetDeviceScrollPosition();
	point.Offset(scrlPos);	

	//TODO: OnMouseMove
	//TRACE("(%d, %d)\n", point.x, point.y);

	CScrollView::OnMouseMove(nFlags, point);
}


void CExample2View::OnLButtonDown(UINT nFlags, CPoint point)
{	
	CClientDC dc(this);
	dc.SetMapMode(mMapMode);
	dc.DPtoLP(&point);
	CPoint scrlPos = GetScrollPosition();
	point.Offset(scrlPos);
	
	// ���� ������ ������ ������� ��� ������ ���� �����
	CRect rect;	
	int indexRow = -1;
	for (int i = 0; i < mGrid.RowCount(); ++i)
	{
		for (int k = 0; k < mGrid.CellCount(); ++k)
		{
			rect = mGrid[i][k];
			rect.NormalizeRect();

			if (rect.PtInRect(point))
			{
				// �����
				indexRow = i;				
				break;
			}
		}

		// ������������� ����������� �����
		if (indexRow != -1)
			break;
	}

	if (indexRow != -1)
	{
		// ������ id
		CString value = mGrid[indexRow][0].mValue;
		int id = _ttoi(value);
		TRACE("id = %d\n", id);

		// �������� ������ ������
		ShowCustomDlg(id);		
	}	

	CScrollView::OnLButtonDown(nFlags, point);
}


BOOL CExample2View::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{

	::SetCursor(AfxGetApp()->LoadStandardCursor(IDC_HAND));
	return TRUE;

	//return CScrollView::OnSetCursor(pWnd, nHitTest, message);
}


void CExample2View::OnPrepareDC(CDC* pDC, CPrintInfo* pInfo)
{	
	//TRACE("OnPrepareDC\n");

	CScrollView::OnPrepareDC(pDC, pInfo);
}
