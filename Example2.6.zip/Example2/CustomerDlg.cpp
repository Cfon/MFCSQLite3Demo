// CustomerDetailsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "CustomerDlg.h"
//#include "afxdialogex.h"
#include <memory>


// CCustomerDlg dialog


enum CustomerType
{
	customerId, firstName, lastName, 
	company, address, city, state, country, 
	postalcode, phone, fax, email, supportRepId
};

static LPCTSTR gCustomerQuery 
{
	_T("SELECT customerId, firstName, lastName, ")
	_T(" company, address, city, state, country, ")
	_T(" postalcode, phone, fax, email, supportRepId ")
	_T(" FROM customers ")
	_T(" WHERE customerId = %d") 
};


enum EmployeeType {	employeeId, lastName_, firstName_ };

static LPCTSTR gEmployeeQuery 
{
	_T("SELECT employeeId, lastName, firstName FROM employees") 
};


IMPLEMENT_DYNAMIC(CCustomerDlg, CCustomDlg)

CCustomerDlg::CCustomerDlg(CWnd* pParent /*=NULL*/)
	: CCustomDlg(CCustomerDlg::IDD, pParent)
	, mCustomerId(0)
	, mAddressValue(_T(""))
	, mCityValue(_T(""))
	, mCompanyValue(_T(""))
	, mCountryValue(_T(""))
	, mEmailValue(_T(""))
	, mFaxValue(_T(""))
	, mFirstNameValue(_T(""))
	, mLastNameValue(_T(""))
	, mPhoneValue(_T(""))
	, mPostalCodeValue(_T(""))
	, mStateValue(_T(""))
	, mSupportRepValue(0)
{

}

CCustomerDlg::~CCustomerDlg()
{
}

void CCustomerDlg::DoDataExchange(CDataExchange* pDX)
{
	CCustomDlg::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CUSTOMER_SUPPORTREP_COMBO, mSupportRepCombo);
	DDX_Text(pDX, IDC_CUSTOMER_ADDRESS_EDIT, mAddressValue);
	DDX_Text(pDX, IDC_CUSTOMER_CITY_EDIT, mCityValue);
	DDX_Text(pDX, IDC_CUSTOMER_COMPANY_EDIT, mCompanyValue);
	DDX_Text(pDX, IDC_CUSTOMER_COUNTRY_EDIT, mCountryValue);
	DDX_Text(pDX, IDC_CUSTOMER_EMAIL_EDIT, mEmailValue);
	DDX_Text(pDX, IDC_CUSTOMER_FAX_EDIT, mFaxValue);
	DDX_Text(pDX, IDC_CUSTOMER_FIRSTNAME_EDIT, mFirstNameValue);
	DDX_Text(pDX, IDC_CUSTOMER_LASTNAME_EDIT, mLastNameValue);
	DDX_Text(pDX, IDC_CUSTOMER_PHONE_EDIT, mPhoneValue);
	DDX_Text(pDX, IDC_CUSTOMER_POSTALCODE_EDIT, mPostalCodeValue);
	DDX_Text(pDX, IDC_CUSTOMER_STATE_EDIT, mStateValue);
	DDX_CBIndex(pDX, IDC_CUSTOMER_SUPPORTREP_COMBO, mSupportRepValue);
	DDX_Control(pDX, IDC_CUSTOMER_PICTURE, mPicture);
}


void CCustomerDlg::InitDialog(int customerId)
{	
	LoadDataByQuery(gCustomerQuery, customerId);
}

void CCustomerDlg::SetControls(const CArrayStr& values, int id)
{
	mCustomerId = id;
	mFirstNameValue = values[CustomerType::firstName];
	mAddressValue = values[CustomerType::address];
	mCityValue = values[CustomerType::city];
	mCompanyValue = values[CustomerType::company];
	mCountryValue = values[CustomerType::country];
	mEmailValue = values[CustomerType::email];
	mFaxValue = values[CustomerType::fax];
	mLastNameValue = values[CustomerType::lastName];
	mPhoneValue = values[CustomerType::phone];
	mPostalCodeValue = values[CustomerType::postalcode];
	mStateValue = values[CustomerType::state];
	mSupportRepValue = _ttoi(values[CustomerType::supportRepId]);
}

void CCustomerDlg::FillSupportRepCombo()
{
	CString query;
	query.Format(gEmployeeQuery);

	std::unique_ptr<CSqlStatement> stmt(theApp.mSQLiteDB.Statement(query));
	ASSERT(stmt);

	while (stmt->NextRow())
	{
		CString value;
		value = CString(stmt->ValueString(EmployeeType::lastName_)) + _T(", ") 
			+ CString(stmt->ValueString(EmployeeType::firstName_));
		mSupportRepCombo.AddString(value);
	}
}


BEGIN_MESSAGE_MAP(CCustomerDlg, CCustomDlg)
END_MESSAGE_MAP()


// CCustomerDlg message handlers


BOOL CCustomerDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	HICON hIcon = AfxGetApp()->LoadIcon(IDI_CUSTOMER);
	ASSERT(hIcon);
	SetIcon(hIcon, TRUE);

	hIcon = (HICON)LoadImage(AfxGetApp()->m_hInstance,
		MAKEINTRESOURCE(IDI_CUSTOMER), IMAGE_ICON, 128, 128, 0);
	ASSERT(hIcon);
	mPicture.SetIcon(hIcon);

	/*CFont font;
	LOGFONT lf{ 0 };
	_tcscpy_s(lf.lfFaceName, _T("Consolas"));
	lf.lfHeight = -12;
	lf.lfWeight = FW_NORMAL;
	font.CreateFontIndirect(&lf);

	for (int i = IDC_FIRSTNAME; i <= IDC_SUPPORTREP; ++i)
	{
		CStatic* pFirstName = static_cast<CStatic*>(GetDlgItem(i));
		pFirstName->SetFont(&font);		
	}
	font.Detach();*/
	
	FillSupportRepCombo();
	mSupportRepCombo.SetCurSel(mSupportRepValue-1);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

