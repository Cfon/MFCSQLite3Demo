// CustomDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "CustomDlg.h"
//#include "afxdialogex.h"
#include <memory>
#include "AlbumDlg.h"
#include "ArtistDlg.h"
#include "CustomerDlg.h"
#include "MediaTypeDlg.h"
#include "PlaylistDlg.h"
#include "TrackDlg.h"

// CCustomDlg dialog

IMPLEMENT_DYNAMIC(CCustomDlg, CDialogEx)

CCustomDlg::CCustomDlg(UINT nIDTemplate, CWnd* pParent /*=NULL*/)
	: CDialogEx(nIDTemplate /*IDD_CUSTOMDLG*/, pParent)
{

}

CCustomDlg::~CCustomDlg()
{
}


void CCustomDlg::LoadDataByQuery(LPCTSTR query, int id)
{
	CString qry;
	qry.Format(query, id);

	std::unique_ptr<CSqlStatement> stmt(theApp.mSQLiteDB.Statement(qry));
	ASSERT(stmt);

	if (stmt->NextRow())
	{
		CArrayStr values;

		// ������� ������ ���� '(null)'
		for (int k = 0; k < stmt->Fields(); ++k)
		{			
			if (CString(stmt->ValueString(k)) != _T("(null)"))
				values.Add(stmt->ValueString(k));
			else
				values.Add(_T(""));
		}

		// ��������� � ������-������ �������
		SetControls(values, id);
	}
}


void CCustomDlg::FillCombo(LPCTSTR query, int fieldZeroIndex, CComboBox * pCombo)
{
	std::unique_ptr<CSqlStatement> stmt(theApp.mSQLiteDB.Statement(query));
	ASSERT(stmt);
	pCombo->ResetContent();

	while (stmt->NextRow())
	{
		CString value;
		value = stmt->ValueString(fieldZeroIndex);
		pCombo->AddString(value);
	}
}


void CCustomDlg::FillListCtrl(CListCtrl* list, LPCTSTR query, int id)
{
	CString qry;
	qry.Format(query, id);

	std::unique_ptr<CSqlStatement> stmt(theApp.mSQLiteDB.Statement(qry));
	ASSERT(stmt);

	/* ������� ��������� ������� */
	CString fieldName;
	fieldName = _T("#");
	list->InsertColumn(0, fieldName);
	list->SetColumnWidth(0, 50);

	for (int k = 1; k < stmt->Fields(); ++k)
	{
		fieldName = stmt->FieldName(k);
		list->InsertColumn(k, fieldName);
		list->SetColumnWidth(k, 100);
	}

	/* ������� ������ � ������� */
	typedef CArray<CString, LPCTSTR> CArrayStr;	
	CArray<std::shared_ptr<CArrayStr>> grid;

	while (stmt->NextRow())
	{		
		std::shared_ptr<CArrayStr> rows(new CArrayStr);

		// ������� ������ ���� '(null)'
		for (int k = 0; k < stmt->Fields(); ++k)
		{
			if (CString(stmt->ValueString(k)) != _T("(null)"))
				rows->Add(stmt->ValueString(k));
			else
				rows->Add(_T(""));
		}
		grid.Add(rows);
	}

	LVITEM lv;
	lv.mask = LVIF_TEXT;
	CString value, n;
	int i = 0;
	for (int i = 0; i < grid.GetCount(); ++i)
	{
		lv.iItem = i;
		lv.iSubItem = 0;
		n.Format(_T("%d"), i + 1);
		lv.pszText = n.GetBuffer(n.GetLength());
		list->InsertItem(&lv);

		for (int k = 1; k < grid[i]->GetCount(); ++k)
		{
			lv.iSubItem = k;
			value = stmt->ValueString(k);
			value = (*grid[i])[k];
			lv.pszText = value.GetBuffer(value.GetLength());
			list->SetItem(&lv);
		}
	}
}



void CCustomDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CCustomDlg, CDialogEx)
END_MESSAGE_MAP()


// CCustomDlg message handlers
