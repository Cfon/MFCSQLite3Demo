#pragma once

#include "Example2Doc.h"
#include <memory>


// CCustomDlg dialog

class CCustomDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CCustomDlg)

public:	
	CCustomDlg(UINT nIDTemplate, CWnd *pParent = NULL); // standard constructor
	virtual ~CCustomDlg();
	
// Dialog Data	

	typedef CArray<CString, LPCTSTR> CArrayStr;

	virtual void InitDialog(int id) = 0;		

protected:	
	virtual void SetControls(const CArrayStr& values, int id) = 0;
	
	void LoadDataByQuery(LPCTSTR query, int id);	
	void FillCombo(LPCTSTR query, int fieldZeroIndex, CComboBox* pCombo);
	void FillListCtrl(CListCtrl* list, LPCTSTR query, int id);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
};

// ������� �������� ���� �������
class CustomDlgFactory
{
public:
	CustomDlgFactory() {}
	virtual ~CustomDlgFactory() {}
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg() = 0;
};

