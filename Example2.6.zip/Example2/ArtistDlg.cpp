// ArtistDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "ArtistDlg.h"
//#include "afxdialogex.h"
#include <memory>


// CArtistDlg dialog

enum ArtistType { artistId,	artistName,  albumsCount };
static LPCTSTR gArtistQuery
{
	_T("SELECT ar.artistId, ar.name, COUNT(al.albumId) 'albums count' ")
	_T(" FROM artists ar ")
	_T(" LEFT JOIN albums al USING (artistId)")
	_T(" GROUP BY ar.artistId ")
	_T(" HAVING ar.artistId = %d")
};

enum AlbumType { albumId, title };
static LPCTSTR gAlbumsQuery
{
	_T("SELECT albumId, title FROM albums WHERE artistId = %d")
};


IMPLEMENT_DYNAMIC(CArtistDlg, CCustomDlg)

CArtistDlg::CArtistDlg(CWnd* pParent /*=NULL*/)
	: CCustomDlg(IDD_ARTIST, pParent)
	, mArtistName(_T(""))
	, mAlbumCount(0)
	, mArtistId(0)
{

}

CArtistDlg::~CArtistDlg()
{
}

void CArtistDlg::DoDataExchange(CDataExchange* pDX)
{
	CCustomDlg::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ARTIST_PICTURE, mPicture);
	DDX_Text(pDX, IDC_ARTIST_NAME_EDIT, mArtistName);
	DDX_Control(pDX, IDC_ARTIST_ALBUMS_LIST, mAlbumsList);
	DDX_Text(pDX, IDC_ARTIST_ALBUMCOUNT_EDIT, mAlbumCount);
}


void CArtistDlg::InitDialog(int artistId)
{
	LoadDataByQuery(gArtistQuery, artistId);
}


void CArtistDlg::SetControls(const CArrayStr& values, int id)
{	
	mArtistId = id;
	mArtistName = values[ArtistType::artistName];
	mAlbumCount = _ttoi(values[ArtistType::albumsCount]);
}


BEGIN_MESSAGE_MAP(CArtistDlg, CCustomDlg)
END_MESSAGE_MAP()


// CArtistDlg message handlers


BOOL CArtistDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// �������� ������ � ��������� ����
	HICON hIcon = AfxGetApp()->LoadIcon(IDI_ARTIST);
	ASSERT(hIcon);
	SetIcon(hIcon, TRUE);

	// �������� ������ � ������� picture
	hIcon = (HICON)LoadImage(AfxGetApp()->m_hInstance,
		MAKEINTRESOURCE(IDI_ARTIST), IMAGE_ICON, 128, 128, 0);
	ASSERT(hIcon);
	mPicture.SetIcon(hIcon);
	
	FillListCtrl(&mAlbumsList, gAlbumsQuery, mArtistId);
	mAlbumsList.SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}
