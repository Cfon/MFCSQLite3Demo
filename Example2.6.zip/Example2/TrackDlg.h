#pragma once
//#include "afxwin.h"
#include "CustomDlg.h"


// CTrackDlg dialog

class CTrackDlg : public CCustomDlg
{
	DECLARE_DYNAMIC(CTrackDlg)

public:
	CTrackDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CTrackDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_TRACK };
#endif

	virtual void InitDialog(int trackId) override;
	virtual void SetControls(const CArrayStr& values, int id) override;

protected:	
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	int mTrackId;
	ULONGLONG mBytes;
	CString mComposer;
	ULONGLONG mMilliseconds;
	CString mTrackName;
	double mPrice;
	int mAlbumId;
	int mMediaTypeId;
	int mGenreId;
	CComboBox mAlbumNamesCombo;
	CComboBox mMediaTypesCombo;
	CComboBox mGenresCombo;	
	virtual BOOL OnInitDialog();
};


class TrackDlgFactory : public CustomDlgFactory
{
public:
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg()
	{
		std::unique_ptr<CCustomDlg> dlg(new CTrackDlg);
		return dlg;
	}
};

