
// GalleryView.cpp : implementation of the CGalleryView class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "Gallery.h"
#endif

#include "GalleryDoc.h"
#include "GalleryView.h"
#include "InputDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif



// CGalleryView

IMPLEMENT_DYNCREATE(CGalleryView, CFormView)

BEGIN_MESSAGE_MAP(CGalleryView, CFormView)
	ON_BN_CLICKED(IDC_ALBUM_EDIT_BUTTON, &CGalleryView::OnAlbumEditButton)		
	ON_BN_CLICKED(IDC_ALBUM_DELETE_BUTTON, &CGalleryView::OnAlbumDeleteButton)
	ON_BN_CLICKED(IDC_ALBUM_INSERT_BUTTON, &CGalleryView::OnAlbumInsertButton)	
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_ALBUM_LIST, &CGalleryView::OnLvnItemchangedAlbumList)
END_MESSAGE_MAP()

// CGalleryView construction/destruction

CGalleryView::CGalleryView()
	: CFormView(CGalleryView::IDD)
	, mRecordCount(0)
	, mCurrentPos(0)
	, mAlbumId(0)	
{
}

CGalleryView::~CGalleryView()
{
}


void CGalleryView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ALBUM_LIST, mAlbumList);
}

BOOL CGalleryView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CGalleryView::OnInitialUpdate()
{
	TRACE(_T("OnInitialUpdate\n"));	
	CFormView::OnInitialUpdate();	
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();		

	mAlbumList.SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE, 0,
		LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);		
}


// CGalleryView diagnostics

#ifdef _DEBUG
void CGalleryView::AssertValid() const
{
	CFormView::AssertValid();
}

void CGalleryView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CGalleryDoc* CGalleryView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGalleryDoc)));
	return (CGalleryDoc*)m_pDocument;
}
#endif //_DEBUG


void CGalleryView::AddAlbumsToList(std::unique_ptr<Albums>& albums, CListCtrl& list)
{
	// ������� ������ � ������	
	LVITEM lv{ 0 };
	lv.mask = LVIF_TEXT;
	
	mRecordCount = 0;
	CString value;	

	for (INT_PTR i = 0; i < albums->GetCount(); ++i)
	{
		lv.iItem = i;
		lv.iSubItem = 0;
		value.Format(_T("%d"), i + 1);
		lv.pszText = value.GetBufferSetLength(value.GetLength());
		list.InsertItem(&lv);
		list.SetItemData(i, (*albums)[i]->Id());
		
		lv.iSubItem = 1;
		value = (*albums)[i]->Name();
		lv.pszText = value.GetBufferSetLength(value.GetLength());
		list.SetItem(&lv);
		
		mRecordCount++;
	}
}


BOOL CGalleryView::IsCurrentPosValid() const
{
	if ((mCurrentPos >= 0) && (mCurrentPos < mRecordCount))
	{
		return TRUE;
	}
	return FALSE;
}


// CGalleryView message handlers


void CGalleryView::OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/)
{	
	TRACE(_T("OnUpdate\n"));	
	
	mAlbumList.DeleteAllItems();
	mAlbumList.DeleteColumn(0);
	mAlbumList.DeleteColumn(0);
	
	// ��������� ������� 
	mAlbumList.InsertColumn(0, _T("#"));
	mAlbumList.SetColumnWidth(0, 50);
	mAlbumList.InsertColumn(1, _T("Album Name"));
	mAlbumList.SetColumnWidth(1, 200);

	auto albums = GetDocument()->GetAlbumDAO()->Select();
	
	// ���������� ������ ��������
	AddAlbumsToList(albums, mAlbumList);
	
	mAlbumId = 0;
	mAlbumName = _T("");

	// ��������� id, name �������� �������
	if (albums->GetCount() != 0)
	{			
		if (!IsCurrentPosValid()) 
		{			
			mCurrentPos = (mCurrentPos - 1) < 0 ? 0 : mCurrentPos - 1;
		}
		
		mAlbumId = (*albums)[mCurrentPos]->Id();
		mAlbumName = (*albums)[mCurrentPos]->Name();			
	}
	
	SetDlgItemText(IDC_ALBUM_STATIC, mAlbumName);	
}


void CGalleryView::OnAlbumEditButton()
{	
	CInputDlg dlg(_T("Edit Album"));
	dlg.mLabelValue = _T("Change album name");
	dlg.mInputValue = mAlbumName;

	if (dlg.DoModal() == IDOK)
	{		
		Album album;
		album.SetId(mAlbumId);
		album.SetName(dlg.mInputValue);

		GetDocument()->GetAlbumDAO()->Update(album);
		GetDocument()->UpdateAllViews(NULL);
	}	
}


void CGalleryView::OnAlbumDeleteButton()
{		
	if (AfxMessageBox(_T("Delete record?"), MB_YESNO) == IDYES)
	{
		GetDocument()->GetAlbumDAO()->Delete(mAlbumId);
		GetDocument()->UpdateAllViews(NULL);
	}
}


void CGalleryView::OnAlbumInsertButton()
{
	CInputDlg dlg(_T("Insert Album"));
	dlg.mLabelValue = _T("Enter an album name");

	if (dlg.DoModal() == IDOK) 
	{
		Album album;
		album.SetName(dlg.mInputValue);
	
		GetDocument()->GetAlbumDAO()->Insert(album);
		GetDocument()->UpdateAllViews(NULL);
	}
}


void CGalleryView::OnLvnItemchangedAlbumList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);

	if ((pNMLV->uChanged & LVIF_STATE) && (pNMLV->uNewState & LVIS_SELECTED))
	{	
		mCurrentPos = pNMLV->iItem;
		mAlbumId = mAlbumList.GetItemData(pNMLV->iItem);
		mAlbumName = mAlbumList.GetItemText(pNMLV->iItem, AlbumDAO::Fields::name);		
		SetDlgItemText(IDC_ALBUM_STATIC, mAlbumName);			
	}

	*pResult = 0;
}
