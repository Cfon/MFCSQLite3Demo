#include "stdafx.h"
#include "AlbumDAO.h"



AlbumDAO::AlbumDAO(CDbSQLite* pDb)
	: mDb(pDb)
{
}

AlbumDAO::~AlbumDAO()
{
}


void AlbumDAO::CreateTable()
{
	CString query;
	query.Format(
		_T("CREATE TABLE IF NOT EXISTS albums (")
		_T(" id INTEGER PRIMARY KEY AUTOINCREMENT, ")
		_T(" name TEXT )"));

	if (!mDb->DirectStatement(query))
	{
		TRACE(_T("table 'albums' is not created\n"));
		ASSERT(FALSE);
	}
}


void AlbumDAO::Insert(Album& album) const
{
	CString query;
	query.Format(_T("INSERT INTO albums (name) VALUES (?)"));

	{
		std::unique_ptr<CSqlStatement> stmt(mDb->Statement(query));
		stmt->Bind(0, album.Name());
		stmt->Execute();
	}

	query.Format(_T("SELECT last_insert_rowid()"));
	std::unique_ptr<CSqlStatement> stmt(mDb->Statement(query));
	stmt->NextRow();
	album.SetId(stmt->ValueInt(0));
}


void AlbumDAO::Update(const Album& album) const
{
	CString query;
	query.Format(_T("UPDATE albums SET name = ? WHERE id = ?"));

	std::unique_ptr<CSqlStatement> stmt(mDb->Statement(query));
	stmt->Bind(0, album.Name());
	stmt->Bind(1, album.Id());
	stmt->Execute();
}


void AlbumDAO::Delete(int albumId) const
{
	CString query;
	query.Format(_T("DELETE FROM albums WHERE id = ?"));

	std::unique_ptr<CSqlStatement> stmt(mDb->Statement(query));
	stmt->Bind(0, albumId);
	stmt->Execute();
}


#ifdef _MFC_CArray		
std::unique_ptr<Albums> AlbumDAO::Select() const
{	
	std::unique_ptr<Albums> upAlbums(new Albums());

	CString query;
	query.Format(_T("SELECT id, name FROM albums"));	
	std::unique_ptr<CSqlStatement> stmt(mDb->Statement(query));

	while (stmt->NextRow())
	{
		std::shared_ptr<Album> album(new Album);
		album->SetId(stmt->ValueInt(Fields::id));
		album->SetName(stmt->ValueString(Fields::name));
		upAlbums->Add(album);
	}

	return upAlbums;
}
#else		
std::unique_ptr<Albums> AlbumDAO::Select() const
{	
	std::unique_ptr<Albums> upAlbums(new Albums());

	CString query;
	query.Format(_T("SELECT id, name FROM albums"));
	enum AlbumType { id, name };

	std::unique_ptr<CSqlStatement> stmt(mDb->Statement(query));

	while (stmt->NextRow())
	{
		std::unique_ptr<Album> album(new Album);
		album->SetId(stmt->ValueInt(Fields::id));
		album->SetName(stmt->ValueString(Fields::name));
		upAlbums->push_back(std::move(album));
	}

	return upAlbums;
}
#endif // _MFC_CArray
