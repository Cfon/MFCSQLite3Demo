#pragma once

#include "DbSqlite.h"
#include "AlbumDAO.h"


//const LPCTSTR DATABASE_FILENAME = _T("db\\gallery.db");
const LPCTSTR DATABASE_FILENAME = _T(":memory:");


class CDbSQLite;

class DatabaseManager
{
public:	
	static DatabaseManager& instance()
	{
		static DatabaseManager singleton;
		return singleton;
	}

	~DatabaseManager() 
	{			
	}

	const AlbumDAO& Album_DAO() const
	{
		return  mAlbumDAO;
	}

protected:
	DatabaseManager(const CString& path = DATABASE_FILENAME)
		: mAlbumDAO(&mDb)
	{		
		mDb.Open(path);
		mAlbumDAO.CreateTable();
	}

	DatabaseManager& operator=(const DatabaseManager& dm) = default;

private:
	CDbSQLite mDb;
	AlbumDAO mAlbumDAO;
};

