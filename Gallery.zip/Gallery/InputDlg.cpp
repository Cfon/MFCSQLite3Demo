// InputDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Gallery.h"
#include "InputDlg.h"
#include "afxdialogex.h"


// CInputDlg dialog

IMPLEMENT_DYNAMIC(CInputDlg, CDialogEx)

CInputDlg::CInputDlg(const CString& caption, CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_INPUT_DIALOG, pParent)
	, mCaption(caption)
	, mInputValue(_T(""))
	, mLabelValue(_T(""))
{

}

CInputDlg::~CInputDlg()
{
}

void CInputDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_INPUT_EDIT, mInputValue);
	DDX_Text(pDX, IDC_INPUT_STATIC, mLabelValue);
}


BEGIN_MESSAGE_MAP(CInputDlg, CDialogEx)
END_MESSAGE_MAP()


// CInputDlg message handlers


BOOL CInputDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	SetWindowText(mCaption);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}
