#pragma once

#include "CustomDlg.h"
#include "NumericFormatedEdit.h"


// CTrackDlg dialog

class CTrackDlg : public CCustomDlg
{
	DECLARE_DYNAMIC(CTrackDlg)

public:
	CTrackDlg(LPCTSTR pQuery, CWnd* pParent = NULL);   // standard constructor
	virtual ~CTrackDlg();

	virtual void SetControls(const CArrayStr& values, int id) override;
	
// Dialog Data
private:
	enum { IDD = IDD_TRACK_DIALOG };

	CComboBox mMediaTypesCombo;
	CComboBox mGenresCombo;	
	CNumericFormatedEdit mMillisecondsEdit;
	CNumericFormatedEdit mBytesEdit;

	ULONGLONG mBytesValue;
	CString mComposerValue;
	ULONGLONG mMillisecondsValue;
	CString mTrackNameValue;
	double mPriceValue;
	int mMediaTypeIdIndex;
	int mGenreIdIndex;
	CString mAlbumNameValue;

protected:	
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
};


class TrackDlgFactory : public CustomDlgFactory
{
public:
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg()
	{
		std::unique_ptr<CCustomDlg> dlg(new CTrackDlg(sTrackQuery));
		return dlg;
	}
private:
	static LPCTSTR sTrackQuery;
};

