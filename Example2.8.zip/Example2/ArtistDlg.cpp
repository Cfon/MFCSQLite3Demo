// ArtistDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "ArtistDlg.h"
#include <memory>




LPCTSTR ArtistDlgFactory::sArtistQuery
{
	_T("SELECT art.name, COUNT(alb.albumId) 'albums count' ")
	_T("FROM artists art ")
	_T("LEFT JOIN albums alb USING (artistId) ")
	_T("GROUP BY art.artistId ")
	_T("HAVING art.artistId = %d ")
};

enum ArtistType { artistName, albumsCount };


// CArtistDlg dialog

//enum ArtistType { artistName, albumsCount };
//static LPCTSTR gArtistQuery
//{
//	_T("SELECT art.name, COUNT(alb.albumId) 'albums count' ")
//	_T("FROM artists art ")
//	_T("LEFT JOIN albums alb USING (artistId) ")
//	_T("GROUP BY art.artistId ")
//	_T("HAVING art.artistId = %d ")
//};


static LPCTSTR gAlbumsQuery
{
	_T("SELECT title FROM albums WHERE artistId = %d")
};


IMPLEMENT_DYNAMIC(CArtistDlg, CCustomDlg)

CArtistDlg::CArtistDlg(LPCTSTR pQuery, CWnd* pParent /*=NULL*/)
	: CCustomDlg(CArtistDlg::IDD, pQuery, pParent)	
	, mAlbumCountValue(0)
{

}

CArtistDlg::~CArtistDlg()
{
}

void CArtistDlg::DoDataExchange(CDataExchange* pDX)
{
	CCustomDlg::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ARTIST_PICTURE, mPictureCtrl);
	DDX_Control(pDX, IDC_ARTIST_ALBUMS_LIST, mAlbumsList);	

	DDX_Text(pDX, IDC_ARTIST_NAME_EDIT, mArtistNameValue);	
	DDX_Text(pDX, IDC_ARTIST_ALBUMCOUNT_EDIT, mAlbumCountValue);
}


void CArtistDlg::SetControls(const CArrayStr& values, int id)
{	
	SetId(id);
	mArtistNameValue = values[ArtistType::artistName];
	mAlbumCountValue = _ttoi(values[ArtistType::albumsCount]);
}


BEGIN_MESSAGE_MAP(CArtistDlg, CCustomDlg)
END_MESSAGE_MAP()


// CArtistDlg message handlers


BOOL CArtistDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// �������� ������ � ��������� ����
	SetSystemMenuIcon(IDI_ARTIST_ICON);

	// �������� ������ � ������� picture
	HICON hIcon = (HICON)LoadImage(AfxGetApp()->m_hInstance,
		MAKEINTRESOURCE(IDI_ARTIST_ICON), IMAGE_ICON, 128, 128, 0);
	ASSERT(hIcon);
	mPictureCtrl.SetIcon(hIcon);
	
	FillListCtrl(&mAlbumsList, gAlbumsQuery, GetId());
	SetGridStyle(&mAlbumsList);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}
