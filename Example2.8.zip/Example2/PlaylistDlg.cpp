// PlaylistDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "PlaylistDlg.h"
#include <memory>


// CPlaylistDlg dialog


LPCTSTR PlaylistDlgFactory::sPlaylistQuery
{
	_T("SELECT p.name, COUNT(pt.trackId) 'tracks count' ")
	_T("FROM playlists p ")
	_T("INNER JOIN playlist_track pt USING (playlistId) ")
	_T("INNER JOIN tracks t USING (trackId) ")
	_T("GROUP BY p.playlistId ")
	_T("HAVING p.playlistId = %d ")
};

enum PlaylistType { playlistName, tracksCount };


static LPCTSTR gTracksQuery
{	
	_T("SELECT t.name 'Track' FROM playlist_track pt ")
	_T("INNER JOIN tracks t USING (trackId) ")
	_T("WHERE pt.playlistId = %d")
};



IMPLEMENT_DYNAMIC(CPlaylistDlg, CCustomDlg)

CPlaylistDlg::CPlaylistDlg(LPCTSTR pQuery, CWnd* pParent /*=NULL*/)
	: CCustomDlg(CPlaylistDlg::IDD, pQuery, pParent)
	, mTrackCountValue(0)
{

}

CPlaylistDlg::~CPlaylistDlg()
{
}


void CPlaylistDlg::SetControls(const CArrayStr& values, int id)
{
	SetId(id);
	mPlaylistNameValue = values[PlaylistType::playlistName];
	mTrackCountValue = _ttoi(values[PlaylistType::tracksCount]);
}


void CPlaylistDlg::DoDataExchange(CDataExchange* pDX)
{
	CCustomDlg::DoDataExchange(pDX);	
	DDX_Control(pDX, IDC_PLAYLIST_TRACK_LIST, mTracksList);

	DDX_Text(pDX, IDC_PLAYLIST_TRACKCOUNT_EDIT, mTrackCountValue);
	DDX_Text(pDX, IDC_PLAYLIST_NAME_EDIT, mPlaylistNameValue);
}


BEGIN_MESSAGE_MAP(CPlaylistDlg, CCustomDlg)
END_MESSAGE_MAP()


// CPlaylistDlg message handlers


BOOL CPlaylistDlg::OnInitDialog()
{
	CCustomDlg::OnInitDialog();

	// �������� ������ � ��������� ����
	SetSystemMenuIcon(IDI_PLAYLIST_ICON);

	FillListCtrl(&mTracksList, gTracksQuery, GetId());
	SetGridStyle(&mTracksList);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}
