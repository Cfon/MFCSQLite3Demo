#pragma once


// CNumericFormatedEdit

class CNumericFormatedEdit : public CEdit
{
	DECLARE_DYNAMIC(CNumericFormatedEdit)

public:
	CNumericFormatedEdit();
	virtual ~CNumericFormatedEdit();

	const CString GetValue() const { return mValue; }	
private:	
	void FormatText(CString& value);

	CString mValue;
	BOOL mIsOnceInitValue;

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnKillfocus();
	afx_msg void OnEnSetfocus();	
	afx_msg UINT OnGetDlgCode();	
};


