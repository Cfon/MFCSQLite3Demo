#pragma once

#include <memory>


// CCustomDlg dialog

class CCustomDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CCustomDlg)

public:	
	// standard constructor
	CCustomDlg(UINT nIDTemplate, LPCTSTR pQuery, CWnd *pParent = NULL);
	virtual ~CCustomDlg();

	typedef CArray<CString> CArrayStr;

	virtual void InitDialog(int id);
	int GetId() const;
	void SetId(int id);
protected:

	virtual void SetControls(const CArrayStr& values, int id) = 0;

	void SetSystemMenuIcon(UINT nIDResource);
	void LoadDataByQuery(LPCTSTR query, int id);
	void FillCombo(CComboBox* pCombo, LPCTSTR query, int fieldZeroIndex);
	void FillListCtrl(CListCtrl* pList, LPCTSTR query, int id);
	void FillEdit(CEdit* pEdit, LPCTSTR query, int fieldZeroIndex, int id);
	void SetGridStyle(CListCtrl* pList);

// Dialog Data	
private:
	int mId;
	LPCTSTR mQuery;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
};


// ������� �������� ���� �������
class CustomDlgFactory
{
public:
	CustomDlgFactory() {}
	virtual ~CustomDlgFactory() {}
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg() = 0;
};

