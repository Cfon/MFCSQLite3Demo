// CustomerDetailsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "CustomerDlg.h"
#include <memory>



LPCTSTR CustomerDlgFactory::sCustomerQuery
{
	_T("SELECT customerId, firstName, lastName, ")
	_T(" company, address, city, state, country, ")
	_T(" postalcode, phone, fax, email, supportRepId ")
	_T(" FROM customers ")
	_T(" WHERE customerId = %d")
};

enum CustomerType
{
	customerId, firstName, lastName,
	company, address, city, state, country,
	postalcode, phone, fax, email, supportRepId
};


// CCustomerDlg dialog


//enum CustomerType
//{
//	customerId, firstName, lastName, 
//	company, address, city, state, country, 
//	postalcode, phone, fax, email, supportRepId
//};
//
//static LPCTSTR gCustomerQuery 
//{
//	_T("SELECT customerId, firstName, lastName, ")
//	_T(" company, address, city, state, country, ")
//	_T(" postalcode, phone, fax, email, supportRepId ")
//	_T(" FROM customers ")
//	_T(" WHERE customerId = %d") 
//};


enum EmployeeType {	employeeId, lastFirstName };
static LPCTSTR gEmployeeQuery 
{
	_T("SELECT employeeId, lastName||', '||firstName FROM employees") 
};


IMPLEMENT_DYNAMIC(CCustomerDlg, CCustomDlg)

CCustomerDlg::CCustomerDlg(LPCTSTR pQuery, CWnd* pParent /*=NULL*/)
	: CCustomDlg(CCustomerDlg::IDD, pQuery, pParent)	
	, mSupportRepIndex(0)
{

}

CCustomerDlg::~CCustomerDlg()
{
}

void CCustomerDlg::DoDataExchange(CDataExchange* pDX)
{
	CCustomDlg::DoDataExchange(pDX);	
	DDX_Control(pDX, IDC_CUSTOMER_SUPPORTREP_COMBO, mSupportRepCombo);
	DDX_Control(pDX, IDC_CUSTOMER_PICTURE, mPictureCtrl);

	DDX_Text(pDX, IDC_CUSTOMER_ADDRESS_EDIT, mAddressValue);
	DDX_Text(pDX, IDC_CUSTOMER_CITY_EDIT, mCityValue);
	DDX_Text(pDX, IDC_CUSTOMER_COMPANY_EDIT, mCompanyValue);
	DDX_Text(pDX, IDC_CUSTOMER_COUNTRY_EDIT, mCountryValue);
	DDX_Text(pDX, IDC_CUSTOMER_EMAIL_EDIT, mEmailValue);
	DDX_Text(pDX, IDC_CUSTOMER_FAX_EDIT, mFaxValue);
	DDX_Text(pDX, IDC_CUSTOMER_FIRSTNAME_EDIT, mFirstNameValue);
	DDX_Text(pDX, IDC_CUSTOMER_LASTNAME_EDIT, mLastNameValue);
	DDX_Text(pDX, IDC_CUSTOMER_PHONE_EDIT, mPhoneValue);
	DDX_Text(pDX, IDC_CUSTOMER_POSTALCODE_EDIT, mPostalCodeValue);
	DDX_Text(pDX, IDC_CUSTOMER_STATE_EDIT, mStateValue);
	DDX_CBIndex(pDX, IDC_CUSTOMER_SUPPORTREP_COMBO, mSupportRepIndex);	
}


void CCustomerDlg::SetControls(const CArrayStr& values, int id)
{
	SetId(id);
	mFirstNameValue = values[CustomerType::firstName];
	mAddressValue = values[CustomerType::address];
	mCityValue = values[CustomerType::city];
	mCompanyValue = values[CustomerType::company];
	mCountryValue = values[CustomerType::country];
	mEmailValue = values[CustomerType::email];
	mFaxValue = values[CustomerType::fax];
	mLastNameValue = values[CustomerType::lastName];
	mPhoneValue = values[CustomerType::phone];
	mPostalCodeValue = values[CustomerType::postalcode];
	mStateValue = values[CustomerType::state];
	mSupportRepIndex = _ttoi(values[CustomerType::supportRepId]);
}


BEGIN_MESSAGE_MAP(CCustomerDlg, CCustomDlg)
END_MESSAGE_MAP()


// CCustomerDlg message handlers


BOOL CCustomerDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	SetSystemMenuIcon(IDI_CUSTOMER_ICON);

	HICON hIcon = (HICON)LoadImage(AfxGetApp()->m_hInstance,
		MAKEINTRESOURCE(IDI_CUSTOMER_ICON), IMAGE_ICON, 128, 128, 0);
	ASSERT(hIcon);
	mPictureCtrl.SetIcon(hIcon);	
	
	FillCombo(&mSupportRepCombo, gEmployeeQuery, EmployeeType::lastFirstName);
	mSupportRepCombo.SetCurSel(mSupportRepIndex);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

