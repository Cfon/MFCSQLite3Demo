#pragma once

#include "CustomDlg.h"


// CArtistDlg dialog

class CArtistDlg : public CCustomDlg
{
	DECLARE_DYNAMIC(CArtistDlg)

public:
	CArtistDlg(LPCTSTR pQuery, CWnd* pParent = NULL);   // standard constructor
	virtual ~CArtistDlg();

	virtual void SetControls(const CArrayStr& values, int id) override;

// Dialog Data
private:
	enum { IDD = IDD_ARTIST_DIALOG };

	CStatic mPictureCtrl;
	CListCtrl mAlbumsList;
	CString mArtistNameValue;
	int mAlbumCountValue;

protected:	
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
};


class ArtistDlgFactory : public CustomDlgFactory
{
public:
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg()
	{
		std::unique_ptr<CCustomDlg> dlg(new CArtistDlg(sArtistQuery));
		return dlg;
	}
private:
	static LPCTSTR sArtistQuery;
};
