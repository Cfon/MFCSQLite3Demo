// CustomDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "CustomDlg.h"
#include <memory>



// CCustomDlg dialog

IMPLEMENT_DYNAMIC(CCustomDlg, CDialogEx)

CCustomDlg::CCustomDlg(UINT nIDTemplate, LPCTSTR pQuery, CWnd* pParent /*=NULL*/)
	: CDialogEx(nIDTemplate, pParent)
	, mId(0)
	, mQuery(pQuery)
{

}

CCustomDlg::~CCustomDlg()
{
}


void CCustomDlg::SetSystemMenuIcon(UINT nIDResource)
{
	// ������ � ��������� ����
	HICON hIcon = AfxGetApp()->LoadIcon(nIDResource);
	ASSERT(hIcon);
	SetIcon(hIcon, FALSE);
}


void CCustomDlg::InitDialog(int id)
{
	ASSERT(mQuery);
	LoadDataByQuery(mQuery, id);
}


void CCustomDlg::LoadDataByQuery(LPCTSTR query, int id)
{
	CString qry;
	qry.Format(query, id);

	std::unique_ptr<CSqlStatement> stmt(theApp.mSQLiteDB.Statement(qry));
	ASSERT(stmt);

	if (stmt->NextRow())
	{
		CArrayStr values;

		// ������� ������ ���� '(null)'
		for (int k = 0; k < stmt->Fields(); ++k)
		{			
			if (CString(stmt->ValueString(k)) != _T("(null)"))
				values.Add(stmt->ValueString(k));
			else
				values.Add(_T(""));
		}

		// ��������� � ������-������ �������
		SetControls(values, id);
	}
}


int CCustomDlg::GetId() const
{
	return mId;
}


void CCustomDlg::SetId(int id)
{
	mId = id;
}


void CCustomDlg::FillCombo(CComboBox * pCombo, LPCTSTR query, int fieldZeroIndex)
{
	std::unique_ptr<CSqlStatement> stmt(theApp.mSQLiteDB.Statement(query));
	ASSERT(stmt);
	pCombo->ResetContent();
	pCombo->AddString(_T(""));

	while (stmt->NextRow())
	{
		CString value;
		value = stmt->ValueString(fieldZeroIndex);
		pCombo->AddString(value);
	}
}


void CCustomDlg::FillListCtrl(CListCtrl* pList, LPCTSTR query, int id)
{
	CString qry;
	qry.Format(query, id);

	std::unique_ptr<CSqlStatement> stmt(theApp.mSQLiteDB.Statement(qry));
	ASSERT(stmt);

	/* ������� ��������� ������� */
	CString fieldName;
	fieldName = _T("#");
	pList->InsertColumn(0, fieldName);
	pList->SetColumnWidth(0, 50);

	for (int k = 0; k < stmt->Fields(); ++k)
	{
		fieldName = stmt->FieldName(k);
		pList->InsertColumn(k+1, fieldName);
		pList->SetColumnWidth(k+1, 100);
	}

	/* ������� ������ � ������� */
	typedef CArray<CString> CArrayStr;	
	CArray<std::shared_ptr<CArrayStr>> grid;

	while (stmt->NextRow())
	{		
		std::shared_ptr<CArrayStr> rows(new CArrayStr);

		// ������� ������ ���� '(null)'
		for (int k = 0; k < stmt->Fields(); ++k)
		{
			if (CString(stmt->ValueString(k)) != _T("(null)"))
				rows->Add(stmt->ValueString(k));
			else
				rows->Add(_T(""));			
		}
		grid.Add(rows);
	}

	LVITEM lv;
	lv.mask = LVIF_TEXT;
	CString value, n;
	int i = 0;
	for (int i = 0; i < grid.GetCount(); ++i)
	{
		lv.iItem = i;
		lv.iSubItem = 0;
		n.Format(_T("%d"), i + 1);
		lv.pszText = n.GetBuffer(n.GetLength());
		pList->InsertItem(&lv);

		for (int k = 0; k < grid[i]->GetCount(); ++k)
		{
			lv.iSubItem = k+1;
			value = stmt->ValueString(k);
			value = (*grid[i])[k];
			lv.pszText = value.GetBuffer(value.GetLength());
			pList->SetItem(&lv);
		}
	}
}


void CCustomDlg::FillEdit(CEdit* pEdit, LPCTSTR query, int fieldZeroIndex, int id)
{
	CString qry;
	qry.Format(query, id);

	std::unique_ptr<CSqlStatement> stmt(theApp.mSQLiteDB.Statement(qry));
	ASSERT(stmt);
	
	pEdit->SetWindowText(_T(""));
	CString value;

	while (stmt->NextRow())
	{		
		if (value.IsEmpty())
			value = CString(stmt->ValueString(fieldZeroIndex));
		else
			value += _T(";  ") + CString(stmt->ValueString(fieldZeroIndex));
	}
	pEdit->SetWindowText(value);
}


void CCustomDlg::SetGridStyle(CListCtrl* pList)
{
	pList->SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE, 0,
		LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);
}


void CCustomDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CCustomDlg, CDialogEx)
END_MESSAGE_MAP()


// CCustomDlg message handlers


BOOL CCustomDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	/*CFont font;
	LOGFONT lf{ 0 };
	_tcscpy_s(lf.lfFaceName, _T("Consolas"));
	lf.lfHeight = -12;
	lf.lfWeight = FW_NORMAL;
	font.CreateFontIndirect(&lf);

	for (int i = IDC_FIRSTNAME; i <= IDC_SUPPORTREP; ++i)
	{
	CStatic* pFirstName = static_cast<CStatic*>(GetDlgItem(i));
	pFirstName->SetFont(&font);
	}
	font.Detach();*/


	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
