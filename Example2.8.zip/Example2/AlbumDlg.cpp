// AlbumDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "AlbumDlg.h"
#include <memory>



// CAlbumDlg dialog


LPCTSTR AlbumDlgFactory::sAlbumQuery
{
	_T("SELECT title, artistId FROM albums ")
	_T(" WHERE albumId = %d") 
};

enum AlbumType { title, artistId };


static LPCTSTR gArtistsQuery 
{
	_T("SELECT name FROM artists") 
};

enum ArtistType { artistName };


static LPCTSTR gTracksQuery 
{
	_T("SELECT t.name, g.name 'Genre', t.composer, t.unitPrice")
	_T(" FROM tracks t")
	_T(" LEFT JOIN genres g USING (genreId)")
	_T(" WHERE t.albumId = %d") 
};


IMPLEMENT_DYNAMIC(CAlbumDlg, CCustomDlg)

CAlbumDlg::CAlbumDlg(LPCTSTR pQuery, CWnd* pParent /*=NULL*/)
	: CCustomDlg(CAlbumDlg::IDD, pQuery, pParent)		
	, mArtistIDIndex(0)
{

}


CAlbumDlg::~CAlbumDlg()
{
}


void CAlbumDlg::DoDataExchange(CDataExchange* pDX)
{
	CCustomDlg::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ALBUM_ARTISTS_COMBO, mArtistsCombo);
	DDX_Control(pDX, IDC_ALBUM_TRACKS_LIST, mTracksList);	

	DDX_Text(pDX, IDC_ALBUM_TITLE_EDIT, mTitleValue);
	DDX_CBIndex(pDX, IDC_ALBUM_ARTISTS_COMBO, mArtistIDIndex);
}


void CAlbumDlg::SetControls(const CArrayStr& values, int id)
{	
	SetId(id);
	mTitleValue = values[AlbumType::title];
	mArtistIDIndex = _ttoi(values[AlbumType::artistId]);
}



BEGIN_MESSAGE_MAP(CAlbumDlg, CCustomDlg)
END_MESSAGE_MAP()


// CAlbumDlg message handlers


BOOL CAlbumDlg::OnInitDialog()
{
	CCustomDlg::OnInitDialog();

	SetSystemMenuIcon(IDI_ALBUM_ICON);
		
	FillListCtrl(&mTracksList, gTracksQuery, GetId());
	SetGridStyle(&mTracksList);

	FillCombo(&mArtistsCombo, gArtistsQuery, ArtistType::artistName);
	mArtistsCombo.SetCurSel(mArtistIDIndex);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
