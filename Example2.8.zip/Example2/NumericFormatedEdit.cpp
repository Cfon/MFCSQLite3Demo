// NumericFormatedEdit.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "NumericFormatedEdit.h"


// CNumericFormatedEdit

IMPLEMENT_DYNAMIC(CNumericFormatedEdit, CEdit)

CNumericFormatedEdit::CNumericFormatedEdit()
	: mIsOnceInitValue(FALSE)
{
}

CNumericFormatedEdit::~CNumericFormatedEdit()
{
}


void CNumericFormatedEdit::FormatText(CString& value)
{
	NUMBERFMT nf{ 0 };
	nf.NumDigits = 0;
	nf.LeadingZero = FALSE;
	nf.Grouping = 3;
	nf.lpDecimalSep = _T(".");
	nf.lpThousandSep = _T(" ");
	nf.NegativeOrder = 0;

	const int cBufferSize = 80;
	GetNumberFormat(LOCALE_USER_DEFAULT, 0, mValue, &nf, value.GetBuffer(cBufferSize), cBufferSize);
	value.ReleaseBuffer();
}


BEGIN_MESSAGE_MAP(CNumericFormatedEdit, CEdit)
	ON_CONTROL_REFLECT(EN_KILLFOCUS, &CNumericFormatedEdit::OnEnKillfocus)
	ON_CONTROL_REFLECT(EN_SETFOCUS, &CNumericFormatedEdit::OnEnSetfocus)	
	ON_WM_GETDLGCODE()	
END_MESSAGE_MAP()



// CNumericFormatedEdit message handlers


void CNumericFormatedEdit::OnEnKillfocus()
{
	CString formattedValue;
	GetWindowText(mValue);
	FormatText(formattedValue);
	SetWindowText(formattedValue);	
	//TRACE(_T("%s\n"), mValue);
}


void CNumericFormatedEdit::OnEnSetfocus()
{		
	SetWindowText(mValue);
}


UINT CNumericFormatedEdit::OnGetDlgCode()
{	
	if (!mIsOnceInitValue)
	{
		OnEnKillfocus();
		//TRACE(_T("%s\n"), mValue);
		mIsOnceInitValue = TRUE;
	}

	return CEdit::OnGetDlgCode();
}

