#pragma once
#include "CustomDlg.h"


// CGenreDlg dialog

class CGenreDlg : public CCustomDlg
{
	DECLARE_DYNAMIC(CGenreDlg)

public:
	CGenreDlg(LPCTSTR pQuery, CWnd* pParent = NULL);   // standard constructor
	virtual ~CGenreDlg();

	virtual void SetControls(const CArrayStr& values, int id) override;

// Dialog Data	
private:
	enum { IDD = IDD_GENRE_DIALOG };

	CListCtrl mTrackList;
	CString mGenreNameValue;
	int mTrackCountValue;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
};


class GenreDlgFactory : public CustomDlgFactory
{
public:
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg()
	{
		std::unique_ptr<CCustomDlg> dlg(new CGenreDlg(sGenreQuery));
		return dlg;
	}
private:
	static LPCTSTR sGenreQuery;
};
