
// Example2Doc.h : interface of the CExample2Doc class
//


#pragma once

#include <memory>


extern CExample2Doc* gDocumentPtr;
extern LPCTSTR gTableNames[];
extern LPCTSTR gQueries[];


class CustomDlgFactory;


class CExample2Doc : public CDocument
{
protected: // create from serialization only
	CExample2Doc();
	DECLARE_DYNCREATE(CExample2Doc)

// Attributes
public:
	
// Operations
public:

// Overrides
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
#ifdef SHARED_HANDLERS
	virtual void InitializeSearchContent();
	virtual void OnDrawThumbnail(CDC& dc, LPRECT lprcBounds);
#endif // SHARED_HANDLERS

// Implementation
public:
	virtual ~CExample2Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	enum TableNameType
	{
		albums,
		artists,
		tracks,
		mediaTypes,
		genres,
		playlists,
		customers,
		employees,
		invoices
	};

	CMainFrame* mMainFramePtr;
	TableNameType mTableNameType;
	int mCurRowN;	
	int mSortByN;
	int mTotalRecords;

	
	class CField : public CObject
	{
	public:
		CField() {}
		CField(const CString& fieldName, const CString& fieldValue)
			: mFieldName(fieldName)
			, mFieldValue(fieldValue) {}
		~CField() {};
		CString FieldName() const { return mFieldName; }
		CString FieldValue() const { return mFieldValue; }
		void FieldName(const CString& value) { mFieldName = value; }
		void FieldValue(const CString& value) { mFieldValue = value; }
		const CField& operator=(const CField& field) 
		{
			mFieldName = field.mFieldName;
			mFieldValue = field.mFieldValue;
			return *this;
		}
	private:
		CString mFieldName;
		CString mFieldValue;
	};

	class CRecord : public CObject
	{
	public:
		CRecord() {};
		~CRecord() {};

		void RemoveFields() { mFields.RemoveAll(); }
		int AddField(const CField& field) { return mFields.Add(field); }
		int FieldCount() const { return mFields.GetCount(); }
		const CRecord& operator=(const CRecord& record)
		{			
			mFields.Copy(record.mFields);
			return *this;
		}
		const CField& operator[](int index) const
		{
			return mFields[index];
		}
	private:
		CArray<CField> mFields;
	};

	class CTable : public CObject
	{
	public:
		CTable() {};
		~CTable() {};
		
		void RemoveRecords() { mRecords.RemoveAll(); }
		int AddRecord(const CRecord& record) { return mRecords.Add(record); }
		int RecordCount() const { return mRecords.GetCount();  }
		int FieldCount() const { return mRecords.ElementAt(0).FieldCount(); }
		const CRecord& operator[](int index) const
		{
			return mRecords[index];
		}
	private:
		CArray<CRecord> mRecords;	

	};
		
	CTable mTable;
	std::unique_ptr<CustomDlgFactory> mDlgFactory;


	friend class CExample2View;
	friend class CMainFrame;
public:

	int GetTotalRecordCount();
	void LoadPartDataFromTable();	
	void ResetData();


	
// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()

#ifdef SHARED_HANDLERS
	// Helper function that sets search content for a Search Handler
	void SetSearchContent(const CString& value);
#endif // SHARED_HANDLERS
public:
	afx_msg void OnTablesAlbums();
	afx_msg void OnTablesCustomers();
	afx_msg void OnTablesTracks();
	afx_msg void OnTablesArtists();
	afx_msg void OnTablesEmployees();
	afx_msg void OnTablesGenres();
	afx_msg void OnTablesInvoices();
	afx_msg void OnTablesMediatypes();
	afx_msg void OnTablesPlaylists();
	afx_msg void OnUpdateTablesAlbums(CCmdUI *pCmdUI);
	afx_msg void OnUpdateTablesArtists(CCmdUI *pCmdUI);
	afx_msg void OnUpdateTablesCustomers(CCmdUI *pCmdUI);
	afx_msg void OnUpdateTablesEmployees(CCmdUI *pCmdUI);
	afx_msg void OnUpdateTablesGenres(CCmdUI *pCmdUI);
	afx_msg void OnUpdateTablesInvoices(CCmdUI *pCmdUI);
	afx_msg void OnUpdateTablesMediatypes(CCmdUI *pCmdUI);
	afx_msg void OnUpdateTablesPlaylists(CCmdUI *pCmdUI);
	afx_msg void OnUpdateTablesTracks(CCmdUI *pCmdUI);
};
