// EmployeeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "EmployeeDlg.h"




// CEmployeeDlg dialog

LPCTSTR EmployeeDlgFactory::sEmployeeQuery
{
	_T("SELECT lastName, firstName, title, reportsTo, ")
	_T("strftime('%%Y-%%m-%%d', birthDate) 'birth date', ")
	_T("strftime('%%Y-%%m-%%d', hireDate) 'hire date', ")
	_T("address, city, state, country, postalCode, phone, fax, email ")
	_T("FROM employees ")
	_T("WHERE employeeId = %d")
};

enum EmployeeType
{
	lastName, firstName,
	title, reportsTo, birthDate, hireDate,
	address, city, state, country, postalCode,
	phone, fax, email
};


static LPCTSTR gReportsToQuery
{
	_T("SELECT lastname||' '||firstname 'reports to' FROM employees ")	
};

enum EmpReportToType { reportsTo_ };


static LPCTSTR gReporteesQuery
{
	_T("SELECT lastname||' '||firstname 'reportees' FROM employees ")
	_T("WHERE reportsto = %d ")
};

enum EmpReporteesType { reportees };


IMPLEMENT_DYNAMIC(CEmployeeDlg, CCustomDlg)

CEmployeeDlg::CEmployeeDlg(LPCTSTR pQuery, CWnd* pParent /*=NULL*/)
	: CCustomDlg(CEmployeeDlg::IDD, pQuery, pParent)
	, mReportsToIndex(0)
{
}

CEmployeeDlg::~CEmployeeDlg()
{
}

void CEmployeeDlg::DoDataExchange(CDataExchange* pDX)
{
	CCustomDlg::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EMPLOYEE_REPORTSTO_COMBO, mReportsToCombo);
	DDX_Control(pDX, IDC_EMPLOYEE_REPORTEES_EDIT, mReporteesEdit);
	DDX_Control(pDX, IDC_EMPLOYEE_HIREDATE_DTPICKER, mHireDateCtrl);
	DDX_Control(pDX, IDC_EMPLOYEE_BIRTHDATE_DTPICKER, mBirthDateCtrl);
	DDX_Control(pDX, IDC_EMPLOYEE_PICTURE, mPictureCtrl);

	DDX_Text(pDX, IDC_EMPLOYEE_ADDRESS_EDIT, mAddressValue);
	DDX_Text(pDX, IDC_EMPLOYEE_CITY_EDIT, mCityValue);
	DDX_Text(pDX, IDC_EMPLOYEE_COUNTRY_EDIT, mCountryValue);
	DDX_Text(pDX, IDC_EMPLOYEE_EMAIL_EDIT, mEmailValue);
	DDX_Text(pDX, IDC_EMPLOYEE_FAX_EDIT, mFaxValue);
	DDX_Text(pDX, IDC_EMPLOYEE_FIRSTNAME_EDIT, mFirstNameValue);
	DDX_Text(pDX, IDC_EMPLOYEE_LASTNAME_EDIT, mLastNameValue);
	DDX_Text(pDX, IDC_EMPLOYEE_PHONE_EDIT, mPhoneValue);
	DDX_Text(pDX, IDC_EMPLOYEE_POSTALCODE_EDIT, mPostalCodeValue);
	DDX_Text(pDX, IDC_EMPLOYEE_STATE_EDIT, mStateValue);
	DDX_CBIndex(pDX, IDC_EMPLOYEE_REPORTSTO_COMBO, mReportsToIndex);
	DDX_Text(pDX, IDC_EMPLOYEE_TITLE_EDIT, mTitleValue);
	DDX_DateTimeCtrl(pDX, IDC_EMPLOYEE_HIREDATE_DTPICKER, mHireDateValue);
	DDX_DateTimeCtrl(pDX, IDC_EMPLOYEE_BIRTHDATE_DTPICKER, mBirthDateValue);	
}


void CEmployeeDlg::SetControls(const CArrayStr& values, int id)
{
	SetId(id);
	mAddressValue = values[EmployeeType::address];
	mBirthDateValue = values[EmployeeType::birthDate];
	mCityValue = values[EmployeeType::city];
	mCountryValue = values[EmployeeType::country];
	mEmailValue = values[EmployeeType::email];
	mFaxValue = values[EmployeeType::fax];
	mFirstNameValue = values[EmployeeType::firstName];
	mHireDateValue = values[EmployeeType::hireDate];
	mLastNameValue = values[EmployeeType::lastName];
	mPhoneValue = values[EmployeeType::phone];
	mPostalCodeValue = values[EmployeeType::postalCode];
	mStateValue = values[EmployeeType::state];
	mTitleValue = values[EmployeeType::title];
	mReportsToIndex = _ttoi(values[EmployeeType::reportsTo]);
}


BEGIN_MESSAGE_MAP(CEmployeeDlg, CCustomDlg)
END_MESSAGE_MAP()


// CEmployeeDlg message handlers


BOOL CEmployeeDlg::OnInitDialog()
{
	CCustomDlg::OnInitDialog();

	SetSystemMenuIcon(IDI_EMPLOYEE_ICON);

	// �������� ������ � ������� picture
	HICON hIcon = (HICON)LoadImage(AfxGetApp()->m_hInstance,
		MAKEINTRESOURCE(IDI_EMPLOYEE_ICON), IMAGE_ICON, 128, 128, 0);
	ASSERT(hIcon);
	mPictureCtrl.SetIcon(hIcon);

	FillCombo(&mReportsToCombo, gReportsToQuery, EmpReportToType::reportsTo_);
	mReportsToCombo.SetCurSel(mReportsToIndex);

	FillEdit(&mReporteesEdit, gReporteesQuery, EmpReporteesType::reportees, GetId());

	mHireDateCtrl.SetFormat(_T("dd/MM/yyyy"));
	mBirthDateCtrl.SetFormat(_T("dd/MM/yyyy"));

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
