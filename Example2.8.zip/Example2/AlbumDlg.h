#pragma once

#include "CustomDlg.h"


// CAlbumDlg dialog

class CAlbumDlg : public CCustomDlg
{
	DECLARE_DYNAMIC(CAlbumDlg)

public:
	CAlbumDlg(LPCTSTR pQuery, CWnd* pParent = NULL);   // standard constructor	
	virtual ~CAlbumDlg();

	virtual void SetControls(const CArrayStr& values, int id) override;

// Dialog Data
private:
	enum { IDD = IDD_ALBUM_DIALOG };

	CComboBox mArtistsCombo;
	CListCtrl mTracksList;
	CString mTitleValue;
	int mArtistIDIndex;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
};


class AlbumDlgFactory : public CustomDlgFactory
{
public:
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg()
	{
		std::unique_ptr<CCustomDlg> dlg(new CAlbumDlg(sAlbumQuery));
		return dlg;
	}
private:
	static LPCTSTR sAlbumQuery;
};
