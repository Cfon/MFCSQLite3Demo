//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Gallery.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_GALLERY_FORM                101
#define IDR_MAINFRAME                   128
#define IDR_GalleryTYPE                 130
#define IDD_INPUT_DIALOG                311
#define IDC_ALBUM_EDIT_BUTTON           1002
#define IDC_ALBUM_LIST                  1003
#define IDC_ALBUM_DELETE_BUTTON         1004
#define IDC_ALBUM_INSERT_BUTTON         1005
#define IDC_INPUT_EDIT                  1006
#define IDC_INPUT_LABEL                 1007
#define IDC_ALBUM_LABEL                 1009
#define IDC_ADDPICTURES_BUTTON          1010
#define IDC_MYPICTURE_LIST              1011
#define IDC_ALBUM_LISTBOX               1012
#define IDC_ALBUM_LSTATIC               1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        313
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
