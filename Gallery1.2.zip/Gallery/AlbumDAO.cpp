#include "stdafx.h"
#include "AlbumDAO.h"
#include "Album.h"
#include "DbSqlite.h"


/* SQL queries */
static LPCTSTR gCreateTableQuery
{ 
	_T("CREATE TABLE IF NOT EXISTS albums (")
	_T(" id INTEGER PRIMARY KEY, ")
	_T(" name TEXT )")
};

static LPCTSTR gInsertQuery{ _T("INSERT INTO albums (name) VALUES (?)") };
static LPCTSTR gUpdateQuery{ _T("UPDATE albums SET name = ? WHERE id = ?") };
static LPCTSTR gDeleteQuery{ _T("DELETE FROM albums WHERE id = ?") };
static LPCTSTR gSelectQuery{ _T("SELECT id, name FROM albums") };


AlbumDAO::AlbumDAO(CDbSQLite& db)
	: mDb(db)
{
}

AlbumDAO::~AlbumDAO()
{
}


void AlbumDAO::CreateTable() const
{	
	if (!mDb.DirectStatement(gCreateTableQuery))
	{
		TRACE(_T("table 'albums' is not created\n"));
		ASSERT(FALSE);
	}
}


void AlbumDAO::Insert(Album& album) const
{	
	{
		std::unique_ptr<CSqlStatement> stmt(mDb.Statement(gInsertQuery));
		stmt->Bind(0, album.Name());
		stmt->Execute();
	}

	CString query(_T("SELECT last_insert_rowid()"));	
	std::unique_ptr<CSqlStatement> stmt(mDb.Statement(query));
	stmt->NextRow();
	album.SetId(stmt->ValueInt(0));
}


void AlbumDAO::Update(const Album& album) const
{	
	std::unique_ptr<CSqlStatement> stmt(mDb.Statement(gUpdateQuery));
	stmt->Bind(0, album.Name());
	stmt->Bind(1, album.Id());
	stmt->Execute();
}


void AlbumDAO::Delete(int albumId) const
{	
	std::unique_ptr<CSqlStatement> stmt(mDb.Statement(gDeleteQuery));
	stmt->Bind(0, albumId);
	stmt->Execute();
}


std::unique_ptr<Albums> AlbumDAO::Select()  const
{
	std::unique_ptr<Albums> upAlbums(new Albums());
	std::unique_ptr<CSqlStatement> stmt(mDb.Statement(gSelectQuery));
	enum AlbumFields { id, name };

	while (stmt->NextRow())
	{
		std::unique_ptr<Album> album(new Album);
		album->SetId(stmt->ValueInt(AlbumFields::id));
		album->SetName(stmt->ValueString(AlbumFields::name));
#ifdef _MFC_CArray
		upAlbums->Add(std::move(album));
#else	
		upAlbums->push_back(std::move(album));
#endif // _MFC_CArray
	}

	return upAlbums;
}