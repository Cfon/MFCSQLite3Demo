#include "stdafx.h"
#include "MyPicture.h"

