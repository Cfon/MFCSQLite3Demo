#pragma once

#include <memory>
#include <vector>


class CDbSQLite;
class MyPicture;


#define _MFC_CArray
#ifdef _MFC_CArray	
typedef CArray<std::shared_ptr<MyPicture>> MyPictures;
#else
typedef std::vector<std::unique_ptr<MyPicture>> MyPictures;
#endif


class MyPictureDAO
{
public:
	explicit MyPictureDAO(CDbSQLite& db);
	~MyPictureDAO();

	void CreateTable() const;
	void Insert(MyPicture& picture, int albumId) const;
	void Delete(int id) const;
	void DeletePictures(int albumId) const;
	std::unique_ptr<MyPictures> Select(int albumId) const;

private:
	CDbSQLite& mDb;
};

