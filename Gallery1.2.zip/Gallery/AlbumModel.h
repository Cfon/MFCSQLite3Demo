#pragma once

#include <memory>
#include "AlbumDAO.h"


class Album;
class DatabaseManager;


class AlbumModel
{
public:
	AlbumModel();
	~AlbumModel();

	BOOL IsIndexValid(int index) const;
	int RowCount() const;

	int AlbumId(int index) const;
	CString AlbumName(int index) const;
	void SetAlbumName(int index, const CString& name) const;
	void AddAlbum(const	Album& album) const;
	BOOL RemoveRows(int	row, int count) const;

private:
	DatabaseManager& mDataManager;
	std::unique_ptr<Albums> mAlbums; // data model
};

