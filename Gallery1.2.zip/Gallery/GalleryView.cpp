
// GalleryView.cpp : implementation of the CGalleryView class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "Gallery.h"
#endif

#include "GalleryDoc.h"
#include "GalleryView.h"
#include "InputDlg.h"
#include "Album.h"
#include "MyPicture.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif



// CGalleryView

IMPLEMENT_DYNCREATE(CGalleryView, CFormView)

BEGIN_MESSAGE_MAP(CGalleryView, CFormView)
	ON_BN_CLICKED(IDC_ALBUM_EDIT_BUTTON, &CGalleryView::OnAlbumEditButton)		
	ON_BN_CLICKED(IDC_ALBUM_DELETE_BUTTON, &CGalleryView::OnAlbumDeleteButton)
	ON_BN_CLICKED(IDC_ALBUM_INSERT_BUTTON, &CGalleryView::OnAlbumInsertButton)	
	//ON_NOTIFY(LVN_ITEMCHANGED, IDC_ALBUM_LIST, &CGalleryView::OnLvnItemchangedAlbumList)
	ON_BN_CLICKED(IDC_ADDPICTURES_BUTTON, &CGalleryView::OnAddPicturesButton)
	ON_LBN_SELCHANGE(IDC_ALBUM_LISTBOX, &CGalleryView::OnLbnSelchangeAlbumListbox)
END_MESSAGE_MAP()

// CGalleryView construction/destruction

CGalleryView::CGalleryView()
	: CFormView(CGalleryView::IDD)
	, mAblumRowIndex(-1)
{		
	mThumbnailImageList.Create(64, 64, ILC_COLOR24, 1, 1);
}

CGalleryView::~CGalleryView()
{
}


void CGalleryView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_MYPICTURE_LIST, mMyPictureList);
	DDX_Control(pDX, IDC_ALBUM_LISTBOX, mAlbumList);
}

BOOL CGalleryView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	
	return CFormView::PreCreateWindow(cs);
}

void CGalleryView::OnInitialUpdate()
{	
	TRACE(_T("OnInitialUpdate\n"));
	CFormView::OnInitialUpdate();	
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();		

	/*mAlbumList.SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE, 0,
		LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);	*/	
	
	CStatic* label1 = static_cast<CStatic*>(GetDlgItem(IDC_ALBUM_LSTATIC));
	CStatic* label2 = static_cast<CStatic*>(GetDlgItem(IDC_ALBUM_LABEL));
	CFont font;
	LOGFONT lf{ 0 };
	_tcscpy_s(lf.lfFaceName, _T("Consolas"));	
	lf.lfHeight = -12;
	lf.lfWeight = FW_BOLD;
	font.CreateFontIndirect(&lf);
	label1->SetFont(&font);
	label2->SetFont(&font);
	font.Detach();	
}


// CGalleryView diagnostics

#ifdef _DEBUG
void CGalleryView::AssertValid() const
{
	CFormView::AssertValid();
}

void CGalleryView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CGalleryDoc* CGalleryView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGalleryDoc)));
	return (CGalleryDoc*)m_pDocument;
}
#endif //_DEBUG


void CGalleryView::UpdateAlbumList()
{	
	mAlbumList.ResetContent();

	// ������� ������ � ������	
	CString value;
	for (int i = 0; i < GetDocument()->GetAlbumModel()->RowCount(); ++i)
	{
		mAlbumList.AddString(GetDocument()->GetAlbumModel()->AlbumName(i));
	}	
}


void CGalleryView::UpdatePictureList()
{
	// ��������� ������ �������� ���������� �������
	GetDocument()->GetMyPictureModel()->LoadPictures(mAblumRowIndex);

	// ������� ������ ��������
	mThumbnailImageList.SetImageCount(0);
	CreateThumbnails(GetDocument()->GetMyPictureModel(), mThumbnailImageList);

	// ��������� ������
	mMyPictureList.DeleteAllItems();
	for (int i = 0; i < mThumbnailImageList.GetImageCount(); ++i)
	{
		CString pictureName = GetDocument()->GetMyPictureModel()->MyPictureFilePath(i);
		mMyPictureList.InsertItem(i, pictureName, i);
	}
}


void CGalleryView::CreateThumbnails(MyPictureModel* pm, CImageList& il)
{	
	CDC srcDC;
	CDC thumbDC;
	srcDC.CreateCompatibleDC(GetDC());	
	thumbDC.CreateCompatibleDC(GetDC());
	CImage image;

	for (int i = 0; i < pm->RowCount(); ++i)
	{				
		CBitmap bitmap;				
		LRESULT ret = image.Load(pm->MyPictureFilePath(i));							
		if (ret != 0)
		{			
			CBitmap empty;	
			empty.CreateBitmap(0, 0, 1, 32, NULL);
			image.Attach(static_cast<HBITMAP>(empty.Detach()));
		}

		bitmap.Attach(image.Detach());
		srcDC.SelectObject(&bitmap);

		CBitmap thumbnail;
		thumbnail.CreateBitmap(64, 64, 1, 32, NULL);		
		thumbDC.SelectObject(&thumbnail);

		BITMAP bm;
		bitmap.GetObject(sizeof(bm), &bm);		
		thumbDC.SetStretchBltMode(COLORONCOLOR);
		thumbDC.StretchBlt(0, 0, 64, 64, &srcDC, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY);

		il.Add(&thumbnail, RGB(0, 0, 0));				
	}		
}


// CGalleryView message handlers


void CGalleryView::OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/)
{	
	TRACE(_T("OnUpdate\n"));
	GetDlgItem(IDC_ALBUM_EDIT_BUTTON)->EnableWindow(FALSE);
	GetDlgItem(IDC_ALBUM_DELETE_BUTTON)->EnableWindow(FALSE);
	GetDlgItem(IDC_ADDPICTURES_BUTTON)->EnableWindow(FALSE);

	UpdateAlbumList();

	if (!GetDocument()->GetAlbumModel()->IsIndexValid(mAblumRowIndex))
	{
		mAblumRowIndex = (mAblumRowIndex - 1) < 0 ? 0 : mAblumRowIndex - 1;
	}
	TRACE(_T("mAblumRowIndex = %d\n"), mAblumRowIndex);

	// ��������� ���� name 
	mAlbumName = GetDocument()->GetAlbumModel()->AlbumName(mAblumRowIndex);
	CString label;
	label.Format(_T("[ %s ]"), mAlbumName);
	SetDlgItemText(IDC_ALBUM_LABEL, label);

	mMyPictureList.SetImageList(&mThumbnailImageList, LVSIL_NORMAL);
	UpdatePictureList();		
}


void CGalleryView::OnAlbumEditButton()
{
	CInputDlg dlg(_T("Edit Album"));
	dlg.mLabelValue = _T("Change the album name");
	dlg.mInputValue = mAlbumName;

	if (dlg.DoModal() == IDOK)
	{
		GetDocument()->GetAlbumModel()->SetAlbumName(mAblumRowIndex, dlg.mInputValue);
		GetDocument()->UpdateAllViews(NULL);		
	}
}


void CGalleryView::OnAlbumDeleteButton()
{				
	CString message(_T("Delete record?"));
	
	if (mAlbumList.GetSelCount() != -1)
	{
		if (mAlbumList.GetSelCount() > 1)
		{
			message.Format(_T("Delete selected records?"));
			if (mAlbumList.GetSelCount() == GetDocument()->GetAlbumModel()->RowCount())
			{
				message.Format(_T("Delete all records?"));
			}
		}		
	}
	
	if (AfxMessageBox(message, MB_YESNO) == IDYES)
	{		
		int selCount = mAlbumList.GetSelCount();
		if (selCount != -1)
		{		
			CArray<int> selItemIndexs;
			selItemIndexs.SetSize(selCount);
			mAlbumList.GetSelItems(selCount, selItemIndexs.GetData());

			// ������� ��������� ������� � �������� �� ��������
			for (int i = selItemIndexs.GetCount() - 1; i >= 0; --i)
			{
				GetDocument()->GetMyPictureModel()->RemoveRows(selItemIndexs[i]);
				GetDocument()->GetAlbumModel()->RemoveRows(selItemIndexs[i], 1);
			}
		}
		else
		{
			// ������� �������� �� �������
			GetDocument()->GetMyPictureModel()->RemoveRows(mAblumRowIndex);
			// ������� ��������� ������
			GetDocument()->GetAlbumModel()->RemoveRows(mAblumRowIndex, 1);
		}

		GetDocument()->UpdateAllViews(NULL);
	}
}


void CGalleryView::OnAlbumInsertButton()
{
	CInputDlg dlg(_T("Insert Album"));
	dlg.mLabelValue = _T("Enter an album name");

	if (dlg.DoModal() == IDOK)
	{
		Album newAlbum;
		newAlbum.SetName(dlg.mInputValue);

		GetDocument()->GetAlbumModel()->AddAlbum(newAlbum);
		GetDocument()->UpdateAllViews(NULL);
	}
}


//void CGalleryView::OnLvnItemchangedAlbumList(NMHDR *pNMHDR, LRESULT *pResult)
//{
//	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);
//
//	if ((pNMLV->uChanged & LVIF_STATE) && (pNMLV->uNewState & LVIS_SELECTED))
//	{	
//		mAblumRowIndex = pNMLV->iItem;				
//		mAlbumName = GetDocument()->GetAlbumModel()->AlbumName(mAblumRowIndex);
//		SetDlgItemText(IDC_ALBUM_LABEL, mAlbumName);
//				
//		UpdatePictureList();
//	}
//	
//	*pResult = 0;
//}


void CGalleryView::OnAddPicturesButton()
{
	CFileDialog dlg(TRUE, NULL, NULL, OFN_HIDEREADONLY | OFN_ALLOWMULTISELECT,
		_T("Picture Files (*.jpg *.png)|*.jpg; *.png|All Files (*.*)|*.*|"));
	dlg.m_ofn.lpstrTitle = _T("Add Pictures");

	if (dlg.DoModal() == IDOK)
	{
		// ��������� ��������� ����� ��������
		POSITION pos = dlg.GetStartPosition();
		while (pos)
		{
			MyPicture picture(dlg.GetNextPathName(pos));
			int albumId = GetDocument()->GetAlbumModel()->AlbumId(mAblumRowIndex);
			if (albumId == -1)
				break;
			picture.SetAlbumId(albumId);
			GetDocument()->GetMyPictureModel()->AddPicture(picture);
		}
		
		UpdatePictureList();
	}
}


void CGalleryView::OnLbnSelchangeAlbumListbox()
{		
	mAblumRowIndex = mAlbumList.GetCurSel();
	mAlbumName = GetDocument()->GetAlbumModel()->AlbumName(mAblumRowIndex);
	
	CString lbl;
	lbl.Format(_T("[ %s ]"), mAlbumName);
	SetDlgItemText(IDC_ALBUM_LABEL, lbl);

	UpdatePictureList();

	GetDlgItem(IDC_ALBUM_EDIT_BUTTON)->EnableWindow(TRUE);
	GetDlgItem(IDC_ALBUM_DELETE_BUTTON)->EnableWindow(TRUE);
	GetDlgItem(IDC_ADDPICTURES_BUTTON)->EnableWindow(TRUE);
}
