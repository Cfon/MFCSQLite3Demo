#pragma once


#include "DbSqlite.h"
#include "AlbumDAO.h"
#include "MyPictureDAO.h"


const LPCTSTR DATABASE_FILENAME = _T("db\\gallery.db");
//const LPCTSTR DATABASE_FILENAME = _T(":memory:");


class CDbSQLite;

class DatabaseManager
{
public:	
	static DatabaseManager& instance()
	{
		static DatabaseManager singleton;
		return singleton;
	}

	~DatabaseManager() 
	{			
	}

	const AlbumDAO& AlbumDao() const
	{
		return  mAlbumDAO;
	}

	const MyPictureDAO& MyPictureDao() const
	{
		return  mMyPictureDAO;
	}

protected:
	DatabaseManager(const CString& path = DATABASE_FILENAME)
		: mAlbumDAO(mDb)
		, mMyPictureDAO(mDb)
	{		
		// open db	
		mDb.Open(path);
		mAlbumDAO.CreateTable();
		mMyPictureDAO.CreateTable();
	}

	DatabaseManager& operator=(const DatabaseManager& dm) = delete;

private:
	CDbSQLite mDb;
	AlbumDAO mAlbumDAO;
	MyPictureDAO mMyPictureDAO;	
};

