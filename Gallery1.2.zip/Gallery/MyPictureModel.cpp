#include "stdafx.h"
#include "MyPictureModel.h"
#include "AlbumModel.h"
#include "DatabaseManager.h"
#include "MyPicture.h"


MyPictureModel::MyPictureModel(const AlbumModel& albumModel)
	: mDataManager(DatabaseManager::instance())	
	, mAlbumId(-1)
	, mMyPictures(new MyPictures())
	, mAlbumModel(albumModel)
{
}


MyPictureModel::~MyPictureModel()
{
}


BOOL MyPictureModel::IsIndexValid(int index) const
{
	if ((index >= 0) && (index < RowCount()))
	{
		return TRUE;
	}
	return FALSE;
}


int MyPictureModel::RowCount() const
{
#ifdef _MFC_CArray	
	return mMyPictures->GetCount();
#else
	return mMyPictures->size();
#endif	
}


int MyPictureModel::MyPictureId(int index) const
{
	if (!IsIndexValid(index))
		return -1;

#ifdef _MFC_CArray	
	const MyPicture& picture = *mMyPictures->ElementAt(index);
#else	
	const MyPicture& picture = *mMyPictures->at(index);
#endif		
	return picture.Id();
}


CString MyPictureModel::MyPictureFilePath(int index) const
{
	if (!IsIndexValid(index))
		return CString();

#ifdef _MFC_CArray	
	const MyPicture& picture = *mMyPictures->ElementAt(index);
#else		
	const MyPicture& picture = *mMyPictures->at(index);
#endif	
	return picture.FilePath();
}


int MyPictureModel::AlbumId(int index) const
{
	if (!IsIndexValid(index))
		return 0;

#ifdef _MFC_CArray	
	const MyPicture& picture = *mMyPictures->ElementAt(index);
#else	
	const MyPicture& picture = *mMyPictures->at(index);
#endif		
	return picture.AlbumId();
}


void MyPictureModel::AddPicture(const MyPicture & picture) const
{
	std::unique_ptr<MyPicture> newPicture(new MyPicture(picture));
	mDataManager.MyPictureDao().Insert(*newPicture, mAlbumId);
#ifdef _MFC_CArray	
	mMyPictures->Add(std::move(newPicture));
#else		
	mMyPictures->push_back(std::move(newPicture));
#endif		
}


BOOL MyPictureModel::RemoveRows(int row, int count) const
{
	if (row < 0 || row >= RowCount() || count < 0 || (row + count) > RowCount())
		return	FALSE;

	int	countLeft = count;

#ifdef _MFC_CArray	
	while (countLeft--)
	{
		const MyPicture& picture = *mMyPictures->ElementAt(row + countLeft);
		mDataManager.MyPictureDao().Delete(picture.Id());
	}

	mMyPictures->RemoveAt(row, count);
#else				
	while (countLeft--)
	{
		const MyPicture& picture = *mMyPictures->at(row + countLeft);
		mDataManager.MyPictureDao().Delete(picture.Id());
	}

	mMyPictures->erase(mMyPictures->begin() + row, mMyPictures->begin() + row + count);
#endif
	return TRUE;
}


BOOL MyPictureModel::RemoveRows(int albumIndex) const
{		
	if (!mAlbumModel.IsIndexValid(albumIndex))
		return FALSE;
	
	int albumId = mAlbumModel.AlbumId(albumIndex);	
	mDataManager.MyPictureDao().DeletePictures(albumId);
	return TRUE;
}


void MyPictureModel::LoadPictures(int index)
{
	if (mAlbumModel.AlbumId(index) <= 0)
	{
		mMyPictures.reset(new MyPictures);
		return;
	}
	mMyPictures = mDataManager.MyPictureDao().Select(mAlbumModel.AlbumId(index));
}

