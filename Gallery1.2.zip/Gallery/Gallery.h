
// Gallery.h : main header file for the Gallery application
//
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols


// CGalleryApp:
// See Gallery.cpp for the implementation of this class
//

#include "DbSqlite.h"



class CGalleryApp : public CWinApp
{
public:
	CGalleryApp();	

// Overrides
public:
	virtual BOOL InitInstance();

// Implementation
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CGalleryApp theApp;
