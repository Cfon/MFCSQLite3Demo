#include "stdafx.h"
#include "MyPictureDAO.h"
#include "MyPicture.h"
#include "DbSqlite.h"
#include <memory>


/* SQL queries */
static LPCTSTR gCreateTableQuery
{
	_T("CREATE TABLE IF NOT EXISTS pictures (")
	_T(" id INTEGER PRIMARY KEY, ")
	_T(" filePath TEXT, ")
	_T(" albumId INTEGER REFERENCES albums(id) ")
	_T(" ON DELETE RESTRICT ")
	//_T(" DEFERRABLE INITIALLY DEFERRED")
	_T(")")
};

static LPCTSTR gInsertQuery{ _T("INSERT INTO pictures (filePath, albumId) VALUES (?, ?)") };
static LPCTSTR gUpdateQuery{ _T("UPDATE pictures SET filePath = ?, albumId = ? WHERE id = ?") };
static LPCTSTR gDeleteQuery{ _T("DELETE FROM pictures WHERE id = ?") };
static LPCTSTR gDeletePicturesQuery{ _T("DELETE FROM pictures WHERE albumId = ?") };

static LPCTSTR gSelectQuery
{
	_T("SELECT id, filePath, albumId FROM pictures")
	_T(" WHERE albumId = ?")
};


MyPictureDAO::MyPictureDAO(CDbSQLite& db)
	: mDb(db)
{
}


MyPictureDAO::~MyPictureDAO()
{
}


void MyPictureDAO::CreateTable() const
{
	if (!mDb.DirectStatement(gCreateTableQuery))
	{
		TRACE(_T("table 'albums' is not created\n"));
		ASSERT(FALSE);
	}
}


void MyPictureDAO::Insert(MyPicture & picture, int albumId) const
{
	{
		std::unique_ptr<CSqlStatement> stmt(mDb.Statement(gInsertQuery));
		stmt->Bind(0, picture.FilePath());
		stmt->Bind(1, picture.AlbumId());
		stmt->Execute();
	}

	CString query(_T("SELECT last_insert_rowid()"));
	std::unique_ptr<CSqlStatement> stmt(mDb.Statement(query));
	stmt->NextRow();
	picture.SetId(stmt->ValueInt(0));
}


void MyPictureDAO::Delete(int id) const
{
	std::unique_ptr<CSqlStatement> stmt(mDb.Statement(gDeleteQuery));
	stmt->Bind(0, id);
	stmt->Execute();
}


void MyPictureDAO::DeletePictures(int albumId) const
{
	std::unique_ptr<CSqlStatement> stmt(mDb.Statement(gDeletePicturesQuery));
	stmt->Bind(0, albumId);
	stmt->Execute();
}


std::unique_ptr<MyPictures> MyPictureDAO::Select(int albumId) const
{
	std::unique_ptr<MyPictures> upPictures(new MyPictures);
	std::unique_ptr<CSqlStatement> stmt(mDb.Statement(gSelectQuery));
	stmt->Bind(0, albumId);

	enum PicturesFields { id, filePath, albumId };

	while (stmt->NextRow())
	{
		std::unique_ptr<MyPicture> picture(new MyPicture);
		picture->SetId(stmt->ValueInt(PicturesFields::id));
		picture->SetFilePath(stmt->ValueString(PicturesFields::filePath));
		picture->SetAlbumId(stmt->ValueInt(PicturesFields::albumId));
#ifdef _MFC_CArray
		upPictures->Add(std::move(picture));
#else	
		upPictures->push_back(std::move(picture));
#endif // _MFC_CArray
	}

	return upPictures;
}

