#pragma once

#include <memory>
#include <vector>


class Album;
class CDbSQLite;

#define _MFC_CArray
#ifdef _MFC_CArray	
typedef CArray<std::shared_ptr<Album>> Albums;
#else
typedef std::vector<std::unique_ptr<Album>> Albums;
#endif 


class AlbumDAO
{	
public:
	AlbumDAO(CDbSQLite& db);
	~AlbumDAO();	
	
	void CreateTable() const;	
	void Insert(Album& album) const;
	void Update(const Album& album) const;
	void Delete(int albumId) const;
	std::unique_ptr<Albums> Select() const;
private:
	CDbSQLite& mDb;
};

