#pragma once

#include <memory>
#include "MyPictureDAO.h"


class AlbumModel;
class MyPicture;
class DatabaseManager;


class MyPictureModel
{
public:
	MyPictureModel(const AlbumModel& albumModel);
	~MyPictureModel();

	BOOL IsIndexValid(int index) const;	
	int	RowCount() const;

	int MyPictureId(int index) const;
	CString MyPictureFilePath(int index) const;
	int AlbumId(int index) const;
	void AddPicture(const MyPicture& picture) const;
	BOOL RemoveRows(int	row, int count) const;
	BOOL RemoveRows(int	albumIndex) const;
	void LoadPictures(int index);

private:		
	DatabaseManager& mDataManager;
	std::unique_ptr<MyPictures> mMyPictures; // picture data model
	int	mAlbumId;
	const AlbumModel& mAlbumModel;
};

