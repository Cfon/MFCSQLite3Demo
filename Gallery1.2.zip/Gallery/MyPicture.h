#pragma once

class MyPicture
{
public:
	MyPicture(const CString& filePath = _T(""))
		: mId(-1)
		, mFilePath(filePath)
		, mAlbumId(-1)
	{}

	~MyPicture() {}

	// Attributes
	int Id() const { return mId; }
	void SetId(int id) { mId = id; }
	CString FilePath() const { return mFilePath; }
	void SetFilePath(const CString& filePath) { mFilePath = filePath; }
	int AlbumId() const { return mAlbumId; }
	void SetAlbumId(int albumId){ mAlbumId = albumId; }

	// Operations

	// Implemantation
private:
	int mId;
	CString mFilePath;
	int mAlbumId;
};

