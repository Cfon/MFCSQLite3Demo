#pragma once

#include "CustomDlg.h"


// CArtistDlg dialog

class CArtistDlg : public CCustomDlg
{
	DECLARE_DYNAMIC(CArtistDlg)

public:
	CArtistDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CArtistDlg();

// Dialog Data
	enum { IDD = IDD_ARTIST_DIALOG };

	virtual void InitDialog(int artistId) override;
	virtual void SetControls(const CArrayStr& values, int id) override;
protected:	
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	CStatic mPicture;
	CString mArtistName;
	CListCtrl mAlbumsList;
	int mAlbumCount;	
};


class ArtistDlgFactory : public CustomDlgFactory
{
public:
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg()
	{
		std::unique_ptr<CCustomDlg> dlg(new CArtistDlg);
		return dlg;
	}
};
