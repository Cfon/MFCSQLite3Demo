#pragma once

#include "CustomDlg.h"
#include "afxdtctl.h"
//#include "ATLComTime.h"


// CEmployeeDlg dialog

class CEmployeeDlg : public CCustomDlg
{
	DECLARE_DYNAMIC(CEmployeeDlg)

public:
	CEmployeeDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CEmployeeDlg();

// Dialog Data
	enum { IDD = IDD_EMPLOYEE_DIALOG };

	virtual void InitDialog(int id) override;
	virtual void SetControls(const CArrayStr& values, int id) override;
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	CStatic mPictureCtrl;	
	CString mAddressValue;	
	CString mCityValue;
	CString mCountryValue;
	CString mEmailValue;
	CString mFaxValue;
	CString mFirstNameValue;	
	CString mLastNameValue;
	CString mPhoneValue;
	CString mPostalCodeValue;
	CString mStateValue;
	int mReportsToIndex;
	CString mTitleValue;	
	CString mHireDateValue;
	CString mBirthDateValue;
	CComboBox mReportsToCombo;
	CEdit mReporteesEdit;
	CDateTimeCtrl mHireDateCtrl;
	CDateTimeCtrl mBirthDateCtrl;
};


class EmployeeDlgFactory : public CustomDlgFactory
{
public:
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg() override
	{
		std::unique_ptr<CCustomDlg> dlg(new CEmployeeDlg);
		return dlg;
	}
};
