#pragma once

#include "CustomDlg.h"


// CMediaTypeDlg dialog

class CMediaTypeDlg : public CCustomDlg
{
	DECLARE_DYNAMIC(CMediaTypeDlg)

public:
	CMediaTypeDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CMediaTypeDlg();

// Dialog Data
	enum { IDD = IDD_MEDIATYPE_DIALOG };

	virtual void InitDialog(int mediaTypeId) override;
	virtual void SetControls(const CArrayStr& values, int mediaTypeId) override;
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:	
	CString mMediaTypeName;
	CListCtrl mTrackList;
	int mTrackCount;
	virtual BOOL OnInitDialog();
};


class MediaTypeDlgFactory : public CustomDlgFactory
{
public:
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg()
	{
		std::unique_ptr<CCustomDlg> dlg(new CMediaTypeDlg);
		return dlg;
	}
};
