// InvoiceDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "InvoiceDlg.h"


// CInvoiceDlg dialog


enum InvoiceType 
{
	invoiceId, customerId, invoiceDate, 
	billingAddress, billingCity, billingState,
	billingCountry, billingPostalCode, invoiceTotal
};

static LPCTSTR gInvoiceQuery
{
	_T("SELECT invoiceId, customerId, ")
	_T(" strftime('%%Y-%%m-%%d', invoiceDate) invoiceDate, ")
	_T(" billingAddress, billingCity, billingState, ")
	_T(" billingCountry, billingPostalCode, total ")
	_T("FROM invoices ")
	_T("WHERE invoiceId = %d ")
};


enum CustomersType { lastFirstName };

static LPCTSTR gCustomersQuery
{
	_T("SELECT (lastName||', '||firstName) lastFirstName FROM customers ")
};


static LPCTSTR gOrderItemsQuery
{
	_T("SELECT it.invoiceId, t.name 'Track', it.unitPrice, it.quantity ")
	_T("FROM invoice_items it ")
	_T("INNER JOIN tracks t USING (trackId) ")
	_T("WHERE it.invoiceId = %d ")
}; 


IMPLEMENT_DYNAMIC(CInvoiceDlg, CCustomDlg)

CInvoiceDlg::CInvoiceDlg(CWnd* pParent /*=NULL*/)
	: CCustomDlg(CInvoiceDlg::IDD, pParent)
	, mBillingCountryValue(_T(""))
	, mBillingAddressValue(_T(""))
	, mBillingCityValue(_T(""))
	, mBillingPostalCodeValue(_T(""))
	, mBillingStateValue(_T(""))	
	, mInvoiceDateValue(_T(""))
	, mInvoiceIDValue(0)
	, mInvoiceTotalValue(0)
	, mCustomerIndex(0)
{

}

CInvoiceDlg::~CInvoiceDlg()
{
}

void CInvoiceDlg::DoDataExchange(CDataExchange* pDX)
{
	CCustomDlg::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_INVOICE_PICTURE, mPictureCtrl);
	DDX_Text(pDX, IDC_INVOICE_BILLINGCOUNTRY_EDIT, mBillingCountryValue);
	DDX_Text(pDX, IDC_INVOICE_BILLINGADDRESS_EDIT, mBillingAddressValue);
	DDX_Text(pDX, IDC_INVOICE_BILLINGCITY_EDIT, mBillingCityValue);
	DDX_Text(pDX, IDC_INVOICE_BILLINGPOSTALCODE_EDIT, mBillingPostalCodeValue);
	DDX_Text(pDX, IDC_INVOICE_BILLINGSTATE_EDIT, mBillingStateValue);
	DDX_Text(pDX, IDC_INVOICE_DATE_EDIT, mInvoiceDateValue);
	DDX_Text(pDX, IDC_INVOICE_ID_EDIT, mInvoiceIDValue);
	DDX_Control(pDX, IDC_INVOICE_ORDERITEMS_LIST, mOrderItemsList);
	DDX_Text(pDX, IDC_INVOICE_TOTAL_EDIT, mInvoiceTotalValue);
	DDX_CBIndex(pDX, IDC_INVOICE_CUSTOMER_COMBO, mCustomerIndex);
	DDX_Control(pDX, IDC_INVOICE_CUSTOMER_COMBO, mCustomersCombo);
}


void CInvoiceDlg::InitDialog(int id) 
{
	LoadDataByQuery(gInvoiceQuery, id);
}


void CInvoiceDlg::SetControls(const CArrayStr& values, int id) 
{	
	SetId(id);	
	mBillingCountryValue = values[InvoiceType::billingCountry];
	mBillingAddressValue = values[InvoiceType::billingAddress];
	mBillingCityValue = values[InvoiceType::billingCity];
	mBillingPostalCodeValue = values[InvoiceType::billingPostalCode];
	mBillingStateValue = values[InvoiceType::billingState];
	mCustomerIndex = _ttoi(values[InvoiceType::customerId]);
	mInvoiceDateValue = values[InvoiceType::invoiceDate];
	mInvoiceIDValue = _ttoi(values[InvoiceType::invoiceId]);
	mInvoiceTotalValue = _ttof(values[InvoiceType::invoiceTotal]);
}


BEGIN_MESSAGE_MAP(CInvoiceDlg, CCustomDlg)
END_MESSAGE_MAP()


// CInvoiceDlg message handlers


BOOL CInvoiceDlg::OnInitDialog()
{
	CCustomDlg::OnInitDialog();
	
	SetSystemMenuIcon(IDI_INVOICE_ICON);
		
	HICON hIcon = (HICON)LoadImage(AfxGetApp()->m_hInstance,
		MAKEINTRESOURCE(IDI_INVOICE_ICON), IMAGE_ICON, 128, 128, 0);
	ASSERT(hIcon);
	mPictureCtrl.SetIcon(hIcon);

	FillCombo(&mCustomersCombo, gCustomersQuery, CustomersType::lastFirstName);
	mCustomersCombo.SetCurSel(mCustomerIndex);

	FillListCtrl(&mOrderItemsList, gOrderItemsQuery, GetId());
	SetGridStyle(&mOrderItemsList);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

