// GenreDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "GenreDlg.h"
#include "CustomDlg.h"


// CGenreDlg dialog


enum GenreType { genreId, genreName, tracksCount };

static LPCTSTR gGenreQuery 
{
	_T("SELECT g.genreId, g.name, COUNT(t.genreId) 'tracks count' FROM genres g ")
	_T("LEFT JOIN tracks t USING (genreId) ")
	_T("GROUP BY g.genreId ")
	_T("HAVING g.genreId = %d")
};


static LPCTSTR gTracksQuery
{
	_T("SELECT t.trackId, t.name 'Track', a.title 'Album', m.name 'Media type', ")
	_T("t.composer, t.milliseconds, t.bytes, t.unitprice ")
	_T("FROM tracks t ")
	_T("INNER JOIN albums a USING (albumId) ")
	_T("INNER JOIN media_types m USING (mediaTypeId) ")
	_T("WHERE t.genreId = %d ")
};


IMPLEMENT_DYNAMIC(CGenreDlg, CCustomDlg)

CGenreDlg::CGenreDlg(CWnd* pParent /*=NULL*/)
	: CCustomDlg(CGenreDlg::IDD, pParent)
	, mGenreName(_T(""))
	, mTrackCount(0)	
{

}

CGenreDlg::~CGenreDlg()
{
}

void CGenreDlg::DoDataExchange(CDataExchange* pDX)
{
	CCustomDlg::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_GENRE_NAME_EDIT, mGenreName);
	DDX_Control(pDX, IDC_GENRE_TRACK_LIST, mTrackList);
	DDX_Text(pDX, IDC_GENRE_TRACKCOUNT_EDIT, mTrackCount);
}


void CGenreDlg::InitDialog(int id)
{
	LoadDataByQuery(gGenreQuery, id);
}


void CGenreDlg::SetControls(const CArrayStr& values, int id)
{
	SetId(id);
	mGenreName = values[GenreType::genreName];
	mTrackCount = _ttoi(values[GenreType::tracksCount]);
}


BEGIN_MESSAGE_MAP(CGenreDlg, CCustomDlg)
END_MESSAGE_MAP()


// CGenreDlg message handlers


BOOL CGenreDlg::OnInitDialog()
{
	CCustomDlg::OnInitDialog();

	SetSystemMenuIcon(IDI_GENRE_ICON);

	FillListCtrl(&mTrackList, gTracksQuery, GetId());
	mTrackList.SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE, 0, 
		LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
