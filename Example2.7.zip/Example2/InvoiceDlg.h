#pragma once

#include "CustomDlg.h"
#include "afxwin.h"
#include "afxcmn.h"


// CInvoiceDlg dialog

class CInvoiceDlg : public CCustomDlg
{
	DECLARE_DYNAMIC(CInvoiceDlg)

public:
	CInvoiceDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CInvoiceDlg();

// Dialog Data
	enum { IDD = IDD_INVOICE_DIALOG };

	virtual void InitDialog(int id) override;
	virtual void SetControls(const CArrayStr& values, int id) override;
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	CStatic mPictureCtrl;
	CString mBillingCountryValue;
	CString mBillingAddressValue;
	CString mBillingCityValue;
	CString mBillingPostalCodeValue;
	CString mBillingStateValue;	
	CString mInvoiceDateValue;
	int mInvoiceIDValue;
	CListCtrl mOrderItemsList;
	double mInvoiceTotalValue;
	int mCustomerIndex;
	CComboBox mCustomersCombo;
};


class InvoiceDlgFactory : public CustomDlgFactory
{
public:
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg() override
	{
		return std::unique_ptr<CCustomDlg>(new CInvoiceDlg);
	}
};
