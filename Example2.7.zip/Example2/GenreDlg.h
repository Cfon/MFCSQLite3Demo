#pragma once
#include "CustomDlg.h"


// CGenreDlg dialog

class CGenreDlg : public CCustomDlg
{
	DECLARE_DYNAMIC(CGenreDlg)

public:
	CGenreDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CGenreDlg();

// Dialog Data
	enum { IDD = IDD_GENRE_DIALOG };

	virtual void InitDialog(int id) override;
	virtual void SetControls(const CArrayStr& values, int id) override;
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	CString mGenreName;
	CListCtrl mTrackList;
	int mTrackCount;	
};


class GenreDlgFactory : public CustomDlgFactory
{
public:
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg()
	{
		std::unique_ptr<CCustomDlg> dlg(new CGenreDlg);
		return dlg;
	}
};
