// MediaTypeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "MediaTypeDlg.h"
#include "afxdialogex.h"


// CMediaTypeDlg dialog

enum MediaTypeType { mediaTypeId, mediaTypeName, tracksCount };

static LPCTSTR gMediaTypeQuery
{
	_T("SELECT m.mediaTypeId, m.name, COUNT(t.mediaTypeId) 'tracks count' ")
	_T(" FROM media_types m ")
	_T(" INNER JOIN tracks t USING (mediaTypeId) ")
	_T(" GROUP BY m.mediaTypeId")
	_T(" HAVING m.mediaTypeId = %d")
}; 


static LPCTSTR gTracksQuery
{
	_T("SELECT t.trackId, t.name 'Track', a.title 'Album', g.name 'Genre', t.composer, t.unitprice ")	
	_T("FROM tracks t ")
	_T("INNER JOIN albums a USING (albumId) ")
	_T("INNER JOIN genres g USING (genreId) ")
	_T("WHERE t.mediaTypeId = %d ")
};


IMPLEMENT_DYNAMIC(CMediaTypeDlg, CCustomDlg)

CMediaTypeDlg::CMediaTypeDlg(CWnd* pParent /*=NULL*/)
: CCustomDlg(CMediaTypeDlg::IDD, pParent)
	, mMediaTypeName(_T(""))
	, mTrackCount(0)	
{

}

CMediaTypeDlg::~CMediaTypeDlg()
{
}


void CMediaTypeDlg::InitDialog(int mediaTypeId)
{
	LoadDataByQuery(gMediaTypeQuery, mediaTypeId);
}


void CMediaTypeDlg::SetControls(const CArrayStr& values, int id)
{
	SetId(id);
	mMediaTypeName = values[MediaTypeType::mediaTypeName];
	mTrackCount = _ttoi(values[MediaTypeType::tracksCount]);
}


void CMediaTypeDlg::DoDataExchange(CDataExchange* pDX)
{
	CCustomDlg::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_MEDIATYPE_NAME_EDIT, mMediaTypeName);
	DDX_Control(pDX, IDC_MEDIATYPE_TRACK_LIST, mTrackList);
	DDX_Text(pDX, IDC_MEDIATYPE_TRACKCOUNT_EDIT, mTrackCount);
}


BEGIN_MESSAGE_MAP(CMediaTypeDlg, CCustomDlg)
END_MESSAGE_MAP()


// CMediaTypeDlg message handlers


BOOL CMediaTypeDlg::OnInitDialog()
{
	CCustomDlg::OnInitDialog();

	SetSystemMenuIcon(IDI_MEDIATYPE_ICON);

	FillListCtrl(&mTrackList, gTracksQuery, GetId());	
	mTrackList.SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE, 0,
		LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
