// PlaylistDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "PlaylistDlg.h"
//#include "afxdialogex.h"
#include <memory>

// CPlaylistDlg dialog

enum PlaylistType {	playlistId, playlistName, tracksCount };

static LPCTSTR gPlaylistQuery 
{
	_T("SELECT p.playlistId, p.name, COUNT(pt.trackId) 'tracks count' ")
	_T(" FROM playlists p ")
	_T(" LEFT JOIN playlist_track pt ON p.playlistId = pt.playlistId ")
	_T(" LEFT JOIN tracks t ON pt.trackId = t.trackId ")
	_T(" GROUP BY p.playlistId")
	_T(" HAVING p.playlistId = %d")
};


enum TracksQuery { trackId, name };

static LPCTSTR gTracksQuery
{	
	_T("SELECT pt.playlistId, t.name FROM playlist_track pt ")
	_T(" INNER JOIN tracks t USING (trackId) ")
	_T(" WHERE pt.playlistId = %d")
};



IMPLEMENT_DYNAMIC(CPlaylistDlg, CCustomDlg)

CPlaylistDlg::CPlaylistDlg(CWnd* pParent /*=NULL*/)
: CCustomDlg(CPlaylistDlg::IDD, pParent)
	, mTrackCount(0)
	, mPlaylistName(_T(""))
{

}

CPlaylistDlg::~CPlaylistDlg()
{
}


void CPlaylistDlg::InitDialog(int playlistId)
{
	LoadDataByQuery(gPlaylistQuery, playlistId);
}


void CPlaylistDlg::SetControls(const CArrayStr& values, int id)
{
	SetId(id);
	mPlaylistName = values[PlaylistType::playlistName];
	mTrackCount = _ttoi(values[PlaylistType::tracksCount]);
}


void CPlaylistDlg::DoDataExchange(CDataExchange* pDX)
{
	CCustomDlg::DoDataExchange(pDX);	
	DDX_Control(pDX, IDC_PLAYLIST_TRACK_LIST, mTrackList);
	DDX_Text(pDX, IDC_PLAYLIST_TRACKCOUNT_EDIT, mTrackCount);
	DDX_Text(pDX, IDC_PLAYLIST_NAME_EDIT, mPlaylistName);
}


BEGIN_MESSAGE_MAP(CPlaylistDlg, CCustomDlg)
END_MESSAGE_MAP()


// CPlaylistDlg message handlers


BOOL CPlaylistDlg::OnInitDialog()
{
	CCustomDlg::OnInitDialog();

	// �������� ������ � ��������� ����
	SetSystemMenuIcon(IDI_PLAYLIST_ICON);

	FillListCtrl(&mTrackList, gTracksQuery, GetId());
	mTrackList.SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE, 0,
		LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}
