#pragma once

#include "Example2Doc.h"
#include <memory>


// CCustomDlg dialog

class CCustomDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CCustomDlg)

public:	
	CCustomDlg(UINT nIDTemplate, CWnd *pParent = NULL); // standard constructor
	virtual ~CCustomDlg();
	
// Dialog Data	

	typedef CArray<CString, LPCTSTR> CArrayStr;

	virtual void InitDialog(int id) = 0;		
	int GetId() const;
	void SetId(int id);	
protected:	
	virtual void SetControls(const CArrayStr& values, int id) = 0;
		
	void SetSystemMenuIcon(UINT nIDResource);
	void LoadDataByQuery(LPCTSTR query, int id);	
	void FillCombo(CComboBox* pCombo, LPCTSTR query, int fieldZeroIndex);
	void FillListCtrl(CListCtrl* pList, LPCTSTR query, int id);
	void FillEdit(CEdit* pEdit, LPCTSTR query, int fieldZeroIndex, int id);	
	void SetGridStyle(CListCtrl* pList);
private:
	int mId;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
};

// ������� �������� ���� �������
class CustomDlgFactory
{
public:
	CustomDlgFactory() {}
	virtual ~CustomDlgFactory() {}
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg() = 0;
};

