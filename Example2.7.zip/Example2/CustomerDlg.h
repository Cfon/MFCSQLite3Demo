#pragma once

#include "CustomDlg.h"


// CCustomerDlg dialog

class CCustomerDlg : public CCustomDlg
{
	DECLARE_DYNAMIC(CCustomerDlg)

public:
	CCustomerDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCustomerDlg();

// Dialog Data
	enum { IDD = IDD_CUSTOMER_DIALOG };


	virtual void InitDialog(int customerId) override;
	virtual void SetControls(const CArrayStr& values, int id) override;
protected:	
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();		
	CComboBox mSupportRepCombo;	
	CStatic mPictureCtrl;
	CString mAddressValue;
	CString mCityValue;
	CString mCompanyValue;
	CString mCountryValue;
	CString mEmailValue;
	CString mFaxValue;
	CString mFirstNameValue;
	CString mLastNameValue;
	CString mPhoneValue;
	CString mPostalCodeValue;
	CString mStateValue;
	int mSupportRepValue;	
};


class CustomerDlgFactory : public CustomDlgFactory
{
public:
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg()
	{
		std::unique_ptr<CCustomDlg> dlg(new CCustomerDlg);
		return dlg;
	}
};