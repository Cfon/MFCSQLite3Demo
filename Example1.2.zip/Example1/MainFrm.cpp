
// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Example1.h"

#include "MainFrm.h"
#include "DbSqlite.h"
#include <memory>
#include "Example1Doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
	ON_CBN_SELCHANGE(ID_SORTBY_COMBO, &CMainFrame::OnCbnSelchangeSortByCombo)	
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{	
	// TODO: add member initialization code here
}

CMainFrame::~CMainFrame()
{
	// Destroy the bitmap objects if they are loaded successfully 
	// in OnCreate.
	/*if (mFirstPageBitmap.m_hObject)
		mFirstPageBitmap.DeleteObject();

	if (mPriorPageBitmap.m_hObject)
		mPriorPageBitmap.DeleteObject();

	if (mNextPageBitmap.m_hObject)
		mNextPageBitmap.DeleteObject();

	if (mLastPageBitmap.m_hObject)
		mLastPageBitmap.DeleteObject();*/
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{	
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT));


	// ��������� �����-������ � ������
	int index = m_wndToolBar.GetToolBarCtrl().CommandToIndex(ID_SORTBY_COMBO);		
	m_wndToolBar.SetButtonInfo(index, ID_SORTBY_COMBO, TBBS_SEPARATOR, 205);

	CRect rect;
	m_wndToolBar.GetToolBarCtrl().GetItemRect(index, &rect);
	rect.left += 5;

	if (!mSortByCombo.Create(CBS_DROPDOWNLIST /*| CBS_SORT*/ | WS_VISIBLE |
		WS_TABSTOP | WS_VSCROLL, rect, &m_wndToolBar, ID_SORTBY_COMBO))
	{
		TRACE(_T("Failed to create combobox\n"));
		return FALSE;
	}		
	
	CFont font;
	LOGFONT lf{ 0 };
	_tcscpy_s(lf.lfFaceName, _T("Consolas"));
	lf.lfHeight = -12;
	font.CreateFontIndirect(&lf);	
	mSortByCombo.SetFont(&font);
	font.Detach();

	FillSortByCombo(theApp.mTableName);


	// TODO: Delete these three lines if you don't want the toolbar to be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);


	// The code fragment below is from CMainFrame::OnCreate and shows 
	// how to associate bitmaps with the "Bitmap" menu item. 
	// Whether the "Bitmap" menu item is checked or unchecked, Windows 
	// displays the appropriate bitmap next to the menu item. Both 
	// IDB_CHECKBITMAP and IDB_UNCHECKBITMAP bitmaps are loaded 
	// in OnCreate() and destroyed in the destructor of CMainFrame class. 
	// CMainFrame is a CFrameWnd-derived class.

	// Load bitmaps from resource. Both m_CheckBitmap and m_UnCheckBitmap
	// are member variables of CMainFrame class of type CBitmap.
	/*ASSERT(mFirstPageBitmap.LoadBitmap(IDB_FIRSTPAGE));
	ASSERT(mPriorPageBitmap.LoadBitmap(IDB_PRIORPAGE));
	ASSERT(mNextPageBitmap.LoadBitmap(IDB_NEXTPAGE));
	ASSERT(mLastPageBitmap.LoadBitmap(IDB_LASTPAGE));*/

	// Associate bitmaps with the "Bitmap" menu item. 
	/*CMenu* pMenu = GetMenu();
	CMenu* pSub = pMenu->GetSubMenu(1);
	ASSERT(pSub->SetMenuItemBitmaps(ID_NAVIGATION_FIRSTPAGE, MF_BYCOMMAND, &mFirstPageBitmap, NULL));
	ASSERT(pSub->SetMenuItemBitmaps(ID_NAVIGATION_PRIORPAGE, MF_BYCOMMAND, &mPriorPageBitmap, NULL));
	ASSERT(pSub->SetMenuItemBitmaps(ID_NAVIGATION_NEXTPAGE, MF_BYCOMMAND, &mNextPageBitmap, NULL));
	ASSERT(pSub->SetMenuItemBitmaps(ID_NAVIGATION_LASTPAGE, MF_BYCOMMAND, &mLastPageBitmap, NULL));
	*/
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}
#endif //_DEBUG


void CMainFrame::FillSortByCombo(const CString& tableName)
{		
	// ������ ������ �����
	CString query;
	query.Format(_T("SELECT * FROM %s LIMIT 0"), tableName);		
	std::unique_ptr<CSqlStatement> stat(theApp.mSQLiteDB.Statement(query));
	ASSERT(stat);

	// ������� ������
	mSortByCombo.ResetContent();

	int fieldCount = stat->Fields();
	CString fieldName;

	for (int i = 0; i < fieldCount; ++i)
	{
		fieldName = stat->FieldName(i);
		fieldName.MakeUpper();
		mSortByCombo.AddString(fieldName);
	}

	mSortByCombo.SetCurSel(0);	

	CString sortBy;
	mSortByCombo.GetWindowText(sortBy);
	theApp.mSortByField = sortBy;
}


// CMainFrame message handlers


void CMainFrame::OnCbnSelchangeSortByCombo()
{		
	CString sortBy;
	mSortByCombo.GetWindowText(sortBy);

	theApp.mSortByField = sortBy;	
	CExample1Doc::GetDoc()->OnNewDocument();
	CExample1Doc::GetDoc()->UpdateAllViews(NULL);
}
