
// Example1.h : main header file for the Example1 application
//
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols
#include "DbSqlite.h"

// CExample1App:
// See Example1.cpp for the implementation of this class
//

class CExample1App : public CWinApp
{
public:
	CExample1App();	

// Overrides
public:
	virtual BOOL InitInstance();

// Implementation
private:
	CDbSQLite mSQLiteDB;
	CString mDBFilename;
	bool mIsDbConnected;
	CString mTableName;	
	CString mSortByField;
	
	//CArray<CString, LPCTSTR> mTableNames;

	friend class CExample1Doc;
	friend class CMainFrame;

public:
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()	
};

extern CExample1App theApp;
