
// Example1Doc.cpp : implementation of the CExample1Doc class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "Example1.h"
#endif

#include "Example1Doc.h"
#include "Example1View.h"
#include <memory>
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif



// CExample1Doc

IMPLEMENT_DYNCREATE(CExample1Doc, CDocument)

BEGIN_MESSAGE_MAP(CExample1Doc, CDocument)
	ON_COMMAND(ID_TABLES_ALBUMS, &CExample1Doc::OnTablesAlbums)
	ON_COMMAND(ID_TABLES_CUSTOMERS, &CExample1Doc::OnTablesCustomers)
	ON_COMMAND(ID_TABLES_ARTISTS, &CExample1Doc::OnTablesArtists)
	ON_COMMAND(ID_TABLES_TRACKS, &CExample1Doc::OnTablesTracks)
	ON_COMMAND(ID_TABLES_GENRES, &CExample1Doc::OnTablesGenres)
	ON_COMMAND(ID_TABLES_MEDIATYPES, &CExample1Doc::OnTablesMediatypes)
	ON_COMMAND(ID_TABLES_PLAYLISTS, &CExample1Doc::OnTablesPlaylists)	
	ON_COMMAND(ID_TABLES_PLAYLISTTRACK, &CExample1Doc::OnTablesPlaylisttrack)
	ON_COMMAND(ID_TABLES_EMPLOYEES, &CExample1Doc::OnTablesEmployees)
	ON_COMMAND(ID_TABLES_INVOICES, &CExample1Doc::OnTablesInvoices)
	ON_COMMAND(ID_TABLES_INVOICEITEMS, &CExample1Doc::OnTablesInvoiceitems)
	ON_UPDATE_COMMAND_UI(ID_TABLES_ALBUMS, &CExample1Doc::OnUpdateTablesAlbums)
	ON_UPDATE_COMMAND_UI(ID_TABLES_CUSTOMERS, &CExample1Doc::OnUpdateTablesCustomers)
	ON_UPDATE_COMMAND_UI(ID_TABLES_ARTISTS, &CExample1Doc::OnUpdateTablesArtists)
	ON_UPDATE_COMMAND_UI(ID_TABLES_TRACKS, &CExample1Doc::OnUpdateTablesTracks)
	ON_UPDATE_COMMAND_UI(ID_TABLES_GENRES, &CExample1Doc::OnUpdateTablesGenres)
	ON_UPDATE_COMMAND_UI(ID_TABLES_MEDIATYPES, &CExample1Doc::OnUpdateTablesMediatypes)
	ON_UPDATE_COMMAND_UI(ID_TABLES_PLAYLISTS, &CExample1Doc::OnUpdateTablesPlaylists)
	ON_UPDATE_COMMAND_UI(ID_TABLES_PLAYLISTTRACK, &CExample1Doc::OnUpdateTablesPlaylisttrack)
	ON_UPDATE_COMMAND_UI(ID_TABLES_EMPLOYEES, &CExample1Doc::OnUpdateTablesEmployees)
	ON_UPDATE_COMMAND_UI(ID_TABLES_INVOICES, &CExample1Doc::OnUpdateTablesInvoices)
	ON_UPDATE_COMMAND_UI(ID_TABLES_INVOICEITEMS, &CExample1Doc::OnUpdateTablesInvoiceitems)
END_MESSAGE_MAP()


// CExample1Doc construction/destruction

CExample1Doc::CExample1Doc()	
	: mSQLiteStatement(NULL)	
	, mCurRowN(0)	
{	
}

CExample1Doc::~CExample1Doc()
{	
}

BOOL CExample1Doc::OnNewDocument()
{
	TRACE("CExample1Doc::OnNewDocument\n");
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)


	if (mSQLiteStatement)
		delete mSQLiteStatement;			

	// ��������� ������ � ��		
	CString query;
	query.Format(_T("SELECT * FROM %s ORDER BY %s ASC LIMIT %d OFFSET %d"),
		theApp.mTableName, 
		theApp.mSortByField,
		CExample1View::cRowCountInPage, 
		mCurRowN);

	mSQLiteStatement = theApp.mSQLiteDB.Statement(query);
	ASSERT(mSQLiteStatement);

	return TRUE;
}


int CExample1Doc::GetRecordCount() const
{
	int recordCount = 0;

	// �������� ����� ������� � ������ ������
	while (mSQLiteStatement->NextRow())
	{
		++recordCount;
	}

	return recordCount;
}


int CExample1Doc::GetAllRecordCount() 
{
	int recordCount = 0;

	// ��������� ������ � ��		
	CString query;
	query.Format(_T("SELECT COUNT(*) FROM %s"), theApp.mTableName);
	std::unique_ptr<CSqlStatement> stat(theApp.mSQLiteDB.Statement(query));	
	ASSERT(stat);

	if (stat->NextRow())
	{
		recordCount = stat->ValueInt(0);
	}

	return recordCount;
}


void CExample1Doc::SelectTable(const CString& tableName)
{
	theApp.mTableName = tableName;
	CMainFrame::GetFrame()->FillSortByCombo(tableName);
	mCurRowN = 0;
	OnNewDocument();
	UpdateAllViews(NULL);		
}


// CExample1Doc serialization

void CExample1Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

#ifdef SHARED_HANDLERS

// Support for thumbnails
void CExample1Doc::OnDrawThumbnail(CDC& dc, LPRECT lprcBounds)
{
	// Modify this code to draw the document's data
	dc.FillSolidRect(lprcBounds, RGB(255, 255, 255));

	CString strText = _T("TODO: implement thumbnail drawing here");
	LOGFONT lf;

	CFont* pDefaultGUIFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	pDefaultGUIFont->GetLogFont(&lf);
	lf.lfHeight = 36;

	CFont fontDraw;
	fontDraw.CreateFontIndirect(&lf);

	CFont* pOldFont = dc.SelectObject(&fontDraw);
	dc.DrawText(strText, lprcBounds, DT_CENTER | DT_WORDBREAK);
	dc.SelectObject(pOldFont);
}

// Support for Search Handlers
void CExample1Doc::InitializeSearchContent()
{
	CString strSearchContent;
	// Set search contents from document's data. 
	// The content parts should be separated by ";"

	// For example:  strSearchContent = _T("point;rectangle;circle;ole object;");
	SetSearchContent(strSearchContent);
}

void CExample1Doc::SetSearchContent(const CString& value)
{
	if (value.IsEmpty())
	{
		RemoveChunk(PKEY_Search_Contents.fmtid, PKEY_Search_Contents.pid);
	}
	else
	{
		CMFCFilterChunkValueImpl *pChunk = NULL;
		ATLTRY(pChunk = new CMFCFilterChunkValueImpl);
		if (pChunk != NULL)
		{
			pChunk->SetTextValue(PKEY_Search_Contents, value, CHUNK_TEXT);
			SetChunkValue(pChunk);
		}
	}
}

#endif // SHARED_HANDLERS

// CExample1Doc diagnostics

#ifdef _DEBUG
void CExample1Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CExample1Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CExample1Doc commands


/* albums          employees       invoices        playlists
artists         genres          media_types     tracks
customers       invoice_items   playlist_track */

void CExample1Doc::OnTablesAlbums()
{
	SelectTable(_T("albums"));	
}


void CExample1Doc::OnTablesCustomers()
{
	SelectTable(_T("customers"));	
}


void CExample1Doc::OnTablesArtists()
{
	SelectTable(_T("artists"));	
}


void CExample1Doc::OnTablesTracks()
{
	SelectTable(_T("tracks"));	
}


void CExample1Doc::OnTablesGenres()
{
	SelectTable(_T("genres"));	
}


void CExample1Doc::OnTablesMediatypes()
{
	SelectTable(_T("media_types"));	
}


void CExample1Doc::OnTablesPlaylists()
{
	SelectTable(_T("playlists"));	
}


void CExample1Doc::OnTablesPlaylisttrack()
{
	SelectTable(_T("playlist_track"));	
}


void CExample1Doc::OnTablesEmployees()
{
	SelectTable(_T("employees"));	
}


void CExample1Doc::OnTablesInvoices()
{
	SelectTable(_T("invoices"));
}


void CExample1Doc::OnTablesInvoiceitems()
{
	SelectTable(_T("invoice_items"));	
}


void CExample1Doc::OnUpdateTablesAlbums(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio(theApp.mTableName == _T("albums"));
}


void CExample1Doc::OnUpdateTablesCustomers(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio(theApp.mTableName == _T("customers"));
}


void CExample1Doc::OnUpdateTablesArtists(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio(theApp.mTableName == _T("artists"));
}


void CExample1Doc::OnUpdateTablesTracks(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio(theApp.mTableName == _T("tracks"));
}


void CExample1Doc::OnUpdateTablesGenres(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio(theApp.mTableName == _T("genres"));
}


void CExample1Doc::OnUpdateTablesMediatypes(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio(theApp.mTableName == _T("mediatypes"));
}


void CExample1Doc::OnUpdateTablesPlaylists(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio(theApp.mTableName == _T("playlists"));
}


void CExample1Doc::OnUpdateTablesPlaylisttrack(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio(theApp.mTableName == _T("playlist_track"));
}


void CExample1Doc::OnUpdateTablesEmployees(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio(theApp.mTableName == _T("employees"));
}


void CExample1Doc::OnUpdateTablesInvoices(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio(theApp.mTableName == _T("invoices"));
}


void CExample1Doc::OnUpdateTablesInvoiceitems(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio(theApp.mTableName == _T("invoice_items"));
}


void CExample1Doc::OnCloseDocument()
{
	if (mSQLiteStatement)
		delete mSQLiteStatement;

	CDocument::OnCloseDocument();
}
