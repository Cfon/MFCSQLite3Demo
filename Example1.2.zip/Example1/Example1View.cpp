
// Example1View.cpp : implementation of the CExample1View class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "Example1.h"
#endif

#include "Example1Doc.h"
#include "Example1View.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CExample1View

IMPLEMENT_DYNCREATE(CExample1View, CScrollView)

BEGIN_MESSAGE_MAP(CExample1View, CScrollView)
	ON_WM_CREATE()
	ON_COMMAND(ID_NAVIGATION_FIRSTPAGE, &CExample1View::OnFirstButton)
	ON_COMMAND(ID_NAVIGATION_LASTPAGE, &CExample1View::OnLastButton)
	ON_COMMAND(ID_NAVIGATION_NEXTPAGE, &CExample1View::OnNextButton)
	ON_COMMAND(ID_NAVIGATION_PRIORPAGE, &CExample1View::OnPriorButton)
	ON_UPDATE_COMMAND_UI(ID_NAVIGATION_FIRSTPAGE, &CExample1View::OnUpdateFirstButton)
	ON_UPDATE_COMMAND_UI(ID_NAVIGATION_LASTPAGE, &CExample1View::OnUpdateLastButton)
	ON_UPDATE_COMMAND_UI(ID_NAVIGATION_NEXTPAGE, &CExample1View::OnUpdateNextButton)
	ON_UPDATE_COMMAND_UI(ID_NAVIGATION_PRIORPAGE, &CExample1View::OnUpdatePriorButton)	
END_MESSAGE_MAP()

// CExample1View construction/destruction

CExample1View::CExample1View()
	: mMapMode(MM_TWIPS)
	, mFontSize(10)
	, mFontName(_T("Consolas"))
	, mFontWeight(FW_BOLD)
	, mRowHeight(0)
	, mTotalWidth(0)
{	
}

CExample1View::~CExample1View()
{
}

BOOL CExample1View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

// CExample1View drawing

void CExample1View::OnDraw(CDC* pDC)
{	
	CExample1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// ������
	pDC->SetWindowOrg(-100, 100);			

	// ��������� ����� 
	CPoint pt(0, 0);			
	DrawHeader(pDC, pt);
	DrawContent(pDC, pt);
	DrawFrame(pDC, pt);
}

void CExample1View::OnInitialUpdate()
{	
	TRACE("CExample1View::OnInitialUpdate\n");
	CScrollView::OnInitialUpdate();		
}


// CExample1View diagnostics

#ifdef _DEBUG
void CExample1View::AssertValid() const
{
	CScrollView::AssertValid();
}

void CExample1View::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CExample1Doc* CExample1View::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CExample1Doc)));
	return (CExample1Doc*)m_pDocument;
}
#endif //_DEBUG


HFONT CExample1View::SetFont(CDC* pDC, const LOGFONT* lpLogFont)
{
	static HFONT hOldFont;
	//static HGDIOBJ hOldFont;

	CFont font;
	font.CreateFontIndirect(lpLogFont);

	if (hOldFont)
		::DeleteObject(hOldFont);

	hOldFont = reinterpret_cast<HFONT>(pDC->SelectObject(&font));
	//hOldFont = static_cast<HGDIOBJ>(pDC->SelectObject(&font));
	//TRACE("hOldFont = %08X\n", hOldFont);	

	HFONT hFont = static_cast<HFONT>(font.Detach());
	//TRACE("hFont = %08X\n", hFont);

	return hOldFont;
}


void CExample1View::CalcColumnMaxWidths(LONG charWidth, int space)
{
	CArray<int> widths;

	const int cFieldCount = GetDocument()->mSQLiteStatement->Fields();
	CString fieldName;

	// ��������� ����� �������� ����� �������
	for (int i = 0; i < cFieldCount; ++i)
	{
		fieldName = GetDocument()->mSQLiteStatement->FieldName(i);
		widths.Add(fieldName.GetLength());
	}

	CString fieldValue;

	// ��������� ����. ����� ������ ����� 
	while (GetDocument()->mSQLiteStatement->NextRow())
	{
		for (int i = 0; i < cFieldCount; ++i)
		{
			fieldValue = GetDocument()->mSQLiteStatement->ValueString(i);
			int len = fieldValue.GetLength();

			if (widths[i] < len)	widths[i] = len;
		}
	}

	// ��������� ����.������ ��������
	for (int i = 0; i < widths.GetCount(); ++i)
	{
		widths[i] *= charWidth;
		widths[i] += space;
	}

	mColumnMaxWidths.RemoveAll();

	// ��������� ��������� 
	for (int i = 0; i < widths.GetCount(); ++i)
	{
		mColumnMaxWidths.Add(widths[i]);
	}
}


void CExample1View::CalcRowMetrics()
{
	TEXTMETRIC tm{ 0 };	//memset(&tm, 0, sizeof(TEXTMETRIC));
	LOGFONT lf{ 0 };	//memset(&lf, 0, sizeof(LOGFONT));
	_tcscpy_s(lf.lfFaceName, mFontName);
	lf.lfHeight = -mFontSize * cTwipsInPoint;
	lf.lfWeight = mFontWeight;

	CClientDC dc(this);
	dc.SetMapMode(mMapMode);
	HFONT hOldFont = SetFont(&dc, &lf);
	dc.GetTextMetrics(&tm);
	dc.SelectObject(hOldFont);

	// ������ ������ 
	mRowHeight = tm.tmHeight + tm.tmExternalLeading;

	// ������ �������		
	CalcColumnMaxWidths(tm.tmAveCharWidth);

	int totalWidth = 0;
	for (int i = 0; i < mColumnMaxWidths.GetCount(); ++i)
	{
		totalWidth += mColumnMaxWidths[i];
	}

	mTotalWidth = totalWidth;
}


void CExample1View::DrawHeader(CDC* pDC, CPoint pt)
{
	// ����� ��������� �������
	LOGFONT lf{ 0 }; 	//memset(&lf, 0, sizeof(LOGFONT));
	_tcscpy_s(lf.lfFaceName, mFontName);
	lf.lfHeight = -mFontSize * cTwipsInPoint;
	lf.lfWeight = mFontWeight;
	HFONT hOldFont = SetFont(pDC, &lf);

	/*pDC->SetTextColor(RGB(0, 0, 255));
	pDC->SetBkColor(RGB(255, 255, 0));*/

	const int cFieldCount = GetDocument()->mSQLiteStatement->Fields();
	CString fieldName;

	for (int i = 0; i < cFieldCount; ++i)
	{
		fieldName = GetDocument()->mSQLiteStatement->FieldName(i);
		fieldName.MakeUpper();
		pDC->TextOut(pt.x, pt.y, fieldName);
		pt.x += mColumnMaxWidths[i];
	}

	pDC->SelectObject(hOldFont);
}


void CExample1View::DrawFrame(CDC* pDC, CPoint pt)
{
	const int dx = 70;
	int rowCount = GetDocument()->GetRecordCount();
	int cy = mRowHeight  * (rowCount + 2);

	CPen pen;
	pen.CreatePen(PS_SOLID, 1, RGB(0, 0, 0));
	CPen* pOldPen = pDC->SelectObject(&pen);

	// ����� ������ �������
	pDC->MoveTo(pt.x - dx, pt.y);
	pDC->LineTo(pt.x + mTotalWidth - dx, pt.y);
	pDC->LineTo(pt.x + mTotalWidth - dx, pt.y - cy);
	pDC->LineTo(pt.x - dx, pt.y - cy);
	pDC->LineTo(pt.x - dx, pt.y);

	// ����� ��� ���������� �������
	pDC->MoveTo(pt.x - dx, pt.y - mRowHeight);
	pDC->LineTo(pt.x + mTotalWidth - dx, pt.y - mRowHeight);

	// ������� ���������
	/*CBrush brush;
	brush.CreateSolidBrush(RGB(255, 255, 0));
	CBrush* pOldBrush = pDC->SelectObject(&brush);
	CRect rc(pt.x - dx, pt.y, pt.x + mTotalWidth - dx, pt.y - mRowHeight);
	pDC->FillRect(rc, &brush);
	pDC->SelectObject(pOldBrush);*/

	// ������������ ��������
	int cx = mColumnMaxWidths[0];
	for (int i = 1; i < mColumnMaxWidths.GetCount(); ++i)
	{
		pDC->MoveTo(pt.x + cx - dx, pt.y);
		pDC->LineTo(pt.x + cx - dx, pt.y - cy);
		cx += mColumnMaxWidths[i];
	}

	pDC->SelectObject(pOldPen);
}


void CExample1View::DrawContent(CDC* pDC, CPoint pt)
{
	LOGFONT lf{ 0 };	//memset(&lf, 0, sizeof(LOGFONT));
	_tcscpy_s(lf.lfFaceName, mFontName);
	lf.lfHeight = -(mFontSize - 2) * cTwipsInPoint;
	lf.lfWeight = FW_NORMAL;

	HFONT hOldFont = SetFont(pDC, &lf);

	/*pDC->SetTextColor(RGB(0, 0, 0));
	pDC->SetBkColor(RGB(255, 255, 255));*/

	const int fieldCount = GetDocument()->mSQLiteStatement->Fields();
	int cy = pt.y - mRowHeight * 1.5;

	CString fieldValue;
	while (GetDocument()->mSQLiteStatement->NextRow())
	{
		for (int i = 0, cx = 0; i < fieldCount; ++i)
		{
			fieldValue = GetDocument()->mSQLiteStatement->ValueString(i);
			// ���������� ������� ��������
			if (fieldValue != _T("(null)"))
				pDC->TextOut(pt.x + cx, pt.y + cy, fieldValue);

			cx += mColumnMaxWidths[i];
		}

		cy -= mRowHeight;
	}

	pDC->SelectObject(hOldFont);
}


void CExample1View::LayoutNavigationButtons(CDC* pDC, CPoint pt)
{
	// ����������� ������ ��������� 

	CPoint scrlPos = GetScrollPosition();
	TRACE("(%d, %d)\n", scrlPos.x, scrlPos.y);

	const CSize buttonSize(76, 23);		
	int cx = pt.x - scrlPos.x;
	int cy = pt.y + scrlPos.y;
	CPoint point(cx, -cy);

	pDC->LPtoDP(&point);
	point.Offset(0, -buttonSize.cy);	

	CPoint first(point);
	CPoint prior(first.x + buttonSize.cx, point.y);
	CPoint next(prior.x + buttonSize.cx, point.y);
	CPoint last(next.x + buttonSize.cx, point.y);

	mFirstPageButton.SetWindowPos(&wndTop, first.x, first.y, 0, 0, SWP_NOSIZE |  SWP_SHOWWINDOW);
	mPriorPageButton.SetWindowPos(&wndTop, prior.x, prior.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
	mNextPageButton.SetWindowPos(&wndTop, next.x, next.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
	mLastPageButton.SetWindowPos(&wndTop, last.x, last.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);	
}


void CExample1View::LayoutNavigationButtons(CPoint pt)
{		
	// ����������� ������ ���������	

	int mapMode;
	CSize totalSize, pageSize, lineSize;	
	GetDeviceScrollSizes(mapMode, totalSize, pageSize, lineSize);

	CPoint scrlPos = GetDeviceScrollPosition();
	//TRACE("scrlPos: (%d, %d)\n", scrlPos.x, scrlPos.y);

	const CSize buttonSize(76, 23);	
	int cx = pt.x - scrlPos.x;
	int cy = pt.y + totalSize.cy - scrlPos.y - buttonSize.cy;

	CPoint first(cx, cy);
	CPoint prior(first.x + buttonSize.cx, cy);
	CPoint next(prior.x + buttonSize.cx, cy);
	CPoint last(next.x + buttonSize.cx, cy);

	mFirstPageButton.SetWindowPos(&wndTop, first.x, first.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
	mPriorPageButton.SetWindowPos(&wndTop, prior.x, prior.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
	mNextPageButton.SetWindowPos(&wndTop, next.x, next.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
	mLastPageButton.SetWindowPos(&wndTop, last.x, last.y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
}


void CExample1View::UpdateStateNavButtons()
{
	mFirstPageButton.EnableWindow(GetDocument()->mCurRowN != 0);
	mLastPageButton.EnableWindow(GetDocument()->GetRecordCount() == cRowCountInPage); 
	mNextPageButton.EnableWindow(GetDocument()->GetRecordCount() == cRowCountInPage); 
	mPriorPageButton.EnableWindow(GetDocument()->mCurRowN != 0);
}


// CExample1View message handlers


int CExample1View::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CScrollView::OnCreate(lpCreateStruct) == -1)
		return -1;	


	// ������� ������ �������
	mFirstPageButton.Create(_T("First"), BS_PUSHBUTTON, CRect(0, 0, 76, 23), this, ID_NAVIGATION_FIRSTPAGE);
	mPriorPageButton.Create(_T("Prior"), BS_PUSHBUTTON, CRect(0, 0, 76, 23), this, ID_NAVIGATION_PRIORPAGE);
	mNextPageButton.Create(_T("Next"), BS_PUSHBUTTON, CRect(0, 0, 76, 23), this, ID_NAVIGATION_NEXTPAGE);
	mLastPageButton.Create(_T("Last"), BS_PUSHBUTTON, CRect(0, 0, 76, 23), this, ID_NAVIGATION_LASTPAGE);
	
	return 0;
}


void CExample1View::OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/)
{
	TRACE(_T("CExample1View::OnUpdate\n"));
	// ������������� ���������� ������� ����	
	
	int rowCount = GetDocument()->GetRecordCount();
	TRACE(_T("rows count = %d\n"), rowCount);

	CalcRowMetrics();	
	TRACE(_T("columns count = %d\n"), mColumnMaxWidths.GetCount());	
	TRACE(_T("row height = %d\n"), mRowHeight);

	// ���.������� ����	
	const int cx = mTotalWidth + 500;
	const int cy = mRowHeight * (rowCount + 5);

	CSize sizeTotal(cx, cy);
	CSize sizePage(sizeTotal.cx / 2, sizeTotal.cy / 2);
	CSize sizeLine(sizeTotal.cx / 50, sizeTotal.cy / 50);

	SetScrollSizes(mMapMode, sizeTotal, sizePage, sizeLine);	
	Invalidate();

	//ScrollToPosition(CPoint(0, 0));	

	/*CClientDC dc(this);
	dc.SetMapMode(mMapMode);
	CPoint pt(0, cY);
	LayoutNavigationButtons(&dc, pt);*/

	CPoint pt(0, 0);
	LayoutNavigationButtons(pt);
	UpdateStateNavButtons();	
}


void CExample1View::OnFirstButton()
{		
	GetDocument()->mCurRowN = 0;
	GetDocument()->OnNewDocument();
	GetDocument()->UpdateAllViews(NULL);
}


void CExample1View::OnLastButton()
{
	int recCount = GetDocument()->GetAllRecordCount();	
	recCount -= recCount % cRowCountInPage;
	GetDocument()->mCurRowN = recCount;	
	GetDocument()->OnNewDocument();
	GetDocument()->UpdateAllViews(NULL);
}


void CExample1View::OnNextButton()
{
	GetDocument()->mCurRowN += cRowCountInPage;
	GetDocument()->OnNewDocument();
	GetDocument()->UpdateAllViews(NULL);
}


void CExample1View::OnPriorButton()
{
	GetDocument()->mCurRowN -= cRowCountInPage;
	GetDocument()->OnNewDocument();
	GetDocument()->UpdateAllViews(NULL);
}


void CExample1View::OnUpdateFirstButton(CCmdUI *pCmdUI)
{	
	pCmdUI->Enable(GetDocument()->mCurRowN != 0);
}


void CExample1View::OnUpdateLastButton(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(!(GetDocument()->GetRecordCount() < cRowCountInPage));
}


void CExample1View::OnUpdateNextButton(CCmdUI *pCmdUI)
{	
	pCmdUI->Enable(!(GetDocument()->GetRecordCount() < cRowCountInPage));
}


void CExample1View::OnUpdatePriorButton(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->mCurRowN != 0);
}

