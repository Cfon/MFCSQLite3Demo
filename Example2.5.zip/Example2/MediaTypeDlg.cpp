// MediaTypeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "MediaTypeDlg.h"
#include "afxdialogex.h"


// CMediaTypeDlg dialog

IMPLEMENT_DYNAMIC(CMediaTypeDlg, CDialogEx)

CMediaTypeDlg::CMediaTypeDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CMediaTypeDlg::IDD, pParent)
{

}

CMediaTypeDlg::~CMediaTypeDlg()
{
}

void CMediaTypeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CMediaTypeDlg, CDialogEx)
END_MESSAGE_MAP()


// CMediaTypeDlg message handlers
