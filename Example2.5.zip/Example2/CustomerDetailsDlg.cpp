// CustomerDetailsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "CustomerDetailsDlg.h"
#include "afxdialogex.h"
#include <memory>


// CCustomerDetailsDlg dialog


const LPCTSTR gCustomerQueryConst =
	_T("SELECT c.customerId, c.firstName, c.lastName, ")
		_T(" c.company, c.address, c.city, c.state, c.country, ")
		_T(" c.postalcode, c.phone, c.fax, c.email, ")
		_T("e.lastName||', '||e.firstName supportRep FROM customers c ")
		_T(" LEFT JOIN employees e ON c.supportRepId = e.employeeId ")
		_T(" WHERE customerId = %d");


IMPLEMENT_DYNAMIC(CCustomerDetailsDlg, CDialogEx)

CCustomerDetailsDlg::CCustomerDetailsDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CCustomerDetailsDlg::IDD, pParent)
	, mID(0)
{

}

CCustomerDetailsDlg::~CCustomerDetailsDlg()
{
}

void CCustomerDetailsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


void CCustomerDetailsDlg::LoadCustomerByID(int id)
{	
	CString query;
	query.Format(gCustomerQueryConst, id);

	std::unique_ptr<CSqlStatement> stmt(theApp.mSQLiteDB.Statement(query));
	ASSERT(stmt);

	if (stmt->NextRow())
	{					
		CString value;
		for (int k = 1; k < stmt->Fields(); ++k)
		{
			value = stmt->ValueString(k);
			if (value != _T("(null)"))
				SetDlgItemText(IDC_FIRSTNAME + (k-1), value);
			else
				SetDlgItemText(IDC_FIRSTNAME + (k-1), _T(""));
		}
	}
}


BEGIN_MESSAGE_MAP(CCustomerDetailsDlg, CDialogEx)
END_MESSAGE_MAP()


// CCustomerDetailsDlg message handlers


BOOL CCustomerDetailsDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	HICON hIcon = AfxGetApp()->LoadIcon(IDI_USER);
	ASSERT(hIcon);
	SetIcon(hIcon, TRUE);

	/*CFont font;
	LOGFONT lf{ 0 };
	_tcscpy_s(lf.lfFaceName, _T("Consolas"));
	lf.lfHeight = -12;
	lf.lfWeight = FW_NORMAL;
	font.CreateFontIndirect(&lf);

	for (int i = IDC_FIRSTNAME; i <= IDC_SUPPORTREP; ++i)
	{
		CStatic* pFirstName = static_cast<CStatic*>(GetDlgItem(i));
		pFirstName->SetFont(&font);		
	}
	font.Detach();*/

	LoadCustomerByID(mID);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

