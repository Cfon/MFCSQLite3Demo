#pragma once


// CMediaTypeDlg dialog

class CMediaTypeDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CMediaTypeDlg)

public:
	CMediaTypeDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CMediaTypeDlg();

// Dialog Data
	enum { IDD = IDD_MEDIATYPE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
};
