#pragma once

#include "CustomDlg.h"
//#include "afxcmn.h"


// CPlaylistDlg dialog

class CPlaylistDlg : public CCustomDlg
{
	DECLARE_DYNAMIC(CPlaylistDlg)

public:
	CPlaylistDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CPlaylistDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_PLAYLIST };
#endif

	virtual void InitDialog(int playlistId) override;
	virtual void SetControls(const CArrayStr& values, int id) override;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	int mPlaylistId;
	CListCtrl mTrackList;
	int mTrackCount;
	CString mPlaylistName;	
};
