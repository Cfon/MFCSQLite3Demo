// AlbumDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "AlbumDlg.h"
//#include "afxdialogex.h"
#include <memory>


// CAlbumDlg dialog


enum AlbumType { albumId, title, artistId };
static LPCTSTR gAlbumQuery 
{
	_T("SELECT albumId, title, artistId FROM albums ")
	_T(" WHERE albumId = %d") 
};


enum ArtistType { artistId_, artistName };
static LPCTSTR gArtistsQuery 
{
	_T("SELECT artistId, name FROM artists") 
};

enum  TrackType { trackId, trackName, genreId, composer, unitPrice };
static LPCTSTR gTracksQuery 
{
	_T("SELECT trackId,	name, genreId, composer, unitPrice ")
	_T(" FROM tracks WHERE albumId = %d") 
};


IMPLEMENT_DYNAMIC(CAlbumDlg, CCustomDlg)

CAlbumDlg::CAlbumDlg(CWnd* pParent /*=NULL*/)
	: CCustomDlg(CAlbumDlg::IDD, pParent)
	, mArtistId(0)
	, mTitle(_T(""))
	, mAlbumId(0)
{

}

CAlbumDlg::~CAlbumDlg()
{
}

void CAlbumDlg::DoDataExchange(CDataExchange* pDX)
{
	CCustomDlg::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ALBUM_ARTISTS_COMBO, mArtistsCombo);
	DDX_Control(pDX, IDC_ALBUM_TRACKS_LIST, mTracksList);	
	DDX_CBIndex(pDX, IDC_ALBUM_ARTISTS_COMBO, mArtistId);
	DDX_Text(pDX, IDC_ALBUM_TITLE_EDIT, mTitle);
}


void CAlbumDlg::InitDialog(int albumId)
{
	LoadDataByQuery(gAlbumQuery, albumId);
}


void CAlbumDlg::SetControls(const CArrayStr& values, int albumId)
{
	mAlbumId = albumId;
	mTitle = values[AlbumType::title];
	mArtistId = _ttoi(values[AlbumType::artistId]);		
}



BEGIN_MESSAGE_MAP(CAlbumDlg, CCustomDlg)
END_MESSAGE_MAP()


// CAlbumDlg message handlers


BOOL CAlbumDlg::OnInitDialog()
{
	CCustomDlg::OnInitDialog();

	HICON hIcon = AfxGetApp()->LoadIcon(IDI_ALBUM);
	ASSERT(hIcon);
	SetIcon(hIcon, TRUE);
		
	FillListCtrl(&mTracksList, gTracksQuery, mAlbumId);
	mTracksList.SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT);

	FillCombo(gArtistsQuery, ArtistType::artistName, &mArtistsCombo);
	mArtistsCombo.SetCurSel(mArtistId - 1);	

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
