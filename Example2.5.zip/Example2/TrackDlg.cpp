// TrackDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "TrackDlg.h"
//#include "afxdialogex.h"
#include <memory>


// CTrackDlg dialog

enum TrackType
{
	trackId, trackName,	albumId, mediaTypeId, genreId, 
	composer, milliseconds, bytes, unitprice 
};

static LPCTSTR gTrackQuery
{
	_T("SELECT trackId, name, albumId, mediaTypeId, genreId, ")
	_T(" composer, milliseconds, bytes, unitprice FROM tracks ")
	_T(" WHERE trackid = %d;")
};


enum AlbumType { albumId_, title, artistId };

static LPCTSTR gAlbumsQuery
{ 
	_T("SELECT albumId, title, artistId FROM albums;")
};


enum MediaTypeType { mediaTypeId_, mediaName };

static LPCTSTR gMediaTypesQuery
{ 
	_T("SELECT mediaTypeId, name FROM media_types;")
};


enum GenreType { genreId_, genreName };

static LPCTSTR gGenresQuery
{ 
	_T("SELECT genreId, name FROM genres;") 
};



IMPLEMENT_DYNAMIC(CTrackDlg, CCustomDlg)

CTrackDlg::CTrackDlg(CWnd* pParent /*=NULL*/)
	: CCustomDlg(IDD_TRACK, pParent)
	, mTrackId(0)
	, mBytes(0)
	, mComposer(_T(""))
	, mMilliseconds(0)
	, mTrackName(_T(""))
	, mPrice(0)
	, mAlbumId(0)
	, mMediaTypeId(0)
	, mGenreId(0)
{

}

CTrackDlg::~CTrackDlg()
{
}

void CTrackDlg::DoDataExchange(CDataExchange* pDX)
{
	CCustomDlg::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_TRACK_BYTES_EDIT, mBytes);
	DDX_Text(pDX, IDC_TRACK_COMPOSER_EDIT, mComposer);
	DDX_Text(pDX, IDC_TRACK_MILLISECONDS_EDIT, mMilliseconds);
	DDX_Text(pDX, IDC_TRACK_NAME_EDIT, mTrackName);
	DDX_Text(pDX, IDC_TRACK_PRICE_EDIT, mPrice);
	DDX_CBIndex(pDX, IDC_TRACK_ALBUM_COMBO, mAlbumId);
	DDX_CBIndex(pDX, IDC_TRACK_MEDIATYPE_COMBO, mMediaTypeId);
	DDX_CBIndex(pDX, IDC_TRACK_GENRE_COMBO, mGenreId);
	DDX_Control(pDX, IDC_TRACK_ALBUM_COMBO, mAlbumNamesCombo);
	DDX_Control(pDX, IDC_TRACK_MEDIATYPE_COMBO, mMediaTypesCombo);
	DDX_Control(pDX, IDC_TRACK_GENRE_COMBO, mGenresCombo);
}


void CTrackDlg::InitDialog(int trackId)
{
	LoadDataByQuery(gTrackQuery, trackId);	
}


void CTrackDlg::SetControls(const CArrayStr& values, int id)
{
	mTrackId = id;				
	mAlbumId = _ttoi(values[TrackType::albumId]);
	mBytes = _ttoi(values[TrackType::bytes]);
	mComposer = values[TrackType::composer];
	mGenreId = _ttoi(values[TrackType::genreId]);
	mMediaTypeId = _ttoi(values[TrackType::mediaTypeId]);
	mMilliseconds = _ttoi(values[TrackType::milliseconds]);
	mTrackName = values[TrackType::trackName];
	mPrice = _ttoi(values[TrackType::unitprice]);		
}


BEGIN_MESSAGE_MAP(CTrackDlg, CCustomDlg)
END_MESSAGE_MAP()


// CTrackDlg message handlers


BOOL CTrackDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// �������� ������ � ��������� ����
	HICON hIcon = AfxGetApp()->LoadIcon(IDI_TRACK);
	ASSERT(hIcon);
	SetIcon(hIcon, TRUE);

	FillCombo(gAlbumsQuery, AlbumType::title, &mAlbumNamesCombo);
	FillCombo(gMediaTypesQuery, MediaTypeType::mediaName, &mMediaTypesCombo);
	FillCombo(gGenresQuery, GenreType::genreName, &mGenresCombo);

	mAlbumNamesCombo.SetCurSel(mAlbumId - 1);
	mMediaTypesCombo.SetCurSel(mMediaTypeId - 1);
	mGenresCombo.SetCurSel(mGenreId - 1);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}
