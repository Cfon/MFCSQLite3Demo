
// GalleryView.cpp : implementation of the CGalleryView class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "Gallery.h"
#endif

#include "GalleryDoc.h"
#include "GalleryView.h"
#include "InputDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif



// CGalleryView

IMPLEMENT_DYNCREATE(CGalleryView, CFormView)

BEGIN_MESSAGE_MAP(CGalleryView, CFormView)
	ON_BN_CLICKED(IDC_ALBUM_EDIT_BUTTON, &CGalleryView::OnAlbumEditButton)		
	ON_BN_CLICKED(IDC_ALBUM_DELETE_BUTTON, &CGalleryView::OnAlbumDeleteButton)
	ON_BN_CLICKED(IDC_ALBUM_INSERT_BUTTON, &CGalleryView::OnAlbumInsertButton)	
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_ALBUM_LIST, &CGalleryView::OnLvnItemchangedAlbumList)
END_MESSAGE_MAP()

// CGalleryView construction/destruction

CGalleryView::CGalleryView()
	: CFormView(CGalleryView::IDD)
	, mCurrentRowIndex(0)
{
}

CGalleryView::~CGalleryView()
{
}


void CGalleryView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ALBUM_LIST, mAlbumList);
}

BOOL CGalleryView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	
	return CFormView::PreCreateWindow(cs);
}

void CGalleryView::OnInitialUpdate()
{	
	CFormView::OnInitialUpdate();	
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();		

	mAlbumList.SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE, 0,
		LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);		
}


// CGalleryView diagnostics

#ifdef _DEBUG
void CGalleryView::AssertValid() const
{
	CFormView::AssertValid();
}

void CGalleryView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CGalleryDoc* CGalleryView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGalleryDoc)));
	return (CGalleryDoc*)m_pDocument;
}
#endif //_DEBUG


void CGalleryView::AddAlbumsToList(CListCtrl& list)
{
	// ������� ������ � ������	
	LVITEM lv{ 0 };
	lv.mask = LVIF_TEXT;
	
	CString value;	
	for (int i = 0; i < GetDocument()->GetAlbumModel()->RowCount(); ++i)
	{
		lv.iItem = i;
		lv.iSubItem = 0;
		value.Format(_T("%d"), i + 1);
		lv.pszText = value.GetBufferSetLength(value.GetLength());
		list.InsertItem(&lv);
		
		lv.iSubItem = 1;
		value = GetDocument()->GetAlbumModel()->AlbumName(i);
		lv.pszText = value.GetBufferSetLength(value.GetLength());
		list.SetItem(&lv);
	}
}


// CGalleryView message handlers


void CGalleryView::OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/)
{	
	TRACE(_T("OnUpdate\n"));		
	mAlbumList.DeleteAllItems();
	while (mAlbumList.DeleteColumn(0));
	
	// ��������� ������� 
	mAlbumList.InsertColumn(0, _T("#"));
	mAlbumList.SetColumnWidth(0, 50);
	mAlbumList.InsertColumn(1, _T("Album Name"));
	mAlbumList.SetColumnWidth(1, 200);	
	
	// ���������� �������� � ������
	AddAlbumsToList(mAlbumList);		
	
	if (!GetDocument()->GetAlbumModel()->IsIndexValid(mCurrentRowIndex))
	{
		mCurrentRowIndex = (mCurrentRowIndex - 1) < 0 ? 0 : mCurrentRowIndex - 1;
	}

	// ��������� ���� name 
	mAlbumName = GetDocument()->GetAlbumModel()->AlbumName(mCurrentRowIndex);
	SetDlgItemText(IDC_ALBUM_STATIC, mAlbumName);	
}


void CGalleryView::OnAlbumEditButton()
{	
	CInputDlg dlg(_T("Edit Album"));
	dlg.mLabelValue = _T("Change the album name");
	dlg.mInputValue = mAlbumName;

	if (dlg.DoModal() == IDOK)
	{		
		GetDocument()->GetAlbumModel()->SetAlbumName(mCurrentRowIndex, dlg.mInputValue);
		GetDocument()->UpdateAllViews(NULL);
	}	
}


void CGalleryView::OnAlbumDeleteButton()
{			
	static LPCTSTR deleteMessages[]
	{
		_T("Delete record?"),		
		_T("Delete selected records?"),		
		_T("Delete all records?"),
	};	

	int index = 0;	

	if (mAlbumList.GetSelectedCount() > 1)
	{
		index = 1;
		if (mAlbumList.GetSelectedCount() == GetDocument()->GetAlbumModel()->RowCount()) 
		{
			index = 2;
		}
	}

	if (AfxMessageBox(deleteMessages[index], MB_YESNO) == IDYES)	
	{
		GetDocument()->GetAlbumModel()->RemoveRows(mCurrentRowIndex, mAlbumList.GetSelectedCount());
		GetDocument()->UpdateAllViews(NULL);
	}

	/*BOOL isDelete = FALSE;
	
	if (mAlbumList.GetSelectedCount() == GetDocument()->GetAlbumModel()->RowCount())
	{
		if (AfxMessageBox(_T("Delete all records?"), MB_YESNO) == IDYES)
			isDelete = TRUE;
	}
	else if (mAlbumList.GetSelectedCount() > 1)
	{
		if (AfxMessageBox(_T("Delete selected records?"), MB_YESNO) == IDYES)
			isDelete = TRUE;
	}
	else
	{
		if (AfxMessageBox(_T("Delete record?"), MB_YESNO) == IDYES)
			isDelete = TRUE;
	}

	if (isDelete)
	{
		GetDocument()->GetAlbumModel()->RemoveRows(mCurrentRowIndex, mAlbumList.GetSelectedCount());
		GetDocument()->UpdateAllViews(NULL);
	}*/
}


void CGalleryView::OnAlbumInsertButton()
{
	CInputDlg dlg(_T("Insert Album"));
	dlg.mLabelValue = _T("Enter an album name");

	if (dlg.DoModal() == IDOK) 
	{
		Album newAlbum;
		newAlbum.SetName(dlg.mInputValue);
	
		GetDocument()->GetAlbumModel()->AddAlbum(newAlbum);
		GetDocument()->UpdateAllViews(NULL);
	}
}


void CGalleryView::OnLvnItemchangedAlbumList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);

	if ((pNMLV->uChanged & LVIF_STATE) && (pNMLV->uNewState & LVIS_SELECTED))
	{	
		mCurrentRowIndex = pNMLV->iItem;				
		mAlbumName = GetDocument()->GetAlbumModel()->AlbumName(mCurrentRowIndex);
		SetDlgItemText(IDC_ALBUM_STATIC, mAlbumName);			
	}
	
	*pResult = 0;
}
