#include "stdafx.h"
#include "AlbumModel.h"
#include "DatabaseManager.h"



AlbumModel::AlbumModel()
	: mDataManager(DatabaseManager::instance())
	, mAlbums(mDataManager.AlbumDao().Select())
{
}


AlbumModel::~AlbumModel()
{
}


BOOL AlbumModel::IsIndexValid(int index) const
{
	if ((index >= 0) && (index < RowCount()))
	{
		return TRUE;
	}
	return FALSE;
}


int AlbumModel::RowCount() const
{
#ifdef _MFC_CArray	
	return mAlbums->GetCount();
#else
	return mAlbums->size();
#endif	
}


int AlbumModel::AlbumId(int index) const
{
	if (!IsIndexValid(index))
		return 0;

#ifdef _MFC_CArray	
	const Album& album = *mAlbums->ElementAt(index);
#else	
	const Album& album = *mAlbums->at(index);
#endif		
	return album.Id();
}


CString AlbumModel::AlbumName(int index) const
{
	if (!IsIndexValid(index))
		return CString();

#ifdef _MFC_CArray	
	const Album& album = *mAlbums->ElementAt(index);
#else		
	const Album& album = *mAlbums->at(index);
#endif	
	return album.Name();
}


void AlbumModel::SetAlbumName(int index, const CString & name) const
{
	if (!IsIndexValid(index)) return;

#ifdef _MFC_CArray	
	Album& album = *mAlbums->ElementAt(index);
#else		
	Album& album = *mAlbums->at(index);
#endif		
	album.SetName(name);
	mDataManager.AlbumDao().Update(album);
}


void AlbumModel::AddAlbum(const Album& album)const
{
	std::unique_ptr<Album> newAlbum(new	Album(album));
	mDataManager.AlbumDao().Insert(*newAlbum);
#ifdef _MFC_CArray	
	mAlbums->Add(std::move(newAlbum));
#else		
	mAlbums->push_back(std::move(newAlbum));
#endif		
}


BOOL AlbumModel::RemoveRows(int row, int count) const
{
	if (row < 0 || row >= RowCount() || count < 0 || (row + count) > RowCount())
		return	FALSE;

	int	countLeft = count;

#ifdef _MFC_CArray	
	while (countLeft--)
	{
		const Album& album = *mAlbums->ElementAt(row + countLeft);
		mDataManager.AlbumDao().Delete(album.Id());
	}

	mAlbums->RemoveAt(row, count);
#else				
	while (countLeft--)
	{
		const Album& album = *mAlbums->at(row + countLeft);
		mDataManager.AlbumDao().Delete(album.Id());
	}

	mAlbums->erase(mAlbums->begin() + row, mAlbums->begin() + row + count);
#endif
	return TRUE;
}

