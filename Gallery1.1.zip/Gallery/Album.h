#pragma once

class Album
{
public:
	explicit Album(const CString& name = _T(""))
		: mId(0)
		, mName(name) 
	{}
	
	~Album() {}

// Attributes	
	int Id() const { return mId; }
	void SetId(int id) { mId = id; }
	CString Name() const { return mName; }
	void SetName(const CString& name) { mName = name; }

// Operations

// Implemantation
private:
	int mId;
	CString mName;
};

