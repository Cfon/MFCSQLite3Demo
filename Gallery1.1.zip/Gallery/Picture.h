#pragma once

class MyPicture
{
public:
	MyPicture(const CString& filePath = _T(""));
	~MyPicture();

	// Attributes
	int Id() const;
	void SetId(int id);
	CString FilePath() const;
	void SetFilePath(const CString& filePath);
	int AlbumId() const;
	void SetAlbumId(int albumId);

	// Operations

	// Implemantation
private:
	int mId;
	CString mFilePath;
	int mAlbumId;
};

