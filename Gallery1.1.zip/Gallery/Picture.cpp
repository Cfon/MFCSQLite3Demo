#include "stdafx.h"
#include "Picture.h"


MyPicture::MyPicture(const CString& filePath)
	: mId(-1)
	, mFilePath(filePath)
	, mAlbumId(-1)
{
}


MyPicture::~MyPicture()
{
}


inline int MyPicture::Id() const
{
	return mId;
}


inline void MyPicture::SetId(int id)
{
	mId = id;
}


inline CString MyPicture::FilePath() const
{
	return mFilePath;
}


inline void MyPicture::SetFilePath(const CString& filePath)
{
	mFilePath = filePath;
}


inline int MyPicture::AlbumId() const
{
	return mAlbumId;
}


inline void MyPicture::SetAlbumId(int albumId)
{
	mAlbumId = albumId;
}
