
// Example2.h : main header file for the Example2 application
//
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols
#include "DbSqlite.h"


enum TableNameType
{
	albums,
	artists,
	tracks,
	mediaTypes,
	genres,
	playlists,
	customers,
	employees,
	invoices
};

extern LPCTSTR gTableNames[];


// CExample2App:
// See Example2.cpp for the implementation of this class
//

class CExample2App : public CWinApp
{
public:
	CExample2App();


// Overrides
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

// Implementation
private:
	CDbSQLite mSQLiteDB;
	CString mDBFilename;
	bool mIsDbConnected;	

	friend class CExample2Doc;
	friend class CMainFrame;

public:
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CExample2App theApp;
