
// Example2View.h : interface of the CExample2View class
//

#pragma once

extern const int sRowCountInPageConst;


class CExample2View : public CScrollView
{
protected: // create from serialization only
	CExample2View();
	DECLARE_DYNCREATE(CExample2View)

// Attributes
public:
	CExample2Doc* GetDocument() const;

// Operations
public:

// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CExample2View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif


protected:
	static const int cTwipsInPoint = 20;

	int mMapMode;	// MM_TWIPS = 1/1440 inch
	int mFontSize;	// in points	
	CString mFontName;
	LONG mFontWeight;
	
	int mTotalWidth;
	int mRowHeight;
	CArray<int> mColumnMaxWidths;


	HFONT SetFont(CDC* pDC, const LOGFONT* lpLogFont);
	void CalcColumnMaxWidths(LONG charWidth, int space = 100);
	void CalcRowMetrics();

	void DrawHeader(CDC* pDC, CPoint pt);
	void DrawFrame(CDC* pDC, CPoint pt);
	void DrawContent(CDC* pDC, CPoint pt);

	void LayoutNavigationButtons(CPoint pt);
	void UpdateStateNavButtons();

public:
	CButton mFirstPageButton,
		mPriorPageButton,
		mNextPageButton,
		mLastPageButton;

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
	virtual void OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/);
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnNavigationFirstpage();
	afx_msg void OnNavigationLastpage();
	afx_msg void OnNavigationNextpage();
	afx_msg void OnNavigationPriorpage();
	afx_msg void OnUpdateNavigationFirstpage(CCmdUI *pCmdUI);
	afx_msg void OnUpdateNavigationLastpage(CCmdUI *pCmdUI);
	afx_msg void OnUpdateNavigationNextpage(CCmdUI *pCmdUI);
	afx_msg void OnUpdateNavigationPriorpage(CCmdUI *pCmdUI);
};

#ifndef _DEBUG  // debug version in Example2View.cpp
inline CExample2Doc* CExample2View::GetDocument() const
   { return reinterpret_cast<CExample2Doc*>(m_pDocument); }
#endif

