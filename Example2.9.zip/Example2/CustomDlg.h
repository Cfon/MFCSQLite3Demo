#pragma once

#include <memory>


// CCustomDlg dialog

class CCustomDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CCustomDlg)

public:	
	// standard constructor
	CCustomDlg(UINT nIDTemplate, LPCTSTR pQuery, CWnd *pParent = NULL);
	virtual ~CCustomDlg();

	typedef CArray<CString> Row;	

	virtual void InitCustomDialog(int id);
	int GetId() const;
	void SetId(int id);

protected:
	virtual void SetControls(const Row& values, int id) = 0;

	void SetSystemMenuIcon(UINT nIDResource);
	void LoadDataByQuery(LPCTSTR pQuery, int id);
	void FillCombo(CComboBox* pCombo, LPCTSTR pQuery, int fieldZeroIndex);
	void FillListCtrl(CListCtrl* pList, LPCTSTR pQuery, int id);
	void FillEdit(CEdit* pEdit, LPCTSTR pQuery, int fieldZeroIndex, int id);
	void SetGridStyle(CListCtrl* pList);

// Dialog Data	
private:
	int mId;
	LPCTSTR mQuery;
	
	class Table
	{
	public:
		INT_PTR AddRow(std::shared_ptr<Row> row) {	return mTable.Add(row); }
		INT_PTR RowCount() { return mTable.GetCount(); }
		Row& operator[](int index) { return *mTable[index]; }
		const Row& operator[](int index) const { return *mTable[index]; }
	private:
		CArray<std::shared_ptr<Row>> mTable;
	};

	void ExecQuery(LPCTSTR pQuery, Table* data, Row* fieldTypes = NULL, Row* fieldNames = NULL);
	void FormattingData(Row* fieldTypes, Table* data);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
};


// ������� �������� ���� �������
class CustomDlgFactory
{
public:
	CustomDlgFactory() {}
	virtual ~CustomDlgFactory() {}
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg() = 0;
};

