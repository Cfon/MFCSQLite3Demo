// GenreDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "GenreDlg.h"
#include "CustomDlg.h"


// CGenreDlg dialog


LPCTSTR GenreDlgFactory::sGenreQuery
{
	_T("SELECT g.name, COUNT(t.genreId) 'tracks count' ")
	_T(" FROM genres g ")
	_T(" LEFT JOIN tracks t USING (genreId) ")
	_T(" GROUP BY g.genreId ")
	_T(" HAVING g.genreId = %d")
};

enum GenreType { genreName, tracksCount };


static LPCTSTR gTracksQuery
{
	_T("SELECT t.name 'Track', a.title 'Album', m.name 'Media type', ")
	_T("  t.composer, t.milliseconds, t.bytes, t.unitprice ")
	_T(" FROM tracks t ")
	_T(" INNER JOIN albums a USING (albumId) ")
	_T(" INNER JOIN media_types m USING (mediaTypeId) ")
	_T(" WHERE t.genreId = %d ")
};


IMPLEMENT_DYNAMIC(CGenreDlg, CCustomDlg)

CGenreDlg::CGenreDlg(LPCTSTR pQuery, CWnd* pParent /*=NULL*/)
	: CCustomDlg(CGenreDlg::IDD, pQuery, pParent)
	, mTrackCountValue(0)
{

}

CGenreDlg::~CGenreDlg()
{
}

void CGenreDlg::DoDataExchange(CDataExchange* pDX)
{
	CCustomDlg::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_GENRE_TRACK_LIST, mTrackList);

	DDX_Text(pDX, IDC_GENRE_NAME_EDIT, mGenreNameValue);	
	DDX_Text(pDX, IDC_GENRE_TRACKCOUNT_EDIT, mTrackCountValue);
}


void CGenreDlg::SetControls(const Row& values, int id)
{
	SetId(id);
	mGenreNameValue = values[GenreType::genreName];
	mTrackCountValue = _ttoi(values[GenreType::tracksCount]);
}


BEGIN_MESSAGE_MAP(CGenreDlg, CCustomDlg)
END_MESSAGE_MAP()


// CGenreDlg message handlers


BOOL CGenreDlg::OnInitDialog()
{
	CCustomDlg::OnInitDialog();

	SetSystemMenuIcon(IDI_GENRE_ICON);

	FillListCtrl(&mTrackList, gTracksQuery, GetId());
	SetGridStyle(&mTrackList);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
