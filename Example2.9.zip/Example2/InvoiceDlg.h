#pragma once

#include "CustomDlg.h"


// CInvoiceDlg dialog

class CInvoiceDlg : public CCustomDlg
{
	DECLARE_DYNAMIC(CInvoiceDlg)

public:
	CInvoiceDlg(LPCTSTR pQuery, CWnd* pParent = NULL);   // standard constructor
	virtual ~CInvoiceDlg();

	virtual void SetControls(const Row& values, int id) override;

// Dialog Data
private:
	enum { IDD = IDD_INVOICE_DIALOG };

	CListCtrl mOrderItemsList;
	CComboBox mCustomersCombo;
	CStatic mPictureCtrl;

	CString mBillingCountryValue;
	CString mBillingAddressValue;
	CString mBillingCityValue;
	CString mBillingPostalCodeValue;
	CString mBillingStateValue;
	CString mInvoiceDateValue;
	int mInvoiceIDValue;
	int mCustomerIndex;
	double mInvoiceTotalValue;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
};


class InvoiceDlgFactory : public CustomDlgFactory
{
public:
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg() override
	{
		return std::unique_ptr<CCustomDlg>(new CInvoiceDlg(sInvoiceQuery));
	}
private:
	static LPCTSTR sInvoiceQuery;
};
