#pragma once

#include "CustomDlg.h"



// CEmployeeDlg dialog

class CEmployeeDlg : public CCustomDlg
{
	DECLARE_DYNAMIC(CEmployeeDlg)

public:
	CEmployeeDlg(LPCTSTR pQuery, CWnd* pParent = NULL);   // standard constructor
	virtual ~CEmployeeDlg();	

	virtual void SetControls(const Row& values, int id) override;

// Dialog Data
private:	
	enum { IDD = IDD_EMPLOYEE_DIALOG };

	CComboBox mReportsToCombo;
	CEdit mReporteesEdit;
	CDateTimeCtrl mHireDateCtrl;
	CDateTimeCtrl mBirthDateCtrl;
	CStatic mPictureCtrl;

	CString mAddressValue;
	CString mCityValue;
	CString mCountryValue;
	CString mEmailValue;
	CString mFaxValue;
	CString mFirstNameValue;
	CString mLastNameValue;
	CString mPhoneValue;
	CString mPostalCodeValue;
	CString mStateValue;
	int mReportsToIndex;
	CString mTitleValue;
	CString mHireDateValue;
	CString mBirthDateValue;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()	
};


class EmployeeDlgFactory : public CustomDlgFactory
{
public:
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg() override
	{
		std::unique_ptr<CCustomDlg> dlg(new CEmployeeDlg(sEmployeeQuery));
		return dlg;
	}
private:
	static LPCTSTR sEmployeeQuery;
};
