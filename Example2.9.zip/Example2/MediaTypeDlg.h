#pragma once

#include "CustomDlg.h"


// CMediaTypeDlg dialog

class CMediaTypeDlg : public CCustomDlg
{
	DECLARE_DYNAMIC(CMediaTypeDlg)

public:
	CMediaTypeDlg(LPCTSTR pQuery, CWnd* pParent = NULL);   // standard constructor
	virtual ~CMediaTypeDlg();

	virtual void SetControls(const Row& values, int id) override;

// Dialog Data
private:
	enum { IDD = IDD_MEDIATYPE_DIALOG };

	CListCtrl mTracksList;
	CString mMediaTypeNameValue;
	int mTrackCountValue;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()	
};


class MediaTypeDlgFactory : public CustomDlgFactory
{
public:
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg()
	{
		std::unique_ptr<CCustomDlg> dlg(new CMediaTypeDlg(sMediaTypeQuery));
		return dlg;
	}
private:
	static LPCTSTR sMediaTypeQuery;
};
