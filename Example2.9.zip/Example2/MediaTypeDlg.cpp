// MediaTypeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "MediaTypeDlg.h"
#include "afxdialogex.h"


// CMediaTypeDlg dialog


LPCTSTR MediaTypeDlgFactory::sMediaTypeQuery
{
	_T("SELECT m.name, COUNT(t.mediaTypeId) 'tracks count' ")
	_T(" FROM media_types m ")
	_T(" LEFT JOIN tracks t USING (mediaTypeId) ")
	_T(" GROUP BY m.mediaTypeId")
	_T(" HAVING m.mediaTypeId = %d")
}; 

enum MediaTypeType { mediaTypeName, tracksCount };


static LPCTSTR gTracksQuery
{
	_T("SELECT t.name 'Track', a.title 'Album', ")
	_T(" g.name 'Genre', t.composer, t.unitprice ")	
	_T("FROM tracks t ")
	_T("LEFT JOIN albums a USING (albumId) ")
	_T("LEFT JOIN genres g USING (genreId) ")
	_T("WHERE t.mediaTypeId = %d ")
};


IMPLEMENT_DYNAMIC(CMediaTypeDlg, CCustomDlg)

CMediaTypeDlg::CMediaTypeDlg(LPCTSTR pQuery, CWnd* pParent /*=NULL*/)
	: CCustomDlg(CMediaTypeDlg::IDD, pQuery, pParent)
	, mTrackCountValue(0)
{

}

CMediaTypeDlg::~CMediaTypeDlg()
{
}


void CMediaTypeDlg::SetControls(const Row& values, int id)
{
	SetId(id);
	mMediaTypeNameValue = values[MediaTypeType::mediaTypeName];
	mTrackCountValue = _ttoi(values[MediaTypeType::tracksCount]);
}


void CMediaTypeDlg::DoDataExchange(CDataExchange* pDX)
{
	CCustomDlg::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_MEDIATYPE_TRACK_LIST, mTracksList);

	DDX_Text(pDX, IDC_MEDIATYPE_NAME_EDIT, mMediaTypeNameValue);	
	DDX_Text(pDX, IDC_MEDIATYPE_TRACKCOUNT_EDIT, mTrackCountValue);
}


BEGIN_MESSAGE_MAP(CMediaTypeDlg, CCustomDlg)
END_MESSAGE_MAP()


// CMediaTypeDlg message handlers


BOOL CMediaTypeDlg::OnInitDialog()
{
	CCustomDlg::OnInitDialog();

	SetSystemMenuIcon(IDI_MEDIATYPE_ICON);

	FillListCtrl(&mTracksList, gTracksQuery, GetId());	
	SetGridStyle(&mTracksList);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
