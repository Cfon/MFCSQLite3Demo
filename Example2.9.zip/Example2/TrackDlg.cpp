// TrackDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "TrackDlg.h"
#include <memory>


// CTrackDlg dialog


LPCTSTR TrackDlgFactory::sTrackQuery
{
	_T("SELECT t.name 'Track', a.title 'Album', t.mediaTypeId, ")
	_T(" t.genreId, t.composer, t.milliseconds, t.bytes, t.unitprice ")
	_T(" FROM tracks t ")
	_T(" LEFT JOIN albums a USING (albumId) ")
	_T(" WHERE trackid = %d ")
};

enum TrackType
{
	trackName, albumName, mediaTypeId, genreId,
	composer, milliseconds, bytes, unitprice
};


static LPCTSTR gMediaTypesQuery
{ 
	_T("SELECT name FROM media_types")
};

enum MediaTypeType { mediaName };


static LPCTSTR gGenresQuery
{ 
	_T("SELECT name FROM genres;") 
};

enum GenreType { genreName };



IMPLEMENT_DYNAMIC(CTrackDlg, CCustomDlg)

CTrackDlg::CTrackDlg(LPCTSTR pQuery, CWnd* pParent /*=NULL*/)
	: CCustomDlg(CTrackDlg::IDD, pQuery, pParent)
	, mBytesValue(0)
	, mMillisecondsValue(0)
	, mPriceValue(0)
	, mMediaTypeIdIndex(0)
	, mGenreIdIndex(0)
{

}

CTrackDlg::~CTrackDlg()
{
}

void CTrackDlg::DoDataExchange(CDataExchange* pDX)
{
	CCustomDlg::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TRACK_MEDIATYPE_COMBO, mMediaTypesCombo);
	DDX_Control(pDX, IDC_TRACK_GENRE_COMBO, mGenresCombo);
	DDX_Control(pDX, IDC_TRACK_MILLISECONDS_EDIT, mMillisecondsEdit);
	DDX_Control(pDX, IDC_TRACK_BYTES_EDIT, mBytesEdit);

	DDX_Text(pDX, IDC_TRACK_BYTES_EDIT, mBytesValue);
	DDX_Text(pDX, IDC_TRACK_COMPOSER_EDIT, mComposerValue);
	DDX_Text(pDX, IDC_TRACK_MILLISECONDS_EDIT, mMillisecondsValue);
	DDX_Text(pDX, IDC_TRACK_NAME_EDIT, mTrackNameValue);
	DDX_Text(pDX, IDC_TRACK_PRICE_EDIT, mPriceValue);
	DDX_CBIndex(pDX, IDC_TRACK_MEDIATYPE_COMBO, mMediaTypeIdIndex);
	DDX_CBIndex(pDX, IDC_TRACK_GENRE_COMBO, mGenreIdIndex);
	DDX_Text(pDX, IDC_TRACK_ALBUM_EDIT, mAlbumNameValue);	
}


void CTrackDlg::SetControls(const Row& values, int id)
{
	SetId(id);				
	mAlbumNameValue = values[TrackType::albumName];
	mBytesValue = _ttoi(values[TrackType::bytes]);
	mComposerValue = values[TrackType::composer];
	mGenreIdIndex = _ttoi(values[TrackType::genreId]);
	mMediaTypeIdIndex = _ttoi(values[TrackType::mediaTypeId]);
	mMillisecondsValue = _ttoi(values[TrackType::milliseconds]);
	mTrackNameValue = values[TrackType::trackName];
	mPriceValue = _ttof(values[TrackType::unitprice]);
}


BEGIN_MESSAGE_MAP(CTrackDlg, CCustomDlg)
END_MESSAGE_MAP()


// CTrackDlg message handlers


BOOL CTrackDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// �������� ������ � ��������� ����
	SetSystemMenuIcon(IDI_TRACK_ICON);

	FillCombo(&mMediaTypesCombo, gMediaTypesQuery, MediaTypeType::mediaName);
	FillCombo(&mGenresCombo, gGenresQuery, GenreType::genreName);
	mMediaTypesCombo.SetCurSel(mMediaTypeIdIndex);
	mGenresCombo.SetCurSel(mGenreIdIndex);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}
