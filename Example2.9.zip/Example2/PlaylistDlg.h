#pragma once

#include "CustomDlg.h"


// CPlaylistDlg dialog

class CPlaylistDlg : public CCustomDlg
{
	DECLARE_DYNAMIC(CPlaylistDlg)

public:
	CPlaylistDlg(LPCTSTR pQuery, CWnd* pParent = NULL);   // standard constructor
	virtual ~CPlaylistDlg();

	virtual void SetControls(const Row& values, int id) override;

// Dialog Data
private:
	enum { IDD = IDD_PLAYLIST_DIALOG };

	CListCtrl mTracksList;
	CString mPlaylistNameValue;
	CString mTrackCountValue;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
};


class PlaylistDlgFactory : public CustomDlgFactory
{
public:
	virtual std::unique_ptr<CCustomDlg> CreateCustomDlg()
	{
		std::unique_ptr<CCustomDlg> dlg(new CPlaylistDlg(sPlaylistQuery));
		return dlg;
	}
private:
	static LPCTSTR sPlaylistQuery;
};
