// NumericFormatedEdit.cpp : implementation file
//

#include "stdafx.h"
#include "Example2.h"
#include "NumericFormatedEdit.h"


// CNumericFormatedEdit

IMPLEMENT_DYNAMIC(CNumericFormatedEdit, CEdit)

CNumericFormatedEdit::CNumericFormatedEdit()
	: mIsOnceInitValue(FALSE)
{
}

CNumericFormatedEdit::~CNumericFormatedEdit()
{
}


BEGIN_MESSAGE_MAP(CNumericFormatedEdit, CEdit)
	ON_CONTROL_REFLECT(EN_KILLFOCUS, &CNumericFormatedEdit::OnEnKillfocus)
	ON_CONTROL_REFLECT(EN_SETFOCUS, &CNumericFormatedEdit::OnEnSetfocus)	
	ON_WM_GETDLGCODE()	
END_MESSAGE_MAP()



// CNumericFormatedEdit message handlers


void CNumericFormatedEdit::OnEnKillfocus()
{
	CString formattedValue;
	GetWindowText(mValue);
	
	if (!mValue.IsEmpty())		
		FormatIntegerNumber(mValue, formattedValue);

	SetWindowText(formattedValue);	
	//TRACE(_T("%s\n"), mValue);
}


void CNumericFormatedEdit::OnEnSetfocus()
{		
	SetWindowText(mValue);
	const DWORD cSelectAll = 0xff00;
	SetSel(cSelectAll);
}


UINT CNumericFormatedEdit::OnGetDlgCode()
{	
	if (!mIsOnceInitValue)
	{
		OnEnKillfocus();
		//TRACE(_T("%s\n"), mValue);
		mIsOnceInitValue = TRUE;
	}

	return CEdit::OnGetDlgCode();
}

